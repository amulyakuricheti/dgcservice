package com.nike.dgcfulfillmentservice.service;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.repository.DgcRequestsRepository;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class DgcPaymentsService {

    private final DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;

//    private final DgcRequestDetailsRepository dgcRequestDetailsRepository;

    private final DgcRequestsRepository dgcRequestsRepository;

    public DgcRequest saveGCRequest(OrderRelease orderRelease, String gcAccountNo, String dgcRequestId) {
        DgcRequest dgcRequest = this.getDBDgcRequest(orderRelease);
        if (dgcRequest != null) {
            return dgcRequest;
        } else {
            dgcRequest = dgcPaymentsWrkrUtil.createDgcRequestRecordFromOrderRelease(orderRelease, gcAccountNo, dgcRequestId);
            dgcRequestsRepository.save(dgcRequest);
            log.info("DGC Request details successfully stored into DB with the dgcRequestId={}, transactionId = {}, details={}", dgcRequestId, dgcRequest.getTransactionId(), dgcRequest);
            return dgcRequest;
        }
    }

    public List<DgcRequest> getRetryTransactions() {
        return dgcRequestsRepository.getRecordsToRetry();
    }


    public DgcRequest getDBDgcRequest(OrderRelease orderRelease) {
        String shipAdviceNo = orderRelease.getShipAdviceNo();
        String orderLineKey = orderRelease.getOrderLine().getOrderLineKey();
        Optional<DgcRequest> optionalDgcRequest = dgcRequestsRepository.getTransactionByRequestId(dgcPaymentsWrkrUtil.getDgcRequestId(orderLineKey, shipAdviceNo));
        DgcRequest dgcRequest = null;
        if (optionalDgcRequest.isPresent()) {
            log.info("Dgc Request is already exists for shipAdviceNo = {} and orderLineKey={}", shipAdviceNo, orderLineKey);
            dgcRequest = optionalDgcRequest.get();
        }
        return dgcRequest;
    }

    public Optional<DgcRequest> getDgcRequestByDgcRequestId(String dgcRequestId) {
        return dgcRequestsRepository.getTransactionByRequestId(dgcRequestId);
    }

//    public DgcDetails getDgcRequestDetails(String paymentDetailId) throws Exception {
//        DgcDetails dgcDetails = null;
//        try {
//            Optional<DgcDetails> optionalDBPaymentDetails = dgcRequestDetailsRepository.getPaymentDetailsByPaymentDetailId(paymentDetailId);
//            if (optionalDBPaymentDetails.isPresent()) {
//                dgcDetails = optionalDBPaymentDetails.get();
//            }
//        } catch (RecordNotFoundException e) {
//            log.error("Record does not exists in DB for the paymentDetailId = {}", paymentDetailId);
//            throw new RuntimeException(String.format("Record does not exists in the DB for the paymentDetailId = %s", paymentDetailId));
//        }
//        return dgcDetails;
//    }

    public void updateTransactionWithCompleted(String dgcRequestId) {
        Optional<DgcRequest> optionalDgcRequest = dgcRequestsRepository.getTransactionByRequestId(dgcRequestId);
        if (optionalDgcRequest.isPresent()) {
            DgcRequest dbDgcRequest = optionalDgcRequest.get();
            dbDgcRequest.setRequestStatus(TransactionStatusConstants.STATUS_COMPLETED);
            dbDgcRequest.setLastModifiedDateTime(OffsetDateTime.now());
            dbDgcRequest.setTtl(OffsetDateTime.now().plusDays(DgcPaymentConstants.RETENTION_DAYS).toEpochSecond());
            dgcRequestsRepository.updateTransaction(dbDgcRequest);
            log.info("Successfully updated DB record with COMPLETED status fo dgcRequestId={}, shipAdviceNo={}, enterpriseCode={}", dbDgcRequest.getDgcRequestId(), dbDgcRequest.getShipAdviceNo(), dbDgcRequest.getEnterpriseCode());
        } else {
            throw new RuntimeException(String.format("Unable to updated the PG Put response for the requestId %s", dgcRequestId));
        }
    }

    public void updateTransactionToRetry(String dgcRequestId, String errorCode, String errorMessage, OffsetDateTime retryExpiryTime) {
        Optional<DgcRequest> optionalDgcRequest = this.getDgcRequestByDgcRequestId(dgcRequestId);
        if (optionalDgcRequest.isPresent()) {
            DgcRequest dgcRequest = optionalDgcRequest.get();
            dgcRequest.setRequestStatus(TransactionStatusConstants.STATUS_RETRY);
            dgcRequest.setErrorCode(errorCode);
            dgcRequest.setErrorMessage(errorMessage);
            dgcRequest.setLastModifiedDateTime(OffsetDateTime.now());
            if (retryExpiryTime != null) {
                dgcRequest.setRetryExpiryDateTime(retryExpiryTime);
            }
            dgcRequestsRepository.updateTransaction(dgcRequest);
            log.info("transaction successfully updated with RETRY status for dgcRequestId={} with details={}", dgcRequestId, dgcRequest.toString());

        } else {
            throw new RuntimeException(String.format("Unable to update RETRY status for the dgcRequestId=%s", dgcRequestId));
        }
    }


    public void updateTransactionToError(String dgcRequestId, String errorCode, String errorMessage) {
        Optional<DgcRequest> optionalDgcRequest = this.getDgcRequestByDgcRequestId(dgcRequestId);
        if (optionalDgcRequest.isPresent()) {
            DgcRequest dgcRequest = optionalDgcRequest.get();
            dgcRequest.setRequestStatus(TransactionStatusConstants.STATUS_ERROR);
            dgcRequest.setErrorCode(errorCode);
            dgcRequest.setErrorMessage(errorMessage);
            dgcRequest.setLastModifiedDateTime(OffsetDateTime.now());
            dgcRequestsRepository.updateTransaction(dgcRequest);
            log.info("transaction successfully updated with ERROR status for dgcRequestId={} with details={}", dgcRequestId, dgcRequest.toString());
        } else {
            throw new RuntimeException(String.format("Unable to update DB with ERROR status for the dgcRequestId=%s", dgcRequestId));
        }
    }

//    /***
//     * this method is used to check if there is any transaction with dgcRequestId
//     * and if it is PROCESSED/COMPLETED
//     *
//     * @param dgcRequestId
//     * @return
//     */
//    public Boolean isTransactionValidToProceed(String dgcRequestId) {
//        Boolean isTransactionValid = true;
//        Optional<DgcRequest> optionalDgcRequest = this.getDgcRequestByDgcRequestId(dgcRequestId);
//        if (optionalDgcRequest.isPresent()) {
//            DgcRequest dgcRequest = optionalDgcRequest.get();
//            String requestStatus = dgcRequest.getRequestStatus();
//            if (requestStatus != null && requestStatus.equalsIgnoreCase(TransactionStatusConstants.STATUS_PROCESSED)
//                    || dgcRequest.getRequestStatus().equalsIgnoreCase(TransactionStatusConstants.STATUS_COMPLETED)) {
//                isTransactionValid = false;
//            }
//        }
//        return isTransactionValid;
//    }


}
