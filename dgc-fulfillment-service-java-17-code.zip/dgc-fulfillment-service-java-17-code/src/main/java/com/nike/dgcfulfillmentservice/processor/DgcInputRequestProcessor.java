package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.constant.RuleEngineConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.model.AccountRuleEnginePayload;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.service.DgcPaymentsService;
import com.nike.dgcfulfillmentservice.service.RuleEngineService;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import com.nike.dgcfulfillmentservice.validator.DGCInputPayloadValidator;
import com.nike.wingtips.TraceHeaders;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class DgcInputRequestProcessor implements Processor {

    private final DgcPaymentsService dgcPaymentsService;

    private final DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;

    private final RuleEngineService ruleEngineService;

    private final DGCInputPayloadValidator dgcInputPayloadValidator;

    @Override
    public void process(Exchange exchange) throws Exception {
        OrderRelease orderRelease = exchange.getIn().getBody(OrderRelease.class);
        log.info("DgcInputRequestProcessor: OrderRelease payload with minimal details is:{}", orderRelease);
        String traceId = exchange.getIn().getHeader(TraceHeaders.TRACE_ID, String.class);
        if (this.isOrderReleaseValid(orderRelease)) {
            String dgcRequestId = dgcPaymentsWrkrUtil.getDgcRequestId(orderRelease.getOrderLine().getOrderLineKey(), orderRelease.getShipAdviceNo());

            Map<String, String> ruleEngineAttr = this.prepareRuleEnginePayload(orderRelease);
            AccountRuleEnginePayload accountRuleEnginePayload = ruleEngineService.getGiftCardAccountNo(ruleEngineAttr, traceId);

            DgcRequest dgcRequest = dgcPaymentsService.saveGCRequest(orderRelease, accountRuleEnginePayload.getAccountNo(), dgcRequestId);
            log.info("DgcRequestId and transactionId sending to downstream are {}, {}", dgcRequestId, dgcRequest.getTransactionId());

            exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, dgcRequestId);
            exchange.setProperty(DgcPaymentConstants.DGC_REQUEST_SHIP_ADVICE_NO, dgcRequest.getShipAdviceNo());
            exchange.setProperty(DgcPaymentConstants.DGC_REQUEST_ENTERPRISE_CODE, dgcRequest.getEnterpriseCode());
            exchange.setProperty(DgcPaymentConstants.TRANSACTION_ID, dgcRequest.getTransactionId());
            exchange.setProperty(DgcPaymentConstants.TRANSACTION_STATUS, dgcRequest.getRequestStatus());
        } else {
            throw new BadRequestException(String.format("Invalid Dgc request payload received from VOM, orderRelease payload=%s", orderRelease));
        }
    }


    public Map<String, String> prepareRuleEnginePayload(OrderRelease orderRelease) {
        Map<String, String> ruleEngineAttr = new HashMap<>();
        ruleEngineAttr.put(RuleEngineConstants.ENTERPRISE_CODE, orderRelease.getEnterpriseCode());
        ruleEngineAttr.put(RuleEngineConstants.CURRENCY, orderRelease.getOrder().getPriceInfo().getCurrency());
        ruleEngineAttr.put(RuleEngineConstants.DGC_TYPE, DgcPaymentConstants.DGC_TYPE_DGC);
        return ruleEngineAttr;
    }

    private boolean isOrderReleaseValid(OrderRelease orderRelease) {
        boolean isIncomingRequestValid = dgcInputPayloadValidator.isIncomingVOMInputValid(orderRelease);
        return isIncomingRequestValid;
    }
}
