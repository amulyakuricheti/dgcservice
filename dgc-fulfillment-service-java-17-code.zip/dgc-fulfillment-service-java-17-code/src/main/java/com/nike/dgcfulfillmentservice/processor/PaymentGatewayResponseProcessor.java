package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.service.PaymentGatewayService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PaymentGatewayResponseProcessor implements Processor {

    private final PaymentGatewayService paymentGatewayService;

    @Override
    public void process(Exchange exchange) throws Exception {
        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        Object paymentGatewayResponseObj = exchange.getIn().getBody();

        if (paymentGatewayResponseObj instanceof PaymentGatewayResponse) {
            PaymentGatewayResponse paymentGatewayResponse = (PaymentGatewayResponse) paymentGatewayResponseObj;
            if (paymentGatewayResponse.getStatus().equalsIgnoreCase(TransactionStatusConstants.STATUS_COMPLETED)) { //Completed
                log.info("Payment response received with Complete status for dgcRequestId = {}", dgcRequestId);
                paymentGatewayService.updateWithPGCompletedResponse(dgcRequestId, paymentGatewayResponse);
                exchange.setProperty(DgcPaymentConstants.TRANSACTION_STATUS, TransactionStatusConstants.STATUS_PROCESSED);
                exchange.setProperty(DgcPaymentConstants.PG_RESULT_URL, paymentGatewayResponse.getResponse().getLinks().getSelf().getRef());
            } else { //Pending
                log.info("Payment request is not complete for the dgcRequestId = {}", dgcRequestId);
                paymentGatewayService.updateWithPGPendingResponse(dgcRequestId, paymentGatewayResponse);
                exchange.setProperty(DgcPaymentConstants.TRANSACTION_STATUS, TransactionStatusConstants.STATUS_PROCESSING);
            }
        } else { //in case of payment gateway result URL gets called
            log.info("Payment response received with Complete status  from result url for dgcRequestId = {}", dgcRequestId);
//            PaymentGatewayResponse.Response paymentGatewayResultResponse = (PaymentGatewayResponse.Response) paymentGatewayResponseObj;
            exchange.setProperty(DgcPaymentConstants.TRANSACTION_STATUS, TransactionStatusConstants.STATUS_PROCESSED);
        }
    }
}

