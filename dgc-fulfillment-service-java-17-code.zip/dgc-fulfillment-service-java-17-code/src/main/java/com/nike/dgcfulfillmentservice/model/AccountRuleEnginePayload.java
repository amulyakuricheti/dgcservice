package com.nike.dgcfulfillmentservice.model;

import lombok.Data;

@Data
public class AccountRuleEnginePayload {
    private String enterpriseCode;
    private String currency;
    private String type;
    private String accountNo;
}
