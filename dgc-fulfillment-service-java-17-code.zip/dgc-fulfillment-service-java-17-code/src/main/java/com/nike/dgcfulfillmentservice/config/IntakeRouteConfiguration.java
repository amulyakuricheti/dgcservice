//package com.nike.dgcfulfillmentservice.config;
//
//import com.nike.ceartemis.configuration.SQSConfiguration;
//import com.nike.dgcfulfillmentservice.route.IngressDgcReleaseEventRouteConfig;
//import com.nike.integration.pulse.ingress.route.configuration.IngressFromPulseRouteBuilder;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.camel.CamelContext;
//import org.apache.camel.builder.RouteBuilder;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//@Slf4j
//@Component
//@RequiredArgsConstructor(onConstructor_ = {@Autowired})
//public class IntakeRouteConfiguration implements InitializingBean {
//
//    public static final String ORDER_RELEASE_DGC_INTAKE_ROUTE = "OrderRelease_DGC-intake-route";
//
//    private final SQSConfiguration sqsConfiguration;
//
//    private final IngressFromPulseRouteBuilder ingressFromPulseRouteBuilder;
//
//    private final CamelContext camelContext;
//
//    @Value("${sqs.vom.dgc.order_release.queue}")
//    private String orderReleaseIntakeQueue;
//
//    @Value("${sqs.vom.dgc.order_release.dlq}")
//    private String orderReleaseIntakeDlq;
//
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        sqsConfiguration.amazonSQSClient();
//
//        final RouteBuilder orderReleaseDgcIntakeRouteBuilder = ingressFromPulseRouteBuilder.createIngressFromPulseRouteBuilder(
//                ORDER_RELEASE_DGC_INTAKE_ROUTE, orderReleaseIntakeQueue, orderReleaseIntakeDlq, IngressDgcReleaseEventRouteConfig.INGRESS_DGC_RELEASE_EVENT_ROUTE_NAME);
//
//        camelContext.addRoutes(orderReleaseDgcIntakeRouteBuilder);
//
//    }
//}
