package com.nike.dgcfulfillmentservice.util;

import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

@Component
@Slf4j
@RequiredArgsConstructor
public class DgcPaymentsWrkrUtil {


    public DgcRequest createDgcRequestRecordFromOrderRelease(OrderRelease request, String gcAccountNo, String dgcRequestId) {
        DgcRequest dgcRequest = new DgcRequest();
        OffsetDateTime currentTime = OffsetDateTime.now();
        dgcRequest.setTransactionId(UUID.randomUUID().toString());
        dgcRequest.setOrderNumber(request.getSalesOrderNo());
        dgcRequest.setDgcRequestId(dgcRequestId);
        dgcRequest.setCreationDateTime(currentTime);
        dgcRequest.setLastModifiedDateTime(currentTime);
        dgcRequest.setRequestStatus(TransactionStatusConstants.STATUS_NEW);
        dgcRequest.setOrderLineKey(request.getOrderLine().getOrderLineKey());
        dgcRequest.setReleaseNo(request.getReleaseNo());
        dgcRequest.setShipAdviceNo(request.getShipAdviceNo());
        dgcRequest.setQuantity(request.getOrderLine().getOrderedQty());
        dgcRequest.setGiftCardAccountNumber(gcAccountNo);
        dgcRequest.setSalesOrderNumber(request.getSalesOrderNo());
        dgcRequest.setEnterpriseCode(request.getEnterpriseCode());
        dgcRequest.setCurrency(request.getOrder().getPriceInfo().getCurrency());
        dgcRequest.setRequestAmount(request.getOrderLine().getExtn().getExtnDenomination());
        dgcRequest.setOrderHeaderKey(request.getOrderHeaderKey());
        dgcRequest.setCertificateProfileId(request.getOrder().getBuyerUserId());
        dgcRequest.setSenderFirstName(request.getOrder().getPersonInfoBillTo().getFirstName());
        dgcRequest.setSenderLastName(request.getOrder().getPersonInfoBillTo().getLastName());
        dgcRequest.setRecipientEmail(request.getOrderLine().getPersonInfoShipTo().getEmailId());
        dgcRequest.setSenderEmail(request.getOrder().getPersonInfoBillTo().getEmailId());
        log.info("Transaction Record details for the incoming orderNumber = {}, shipAdviceNumber  = {} being formed with transactionId  = {}", request.getSalesOrderNo(), request.getShipAdviceNo(), dgcRequest.getTransactionId());

        return dgcRequest;
    }


    /***
     *
     * @param orderLineKey
     * @param uniqueReqIdentifier This parameter holds shipAdviceNo
     * @return
     */
    public String getDgcRequestId(String orderLineKey, String uniqueReqIdentifier) {
        String dgcRequestId;
        if ((uniqueReqIdentifier != null) && !uniqueReqIdentifier.isEmpty()) {
            dgcRequestId = orderLineKey + "_" + uniqueReqIdentifier;
        } else {
            dgcRequestId = orderLineKey;
        }
        return dgcRequestId;
    }

    public boolean isEligibleToRetry(Exception exception) {
        Boolean isEligibleToRetry = true;
        Map<String, String> errorDetails = PaymentsExceptionUtil.getErrorDetails(exception);
        String exceptionStatusCode = errorDetails.get("ErrorCode");
        if (exceptionStatusCode != null
                && (exceptionStatusCode.equals(String.valueOf(HttpStatus.SC_BAD_REQUEST))
                || exceptionStatusCode.equals(String.valueOf(HttpStatus.SC_CONFLICT)))) {
            isEligibleToRetry = false;
        }
        return isEligibleToRetry;
    }


}
