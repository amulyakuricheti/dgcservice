package com.nike.dgcfulfillmentservice.model.asyncbridge;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class BooleanXmlAdapter extends XmlAdapter<String, Boolean> {

    private static final String STRING_TRUE = "Y";
    private static final String STRING_FALSE = "N";

    public Boolean unmarshal(String v) throws Exception {
        if (v == null) {
            return false;
        }
        if (STRING_TRUE.equals(v)) {
            return true;
        }
        return false;
    }

    public String marshal(Boolean v) throws Exception {
        return (v ? STRING_TRUE : STRING_FALSE);
    }

}
