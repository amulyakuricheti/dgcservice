package com.nike.dgcfulfillmentservice.route;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.processor.InputToPGGetSqsMessageProcessor;
import com.nike.dgcfulfillmentservice.processor.PaymentGatewayResponseProcessor;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.IS_PG_DGC_RESULTS_ENDPOINT;

@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class GetPGUpdateRouteConfig extends RouteBuilder {

    public static final String GET_PG_UPDATE_ROUTE_ID = "get-from-pg-route-id";
    public static final String PG_GET_CALL_ROUTE_NAME = "direct:" + GET_PG_UPDATE_ROUTE_ID;

    private final InputToPGGetSqsMessageProcessor inputToPGGetSqsMessageProcessor;

    private final PaymentGatewayResponseProcessor paymentGatewayResponseProcessor;

    @Value("${camel.payments.pg_get.connectionTimeOut:10000}")
    private long connectionTimeOut;

    @Value("${camel.payments.pg_get.SocketTimeout:10000}")
    private long socketTimeout;

    @Value("${camel.hystrix.timout:10000}")
    private int hystrixTimeout;

    @Value("${hystrix.http.protocol:http4}")
    private String httpProtocol;

    @Value("${oscar.service-scopes.payment-gift_certificate_results-v1.GET}")
    private String giftCertificateResultEndpointScope;

    @Value("${oscar.service-scopes.payment-gift_certificates-v1.GET}")
    private String giftCertificateGetEndpointScope;

    @Override
    public void configure() throws Exception {

        from(PG_GET_CALL_ROUTE_NAME)
                .routeId(GET_PG_UPDATE_ROUTE_ID)
                .routeDescription("this is route will call PG GET endpoint either jobs or result endpoint based on the url received in the sqs message")
                .process(inputToPGGetSqsMessageProcessor)
                .setBody(constant(null))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json; charset=UTF-8"))
                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.GET))
                .setHeader(DgcPaymentConstants.X_NIKE_APP_ID, constant(DgcPaymentConstants.ASYNCPAYMENTS))
                .choice()
                .when(exchangeProperty(IS_PG_DGC_RESULTS_ENDPOINT))
                .setHeader(DgcPaymentConstants.SCOPE, simple(giftCertificateResultEndpointScope))
                .otherwise()
                .setHeader(DgcPaymentConstants.SCOPE, simple(giftCertificateGetEndpointScope))
                .end()
                .log(LoggingLevel.INFO, "before calling  payment gateway GET Endpoint for dgcRequestId=${header." + DgcPaymentConstants.DGC_REQUEST_ID + "} && transactionId = ${header." + DgcPaymentConstants.TRANSACTION_ID + "} &&  traceId = ${header.X-B3-TraceId}")
                .hystrix()
                .hystrixConfiguration()
                .executionTimeoutInMilliseconds(hystrixTimeout)
                .end()
                .serviceCall().name("${property.VIP_NAME}")
                .expression()
                .simple(httpProtocol + ":${header.CamelServiceCallServiceHost}:${header.CamelServiceCallServicePort}"
                        + "${property.URL_PATH}"
                        + "?httpClient.SocketTimeout=" + socketTimeout
                        + "&httpClient.ConnectTimeout=" + connectionTimeOut
                        + "&httpClientConfigurer=#customOscarNoRetryConfigurer"
                        + "&connectionClose=true")
                .end()
                .endHystrix()
                .onFallback()
                .process(exchange -> {
                    throw new RuntimeException(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class));
                })
                .end()
                .convertBodyTo(String.class)
                .choice()
                .when(exchangeProperty(IS_PG_DGC_RESULTS_ENDPOINT))
                .unmarshal().json(JsonLibrary.Jackson, PaymentGatewayResponse.Response.class)
                .endChoice()
                .otherwise()
                .unmarshal().json(JsonLibrary.Jackson, PaymentGatewayResponse.class)
                .end()
                .process(paymentGatewayResponseProcessor)
                .log(LoggingLevel.INFO, "Received response from PG GET call for dgcRequestId=${header." + DgcPaymentConstants.DGC_REQUEST_ID + "}")
                .end();
    }
}
