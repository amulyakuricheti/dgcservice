package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.service.DgcPaymentsService;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import com.nike.dgcfulfillmentservice.util.PaymentsExceptionUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.Optional;


@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PGPutCallExceptionProcessor implements Processor {

    private final DgcPaymentsService dgcPaymentsService;

    private final DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;

    @Override
    public void process(Exchange exchange) {
        Exception camelExceptionCaught = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
        Map<String, String> errorDetails = PaymentsExceptionUtil.getErrorDetails(camelExceptionCaught);
        Boolean isEligibleToRetry = dgcPaymentsWrkrUtil.isEligibleToRetry(camelExceptionCaught);
        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        if (isEligibleToRetry) {
            log.info("Received dgc request after pg put call failed to try with dgcRequestId={}", dgcRequestId);
            OffsetDateTime retryExpirationDateTime = OffsetDateTime.now().plusHours(DgcPaymentConstants.FORTY_EIGHT_TRANSACTION_EXPIRY_HOURS);
            dgcPaymentsService.updateTransactionToRetry(dgcRequestId, errorDetails.get("ErrorCode"), errorDetails.get("ErrorMessage"), retryExpirationDateTime);
        } else {
            log.warn("Request is not eligible to process for dgcRequestId={} with error {}", dgcRequestId, camelExceptionCaught);
            throw new RuntimeException(camelExceptionCaught);
        }
    }


    public void handleExceptionOnRetry(Exchange exchange) throws Exception {
        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        Optional<DgcRequest> optionalDgcRequest = dgcPaymentsService.getDgcRequestByDgcRequestId(dgcRequestId);
        Exception camelExceptionCaught = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
        Map<String, String> errorDetails = PaymentsExceptionUtil.getErrorDetails(camelExceptionCaught);
        if (optionalDgcRequest.isPresent()) {
            if (optionalDgcRequest.get().getRetryExpiryDateTime().compareTo(OffsetDateTime.now().plusMinutes(5)) != -1) {
                dgcPaymentsService.updateTransactionToRetry(dgcRequestId, errorDetails.get("ErrorCode"), errorDetails.get("ErrorMessage"), null);
            } else {
                dgcPaymentsService.updateTransactionToError(dgcRequestId, errorDetails.get("ErrorCode"), errorDetails.get("ErrorMessage"));
            }
            log.info("dgcRequestId {} successfully updated with error details after PG PUT Call", dgcRequestId);
        }
    }

}
