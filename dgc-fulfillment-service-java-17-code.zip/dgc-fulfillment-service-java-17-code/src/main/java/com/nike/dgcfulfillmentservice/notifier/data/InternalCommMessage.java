package com.nike.dgcfulfillmentservice.notifier.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class InternalCommMessage {
    private String dgcRequestId;
    private String giftCardType;
    private String pgGetJobUrl;
}
