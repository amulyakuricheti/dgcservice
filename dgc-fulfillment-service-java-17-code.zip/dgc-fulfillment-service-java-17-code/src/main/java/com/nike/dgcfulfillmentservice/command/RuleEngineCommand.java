package com.nike.dgcfulfillmentservice.command;

import com.amazonaws.util.json.Jackson;
import com.google.gson.JsonObject;
import com.nike.dgcfulfillmentservice.model.RuleEngineResponse;
import com.nike.wingtips.TraceHeaders;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestOperations;

import java.util.Map;
import java.util.Set;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class RuleEngineCommand {

//    private static final String HYSTRIX_COMMAND_GROUP = "GetBackOrderRulesCommand";

    @Value("${platform.ruleengine.vipName}")
    private String ruleEngineVipName;

    @Value("${platform.ruleengine.gift_card_account_no.urlSuffix}")
    private String ruleEngineBackorderUrlSuffix;

    @Qualifier("restTemplateWithLoadBalancer")
    private final RestOperations restTemplate;

    public String getGiftCardAccountNo(Map<String, String> ruleEngineAttr, String traceId) {
        String getUrlWithOrderNumber = this.getRuleEngineUrl();
        String requestBody = this.prepareRuleEnginePayload(ruleEngineAttr);
        log.info("Calling  ruleEngine URL : {} and ruleEngineReqBody={} ", getUrlWithOrderNumber, requestBody);
        HttpHeaders headers = new HttpHeaders();
        headers.set(TraceHeaders.TRACE_ID, traceId);
        headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.set(HttpHeaders.ACCEPT_CHARSET, "UTF-8");
        HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);
        try {
            ResponseEntity<String> response = restTemplate.postForEntity(getUrlWithOrderNumber, requestEntity, String.class);
            log.info("Successfully called ruleEngine post endpoint with response : {}", response);
            RuleEngineResponse ruleEngineResponse = Jackson.fromJsonString(response.getBody(), RuleEngineResponse.class);
            if (ruleEngineResponse.getResultFound()) {
                return ruleEngineResponse.getAccountNo();
            } else {
                return null;
            }
        } catch (Exception e) {
            log.warn("failed calling rule engine for the reason : {}", e.getCause());
            throw new RuntimeException(String.format("Unable to get gift card accountNo for the values %s", ruleEngineAttr.toString()), e);
        }
    }

    private String getRuleEngineUrl() {
        return "http://" + ruleEngineVipName + ruleEngineBackorderUrlSuffix;
    }

    private String prepareRuleEnginePayload(Map<String, String> ruleEngAttr) {
        JsonObject reqBodyJsonObj = new JsonObject();
        Set<Map.Entry<String, String>> entrySet = ruleEngAttr.entrySet();
        entrySet.forEach(e -> reqBodyJsonObj.addProperty(e.getKey(), e.getValue()));
        return reqBodyJsonObj.toString();
    }
}
