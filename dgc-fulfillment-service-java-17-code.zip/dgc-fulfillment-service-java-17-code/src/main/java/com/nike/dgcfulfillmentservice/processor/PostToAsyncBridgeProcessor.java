package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.model.asyncbridge.ExtnNikeGiftcardInfo;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.service.AsyncBridgeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.URL_PATH;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PostToAsyncBridgeProcessor implements Processor {

    private final AsyncBridgeService asyncBridgeService;

    @Override
    public void process(Exchange exchange) throws Exception {
        ExtnNikeGiftcardInfo asyncResponse;

        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        if (exchange.getIn().getBody() != null) {
            Object paymentGatewayResponseObj = exchange.getIn().getBody();
            //when pg get jobs url gets called
            if (paymentGatewayResponseObj instanceof PaymentGatewayResponse) { //usual flow
                PaymentGatewayResponse paymentGatewayResponse = (PaymentGatewayResponse) paymentGatewayResponseObj;
                log.info("paymentGateway response has been received for dgcRequestId={} from get jobs URL:{}", dgcRequestId, exchange.getProperty(URL_PATH, String.class));
                asyncResponse = asyncBridgeService.prepareAsyncPaymentResponse(dgcRequestId, paymentGatewayResponse.getResponse());
            } else { //retry flow when pg results url gets called
                PaymentGatewayResponse.Response paymentGatewayResponse = exchange.getIn().getBody(PaymentGatewayResponse.Response.class);
                log.info("paymentGateway response has been received for dgcRequestId={} from results URL:{}", dgcRequestId, exchange.getProperty(URL_PATH, String.class));
                asyncResponse = asyncBridgeService.prepareAsyncPaymentResponse(dgcRequestId, paymentGatewayResponse);
            }

            //setting xml payload to body
            if (asyncBridgeService.validate(asyncResponse)) {
                exchange.getIn().setBody(asyncResponse);
            } else {
                log.error("Invalid asyncResponse formed for dgcRequestId={}", dgcRequestId);
                asyncBridgeService.updateTransactionWithError(dgcRequestId, "400", "Bad_Request_To_AsyncBridge");
                throw new BadRequestException(String.format("Async Response is invalid to publish to AsyncBridge, dgcRequestId = %s", dgcRequestId));
            }
        } else {
            throw new RuntimeException(String.format("PG get Response is invalid to prepare  AsyncBridge response, dgcRequestId=%s", dgcRequestId));
        }

    }
}
