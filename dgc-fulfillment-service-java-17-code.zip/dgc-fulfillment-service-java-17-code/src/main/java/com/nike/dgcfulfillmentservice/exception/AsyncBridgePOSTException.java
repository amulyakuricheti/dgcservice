package com.nike.dgcfulfillmentservice.exception;

public class AsyncBridgePOSTException extends Exception {

    public AsyncBridgePOSTException(String errorMessage) {
        super(errorMessage);
    }

    public AsyncBridgePOSTException(Exception exception) {
        super(exception);
    }
}
