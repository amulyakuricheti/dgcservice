package com.nike.dgcfulfillmentservice.model.asyncbridge;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Data
@XmlRootElement(name = "ExtnNikeGiftcardInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class ExtnNikeGiftcardInfo {

    @XmlAttribute(name = "ExtnOrderLineKey")
    @NotEmpty(message = "ExtnOrderLineKey is empty.", groups = VOMDgcResponseCheck.class)
    private String extnOrderLineKey;

    @XmlAttribute(name = "ExtnOrderHeaderKey")
    @NotEmpty(message = "ExtnOrderHeaderKey is empty.", groups = VOMDgcResponseCheck.class)
    private String extnOrderHeaderKey;

    @XmlAttribute(name = "ExtnAuthCode")
    @NotEmpty(message = "ExtnAuthCode is empty.", groups = VOMDgcResponseCheck.class)
    private String extnAuthCode;

    @XmlAttribute(name = "ExtnTokenCode")
    @NotEmpty(message = "ExtnTokenCode is empty.", groups = VOMDgcResponseCheck.class)
    private String extnTokenCode;

    @XmlAttribute(name = "ExtnDecision")
    @NotEmpty(message = "ExtnDecision is empty.", groups = VOMDgcResponseCheck.class)
    private String extnDecision;

    @XmlAttribute(name = "ExtnSuccessStatus")
    @NotNull(message = "ExtnSuccessStatus is empty.", groups = VOMDgcResponseCheck.class)
    @XmlJavaTypeAdapter(BooleanXmlAdapter.class)
    private Boolean extnSuccessStatus;

    @XmlAttribute(name = "ExtnStatus")
    @NotEmpty(message = "ExtnStatus is empty.", groups = VOMDgcResponseCheck.class)
    private String extnStatus;

    @XmlAttribute(name = "ExtnExpirationDate")
    @NotEmpty(message = "ExtnExpirationDate is empty.", groups = VOMDgcResponseCheck.class)
//    @XmlJavaTypeAdapter(DateTimeAdapter.class)
    private String extnExpirationDate;

    @XmlAttribute(name = "OrderLineKey")
    @NotEmpty(message = "OrderLineKey is empty.", groups = VOMDgcResponseCheck.class)
    private String orderLineKey;

    @XmlAttribute(name = "Quantity")
    @NotNull(message = "Quantity is empty.", groups = VOMDgcResponseCheck.class)
    @XmlJavaTypeAdapter(DoubleXmlAdapter.class)
    private Double quantity;

    @XmlAttribute(name = "ReleaseNo")
    @NotEmpty(message = "ReleaseNo is empty.", groups = VOMDgcResponseCheck.class)
    private String releaseNo;

    @XmlAttribute(name = "OrderHeaderKey")
    @NotEmpty(message = "OrderHeaderKey is empty.", groups = VOMDgcResponseCheck.class)
    private String orderHeaderKey;

    @XmlAttribute(name = "ExtnPin")
    @NotEmpty(message = "ExtnPin is empty.", groups = VOMDgcResponseCheck.class)
    private String extnPin;

    @XmlAttribute(name = "ExtnGiftcardNumber")
    @NotEmpty(message = "ExtnGiftcardNumber is empty.", groups = VOMDgcResponseCheck.class)
    private String extnGiftcardNumber;

    @XmlAttribute(name = "IsDGC")
    @NotNull(message = "isDGC is empty.", groups = VOMDgcResponseCheck.class)
    @XmlJavaTypeAdapter(BooleanXmlAdapter.class)
    private Boolean isDGC;

}
