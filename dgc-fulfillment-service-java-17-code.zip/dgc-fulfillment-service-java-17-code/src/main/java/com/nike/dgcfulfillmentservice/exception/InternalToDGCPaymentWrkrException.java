package com.nike.dgcfulfillmentservice.exception;

public class InternalToDGCPaymentWrkrException extends RuntimeException {

//    public InternalToPaymentsException(Exception e) {
//        super(e);
//    }

    public InternalToDGCPaymentWrkrException(String msg) {
        super(msg);
    }
}
