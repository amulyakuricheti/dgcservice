package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.notifier.SQSNotifier;
import com.nike.dgcfulfillmentservice.repository.DgcRequestsRepository;
import com.nike.wingtips.TraceHeaders;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PublishMsgToGetPGUpdateProcessor implements Processor {

    @Autowired
    @Qualifier("pgGetCallNotifier")
    private SQSNotifier paymentsNotifier;

    private final DgcRequestsRepository dgcRequestsRepository;

    @Override
    public void process(Exchange exchange) throws Exception {
        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        Object paymentGatewayResponseObj = exchange.getIn().getBody(Object.class);
        String traceId = exchange.getIn().getHeader(TraceHeaders.TRACE_ID, String.class);
        String giftCardGetJobUrl;
        int eta = 0;
        log.info("Request received to notify PG GET Call route for dgcRequestId={}", dgcRequestId);
        if (paymentGatewayResponseObj instanceof PaymentGatewayResponse) {
            PaymentGatewayResponse paymentGatewayResponse = (PaymentGatewayResponse) paymentGatewayResponseObj;
            giftCardGetJobUrl = paymentGatewayResponse.getLinks().getSelf().getRef();
            eta = paymentGatewayResponse.getEta();
        } else { //for duplicate requests PG URL will be taken from DB to repost to Asyncbridge
            Optional<DgcRequest> dgcRequest = dgcRequestsRepository.getTransactionByRequestId(dgcRequestId);
            if (dgcRequest.get().getPgGiftCardResultsUrl() != null) {
                giftCardGetJobUrl = dgcRequest.get().getPgGiftCardResultsUrl();
            } else {
                giftCardGetJobUrl = dgcRequest.get().getPgGetUrl();
            }
        }
        paymentsNotifier.publishMessageForGETDetails(dgcRequestId, giftCardGetJobUrl, eta, traceId);

    }
}
