package com.nike.dgcfulfillmentservice.route;

import com.nike.camel.processor.DistributedTraceProcessor;
import com.nike.camel.processor.ExceptionLoggingProcessor;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.exception.InternalToDGCPaymentWrkrException;
import com.nike.dgcfulfillmentservice.notifier.data.InternalCommMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static com.nike.integration.pulse.common.RouteConstants.SQS_CLIENT_SUFFIX;
import static com.nike.integration.pulse.common.RouteConstants.SQS_SCHEMA;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class RetryPostToAsyncBridgeRouteConfig extends RouteBuilder {

    public static final String ASYNC_BRIDGE_EXCEPTIONAL_ROUTE_ID = "asyncBridge-exceptional-route-id";

    @Value("${sqs.dgc.pac-post-retry.queue}")
    private String asyncBridgeExceptionalProcessInputQueue;

    @Value("${sqs.dgc.pac-post-retry.dlq}")
    private String asyncBridgeExceptionalProcessInputDlq;

    @Value("${sqs.no.consumers:1}")
    private String numberOfConsumers;

    @Value("${sqs.max.no.messages:10}")
    private int maxNumberOfMessages;

    @Value("${sqs.redeliveryDelayMs}")
    private long redeliverDelay;

    @Value("${sqs.maxRedeliveryCount}")
    private int maxRedeliveryCount;

    @Override
    public void configure() throws Exception {

        onException(InternalToDGCPaymentWrkrException.class, BadRequestException.class)
                .handled(true)
                .useOriginalMessage()
                .bean(ExceptionLoggingProcessor.class)
                .to(SQS_SCHEMA + asyncBridgeExceptionalProcessInputDlq + SQS_CLIENT_SUFFIX)
                .end();

        onException(Exception.class)
                .useOriginalMessage()
                .bean(DistributedTraceProcessor.class)
                .bean(ExceptionLoggingProcessor.class)
                .maximumRedeliveries(maxRedeliveryCount)
                .redeliveryDelay(redeliverDelay)
                .asyncDelayedRedelivery()
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .retriesExhaustedLogLevel(LoggingLevel.ERROR);


        String uri = SQS_SCHEMA + asyncBridgeExceptionalProcessInputQueue + SQS_CLIENT_SUFFIX
                + "&concurrentConsumers=" + numberOfConsumers
                + "&maxMessagesPerPoll=" + maxNumberOfMessages
                + "&messageAttributeNames="
                + "X-B3-TraceId,X-B3-SpanId,X-B3-Sampled";

        from(uri)
                .routeId(ASYNC_BRIDGE_EXCEPTIONAL_ROUTE_ID)
                .routeDescription("this route will re-process exceptional requests")
                .log(LoggingLevel.INFO, "received request to retry  asyncBridge post for the dgcRequestId = ${body}")
                .unmarshal().json(JsonLibrary.Jackson, InternalCommMessage.class)
                .to(GetPGUpdateRouteConfig.PG_GET_CALL_ROUTE_NAME)
                .to(PostToAsyncBridgeRouteConfig.POST_TO_PAC_ROUTE_NAME)
                .log(LoggingLevel.INFO, "On retry Successfully processed asyncBridge record ${body}")
                .end();
    }
}
