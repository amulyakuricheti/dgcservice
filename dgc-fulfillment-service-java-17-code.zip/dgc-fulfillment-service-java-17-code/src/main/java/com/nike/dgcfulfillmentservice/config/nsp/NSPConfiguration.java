package com.nike.dgcfulfillmentservice.config.nsp;

import com.nike.hades.nspkafkautil.model.KafkaSourceConfig;
import com.nike.hades.nspkafkautil.model.OauthKeys;
import com.nike.hades.nspkafkautil.producer.PublishToKafkaProducer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;

import java.util.Map;


@Configuration
@Slf4j
@RequiredArgsConstructor(onConstructor = @__({@Autowired}))
public class NSPConfiguration {
    public static final String OAUTH_SECRET_KEY = "client_secret";
    public static final String OAUTH_CLIENT_ID_KEY = "client_id";
    public static final String OAUTH_TOKEN_URL_KEY = "token_url";

    private final PublishToKafkaProducer publishToKafkaProducer;

    @Value("${kafka.broker.url}")
    private String brokerUrl;
    @Value("${kafka.stream.clientid}")
    private String sourceId;
    @Value("${kafka.topicName}")
    private String topicName;

    @Autowired
    @Qualifier("CerberusSecrets")
    private Map<String, String> cerberusProps;

    @EventListener(ApplicationReadyEvent.class)
    public void initKafkaProducer() {
        publishToKafkaProducer.initProducer(buildOauthKeys(), buildKafkaSource());
        log.info("action=processNSP status=Successfully initialized PublishToKafkaProducer.");
    }

    private OauthKeys buildOauthKeys() {
        if (cerberusProps.get(OAUTH_TOKEN_URL_KEY) != null && cerberusProps.get(OAUTH_CLIENT_ID_KEY) != null
                && cerberusProps.get(OAUTH_SECRET_KEY) != null) {
            log.info("action=processNSP event: retrievalOfCerberusValues is Successful");
        } else {
            log.error("action=processNSP event: retrievalOfCerberusValues Failed");
        }
        return OauthKeys.builder()
                .tokenUrl(cerberusProps.get(OAUTH_TOKEN_URL_KEY))
                .clientId(cerberusProps.get(OAUTH_CLIENT_ID_KEY))
                .clientSecret(cerberusProps.get(OAUTH_SECRET_KEY))
                .build();
    }

    private KafkaSourceConfig buildKafkaSource() {
        return KafkaSourceConfig.builder()
                .sourceBrokerUrl(brokerUrl)
                .sourceId(sourceId)
                .sourceTopicName(topicName)
                .build();
    }
}
