package com.nike.dgcfulfillmentservice.model;

import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Data;

@Data
@JsonPOJOBuilder
public class RuleEngineResponse {
    private String accountNo;
    private Boolean resultFound;
}
