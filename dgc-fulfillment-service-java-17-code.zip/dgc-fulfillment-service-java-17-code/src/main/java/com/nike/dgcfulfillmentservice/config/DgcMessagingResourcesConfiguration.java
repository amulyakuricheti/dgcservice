//package com.nike.dgcfulfillmentservice.config;
//
//import com.nike.ceartemis.configuration.MessagingResourcesConfiguration;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import java.util.Arrays;
//import java.util.Map;
//import java.util.stream.Collectors;
//
//
//@Configuration
//public class DgcMessagingResourcesConfiguration extends MessagingResourcesConfiguration {
//
//    public static final String PULSE_TO_DGCPAYMENTSWRKR_PROCESSING_RESOURCES = "VomOrderReleaseEvent";
//    public static final String DGCPAYMENTSWRKR_TO_PG_GET_PROCESSING_RESOURCES = "PaymentsToPG_GET";
//    public static final String ASYNCBRIDGE_POST_ON_ERROR_TO_PAC_PROCESSING_RESOURCES = "ErrorPaymentResponseReprocess";
//
//
//    @Value("${sns.vom.egc.release.event}")
//    private String dgcOrderReleaseTopic;
//
//    @Value("${sqs.vom.dgc.order_release.queue}")
//    private String dgcOrderReleaseNotifyQueueName;
//
//    @Value("${sqs.vom.dgc.order_release.dlq}")
//    private String dgccOrderReleaseNotifyDLQName;
//
//    @Value("${sqs.dgc.pg-get.queue}")
//    private String pgGetCallInputQueue;
//
//    @Value("${sqs.dgc.pg-get.dlq}")
//    private String pgGetCallInputQueueDlq;
//
//    @Value("${sqs.dgc.pac-post-retry.queue}")
//    private String pacRetryQueue;
//
//    @Value("${sqs.dgc.pac-post-retry.dlq}")
//    private String pacRetryDlq;
//
//
//    @Bean(name = MESSAGING_RESOURCES)
//    @Override
//    public Map<String, MessagingResources> getMessagingResources() {
//        return Arrays.asList(getPublishAsyncPaymentsToPGResources(), getPaymentJobIdToSQSResources(), getPostResponseToPACSQSResources())
//                .stream().collect(Collectors.toMap(MessagingResources::getResourcesName, messagingResources -> messagingResources));
//    }
//
//
//    /* Async bridge post retry queue configurations*/
//    private MessagingResources getPublishAsyncPaymentsToPGResources() {
//        return new MessagingResources(PULSE_TO_DGCPAYMENTSWRKR_PROCESSING_RESOURCES, dgcOrderReleaseTopic,
//                dgcOrderReleaseNotifyQueueName, dgccOrderReleaseNotifyDLQName);
//    }
//
//    private MessagingResources getPaymentJobIdToSQSResources() {
//        return new MessagingResources(DGCPAYMENTSWRKR_TO_PG_GET_PROCESSING_RESOURCES, null,
//                pgGetCallInputQueue, pgGetCallInputQueueDlq);
//    }
//
//    private MessagingResources getPostResponseToPACSQSResources() {
//        return new MessagingResources(ASYNCBRIDGE_POST_ON_ERROR_TO_PAC_PROCESSING_RESOURCES, null,
//                pacRetryQueue, pacRetryDlq);
//    }
//
//
//}
