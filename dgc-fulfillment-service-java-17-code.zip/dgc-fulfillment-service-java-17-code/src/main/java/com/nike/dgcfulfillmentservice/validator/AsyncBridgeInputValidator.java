package com.nike.dgcfulfillmentservice.validator;

import com.nike.dgcfulfillmentservice.model.asyncbridge.ExtnNikeGiftcardInfo;
import com.nike.dgcfulfillmentservice.model.asyncbridge.VOMDgcResponseCheck;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Set;

@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class AsyncBridgeInputValidator {

    private final Validator validator;

    public boolean isAsyncResponseValid(ExtnNikeGiftcardInfo extnNikeGiftcardInfo) {
        return validateAsyncPaymentResponse(extnNikeGiftcardInfo).isEmpty();
    }

    private Set<ConstraintViolation<ExtnNikeGiftcardInfo>> validateAsyncPaymentResponse(ExtnNikeGiftcardInfo recordExternalCharges) {
        return validator.validate(recordExternalCharges, VOMDgcResponseCheck.class);
    }


}
