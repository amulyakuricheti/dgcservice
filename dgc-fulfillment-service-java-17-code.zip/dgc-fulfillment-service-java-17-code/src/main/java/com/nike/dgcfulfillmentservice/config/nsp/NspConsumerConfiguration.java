package com.nike.dgcfulfillmentservice.config.nsp;

import com.nike.dgcfulfillmentservice.route.IngressDgcReleaseEventRouteConfig;
import com.nike.om.nsp.routes.NspRouteBuilder;
import com.nike.om.nsp.utils.NspKafkaConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.kafka.KafkaConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

import static com.nike.dgcfulfillmentservice.route.IngressDgcReleaseEventRouteConfig.INGRESS_DGC_RELEASE_EVENT_ROUTE_ID;
import static com.nike.dgcfulfillmentservice.route.IngressDgcReleaseEventRouteConfig.INGRESS_DGC_RELEASE_EVENT_ROUTE_NAME;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class NspConsumerConfiguration {

    private final NspRouteBuilder nspRouteBuilder;
    private final CamelContext context;
    private final NspKafkaConfig nspKafkaConfig;

    @Value("${custom.kafka.topic}")
    private String nspConsumerTopic;

    @Value("${nsp.master.invoice.groupid}")
    private String nspDgcFulfillmentGroupId;

    public static final String DGC_RELEASE_EVENT_ROUTE_ID = "dgcReleaseEventRoute";
    public static final String DIRECT_NSP_CONSUMER_INVOICE_ROUTE_NAME = "direct:" + DGC_RELEASE_EVENT_ROUTE_ID;


@Bean("nspDgcFulfillmentOrderReleaseIngressConfig")
public KafkaConfiguration nspDgcFulfillmentConfig() {
    return nspKafkaConfig.getConsumerConfig(nspConsumerTopic, nspDgcFulfillmentGroupId);
}

    @PostConstruct
    public void addNspRoutes() throws Exception {

        final RouteBuilder nspScanfileConsumerRoute = nspRouteBuilder.nspConsumerRouteBuilder(nspConsumerTopic, "nspDgcFulfillmentConfig",
                INGRESS_DGC_RELEASE_EVENT_ROUTE_NAME, INGRESS_DGC_RELEASE_EVENT_ROUTE_ID,
                IngressDgcReleaseEventRouteConfig.INGRESS_DGC_RELEASE_EVENT_ROUTE_NAME);
        context.addRoutes(nspScanfileConsumerRoute);

    }
}
