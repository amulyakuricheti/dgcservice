package com.nike.dgcfulfillmentservice.route;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.exception.PaymentGatewayPUTException;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.processor.PaymentGatewayInputProcessor;
import com.nike.dgcfulfillmentservice.processor.PaymentGatewayResponseProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PostToPaymentGatewayRouteConfig extends RouteBuilder {


    public static final String PUT_TO_PG_ROUTE_ID = "put-request-to-pg";
    public static final String PUT_TO_PG_ROUTE_NAME = "direct:" + PUT_TO_PG_ROUTE_ID;

    private final PaymentGatewayInputProcessor paymentGatewayInputProcessor;

    private final PaymentGatewayResponseProcessor paymentGatewayResponseProcessor;

    @Value("${camel.pg_put.connectionTimeOut:10000}")
    private long connectionTimeOut;

    @Value("${camel.pg_put.SocketTimeout:10000}")
    private long socketTimeout;

    @Value("${camel.hystrix.timout:10000}")
    private int hystrixTimeout;

    @Value("${hystrix.http.protocol:http4}")
    private String httpProtocol;

    @Value("${oscar.service-scopes.payment-gift_certificates-v1.PUT}")
    private String giftCertificatePutEndpointScope;

    @Override
    public void configure() throws Exception {

        from(PUT_TO_PG_ROUTE_NAME)
                .routeId(PUT_TO_PG_ROUTE_ID)
                .routeDescription("post dgc request to Payment Gateway")
                .errorHandler(noErrorHandler())
                .process(paymentGatewayInputProcessor)
                .marshal().json(JsonLibrary.Jackson)
                .log(LoggingLevel.INFO, "Before calling Payment Gateway PUT endpoint, data = ${body}")
                .removeHeaders("CamelServiceCall*") //to remove the previous call (pulse) headers
                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.PUT))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))// to remove header which are populated by previous service call
                .setHeader(DgcPaymentConstants.X_NIKE_APP_ID, constant(DgcPaymentConstants.ASYNCPAYMENTS))
                .setHeader(DgcPaymentConstants.SCOPE, simple(giftCertificatePutEndpointScope))
                .hystrix()
                .hystrixConfiguration()
                .executionTimeoutInMilliseconds(hystrixTimeout)
                .end()// end of configuration block
                .serviceCall().name("${property.VIP_NAME}")
                .expression()
                .simple(httpProtocol + ":${header.CamelServiceCallServiceHost}:${header.CamelServiceCallServicePort}"
                        + "${property.URL_PATH}"
                        + "?httpClient.SocketTimeout=" + socketTimeout
                        + "&httpClient.ConnectTimeout=" + connectionTimeOut
                        + "&httpClientConfigurer=#customOscarNoRetryConfigurer"
                        + "&connectionClose=true")
                .end()
                .endHystrix()// end hystrix block
                .onFallback()
                .log(LoggingLevel.ERROR, "in PaymentGateway PUT Call fallback dgcRequestId=${header." + DgcPaymentConstants.DGC_REQUEST_ID + "}")
                .process(exchange -> {
                    throw new PaymentGatewayPUTException(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class));
                }).end()
                .convertBodyTo(String.class)
                .log(LoggingLevel.INFO, "Response received from PG PUT call is = ${body}, dgcRequestId=${header." + DgcPaymentConstants.DGC_REQUEST_ID + "}")
                .unmarshal().json(JsonLibrary.Jackson, PaymentGatewayResponse.class)
                .process(paymentGatewayResponseProcessor)// payment gateway response processor
                .end();

    }
}
