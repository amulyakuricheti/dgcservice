package com.nike.dgcfulfillmentservice.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

import static java.util.Collections.singletonMap;

/**
 * Example endpoint that returns version information about the application.
 */
@RestController
@RequestMapping("/order_mgmt")
public class DgcPaymentsController {

    @RequestMapping(value = "/dgc_payments/v1", method = RequestMethod.GET, produces = {"application/json"})
    public Map<String, String> success() {
        return singletonMap("success", "true");
    }



}
