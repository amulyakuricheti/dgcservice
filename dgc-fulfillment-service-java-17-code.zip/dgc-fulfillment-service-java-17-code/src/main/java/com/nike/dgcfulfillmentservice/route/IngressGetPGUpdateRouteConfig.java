package com.nike.dgcfulfillmentservice.route;

import com.nike.camel.processor.DistributedTraceProcessor;
import com.nike.camel.processor.ExceptionLoggingProcessor;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.exception.AsyncBridgePOSTException;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.exception.InternalToDGCPaymentWrkrException;
import com.nike.dgcfulfillmentservice.notifier.data.InternalCommMessage;
import com.nike.dgcfulfillmentservice.processor.AsyncBridgeExceptionProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static com.nike.integration.pulse.common.RouteConstants.SQS_CLIENT_SUFFIX;
import static com.nike.integration.pulse.common.RouteConstants.SQS_SCHEMA;


@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class IngressGetPGUpdateRouteConfig extends RouteBuilder {

    public static final String GET_PG_UPDATE_INGRESS_ROUTE_ID = "get-pg-update-ingress-route-id";

    @Value("${sqs.dgc.pg-get.queue}")
    private String pgGetCallInputQueue;

    @Value("${sqs.dgc.pg-get.dlq}")
    private String pgGetCallInputDlq;

    @Value("${sqs.no.consumers:3}")
    private int numberOfConsumers;

    @Value("${sqs.max.no.messages:10}")
    private int maxNumberOfMessages;

    @Value("${camel.redeliveryDelayMs}")
    private long redeliverDelay;

    @Value("${camel.maxRedeliveryCount}")
    private int maxRedeliveryCount;

    @Override
    public void configure() throws Exception {

        onException(AsyncBridgePOSTException.class)
                .handled(true)
                .bean(AsyncBridgeExceptionProcessor.class)
                .stop();

        onException(InternalToDGCPaymentWrkrException.class, BadRequestException.class)
                .handled(true)
                .useOriginalMessage()
                .bean(ExceptionLoggingProcessor.class)
                .to(SQS_SCHEMA + pgGetCallInputDlq + SQS_CLIENT_SUFFIX)
                .end();

        onException(Exception.class)
                .useOriginalMessage()
                .bean(DistributedTraceProcessor.class)
                .bean(ExceptionLoggingProcessor.class)
                .maximumRedeliveries(maxRedeliveryCount)
                .redeliveryDelay(redeliverDelay)
                .asyncDelayedRedelivery()
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .retriesExhaustedLogLevel(LoggingLevel.ERROR);


        String uri = SQS_SCHEMA + pgGetCallInputQueue + SQS_CLIENT_SUFFIX
                + "&concurrentConsumers=" + numberOfConsumers
                + "&maxMessagesPerPoll=" + maxNumberOfMessages
                + "&messageAttributeNames="
                + ",X-B3-TraceId,X-B3-SpanId,X-B3-Sampled";

        from(uri)
                .routeId(GET_PG_UPDATE_INGRESS_ROUTE_ID)
                .routeDescription("Get DGC details  from payment gateway ")
                .streamCaching()
                .bean(DistributedTraceProcessor.class)
                .process(exchange -> {
                    exchange.setProperty("PG_GET_START_TIME", System.currentTimeMillis());
                })
                .log(LoggingLevel.INFO, "internal sqs messageBody is: ${body}")
                .unmarshal().json(JsonLibrary.Jackson, InternalCommMessage.class)
                .to(GetPGUpdateRouteConfig.PG_GET_CALL_ROUTE_NAME)
                .choice()
                .when(exchangeProperty(DgcPaymentConstants.TRANSACTION_STATUS).isEqualTo(TransactionStatusConstants.STATUS_PROCESSING))
                .to(NotifyGetPGUpdateRouteConfig.PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_NAME)
                .when(exchangeProperty(DgcPaymentConstants.TRANSACTION_STATUS).isEqualTo(TransactionStatusConstants.STATUS_PROCESSED))
                .to(PostToAsyncBridgeRouteConfig.POST_TO_PAC_ROUTE_NAME)
                .end()
                .end();
    }


}
