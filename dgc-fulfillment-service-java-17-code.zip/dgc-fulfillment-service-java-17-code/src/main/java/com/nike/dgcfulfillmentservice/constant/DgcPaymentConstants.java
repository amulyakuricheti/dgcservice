package com.nike.dgcfulfillmentservice.constant;

public final class DgcPaymentConstants {

    public static final String ASYNCPAYMENTS = "asyncpayments";
    public static final String SCOPE = "scope";

    private DgcPaymentConstants() {

    }

    public static final String PRIORITY_NORMAL = "NORMAL";

    public static final String DGC_TYPE_DGC = "DGC";

    public static final String DGC_REQUEST_ID = "dgcRequestId";
    public static final String DGC_REQUEST_SHIP_ADVICE_NO = "dgcShipAdviceNo"; //for logging
    public static final String DGC_REQUEST_ENTERPRISE_CODE = "enterpriseCode"; //for logging

    public static final String TRANSACTION_ID = "transactionId";
    public static final String GIFT_CARD_TYPE_ACC_NO = "giftCardTypeAccNo";

    public static final String VIP_NAME_DELIMITER = "-";

    public static final String URL_SEPARATOR = "/";

    public static final String X_NIKE_APP_ID = "X-Nike-AppId";

    public static final String URL_PATH = "URL_PATH";
    public static final String VIP_NAME = "VIP_NAME";
    public static final String PG_RESULT_URL = "PG_RESULT_URL";
    public static final String TRANSACTION_STATUS = "TRANSACTION_STATUS";
    public static final int RETENTION_DAYS = 60;
    public static final Integer FORTY_EIGHT_TRANSACTION_EXPIRY_HOURS = 48;
    public static final String ASYNC_BRIDGE_POST_EXCEPTION = "ASYNC_BRIDGE_POST_FAILED";

    public static final String IS_PG_DGC_RESULTS_ENDPOINT = "IS_PG_DGC_RESULTS_ENDPOINT";
}
