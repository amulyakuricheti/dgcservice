package com.nike.dgcfulfillmentservice.model.paymentgateway;

public interface PaymentGatewayDGCInputCheck {
}
