package com.nike.dgcfulfillmentservice.model.asyncbridge;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class DoubleXmlAdapter extends XmlAdapter<String, Double> {
    @Override
    public Double unmarshal(String value) throws Exception {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public String marshal(Double value) throws Exception {
        if (value == null) {
            return "";
        }
        return value.toString();
    }
}
