package com.nike.dgcfulfillmentservice.route;

import com.nike.camel.processor.DistributedTraceProcessor;
import com.nike.camel.processor.ExceptionLoggingProcessor;
import com.nike.dgcfulfillmentservice.exception.InternalToDGCPaymentWrkrException;
import com.nike.dgcfulfillmentservice.exception.PaymentGatewayPUTException;
import com.nike.dgcfulfillmentservice.processor.PGPutCallExceptionProcessor;
import com.nike.dgcfulfillmentservice.processor.SchedulerProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class RetryPostToPGSchedulerRouteConfig extends RouteBuilder {

    public static final String SCHEDULER_ROUTE_ID = "quartz2:PGPutCallRetryScheduler";

    private final SchedulerProcessor schedulerProcessor;

    @Value("${quartz2.cron}")
    private String cronSchedule;

    @Value("${camel.redeliveryDelayMs}")
    private long redeliverDelay;

    @Value("${camel.maxRedeliveryCount}")
    private int maxRedeliveryCount;

    @Override
    public void configure() throws Exception {


        onException(InternalToDGCPaymentWrkrException.class, PaymentGatewayPUTException.class)
                .handled(true)
                .bean(DistributedTraceProcessor.class)
                .bean(PGPutCallExceptionProcessor.class, "handleExceptionOnRetry")
                .stop();

        onException(Exception.class)
                .useOriginalMessage()
                .bean(DistributedTraceProcessor.class)
                .bean(ExceptionLoggingProcessor.class)
                .maximumRedeliveries(maxRedeliveryCount)
                .redeliveryDelay(redeliverDelay)
                .asyncDelayedRedelivery()
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .retriesExhaustedLogLevel(LoggingLevel.ERROR);


        from("quartz2:PGPutCallRetryScheduler?" + cronSchedule)
                .routeId(SCHEDULER_ROUTE_ID)
                .routeDescription("to retry the PG PUT Call fetch records from the DB")
                .bean(schedulerProcessor, "getRecordsToRetry()")
                .split(simple("${body}"))
                .bean(DistributedTraceProcessor.class)
                .log(LoggingLevel.INFO, "Received record to retry with dgcRequestId=${body}")
                .process(schedulerProcessor)
                .to(PostToPaymentGatewayRouteConfig.PUT_TO_PG_ROUTE_NAME)
                .to(NotifyGetPGUpdateRouteConfig.PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_NAME)
                .end();

    }
}
