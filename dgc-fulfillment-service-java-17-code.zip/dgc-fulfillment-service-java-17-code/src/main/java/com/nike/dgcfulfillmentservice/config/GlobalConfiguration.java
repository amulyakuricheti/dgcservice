package com.nike.dgcfulfillmentservice.config;

import com.nike.om.configuration.interceptors.OscarInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

@Configuration
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class GlobalConfiguration {

    @Value("${http.connection.timeout.ms}")
    private long connectTimeoutInMillis;

    @Value("${http.read.timeout.ms}")
    private long readTimeoutInMillis;

    @LoadBalanced
    @Bean(name = "restTemplateWithLoadBalancer")
    public RestTemplate getRestTemplate() {
        return new RestTemplateBuilder()
                .setConnectTimeout(Duration.ofMillis(connectTimeoutInMillis))
                .setReadTimeout(Duration.ofMillis(readTimeoutInMillis))
                .additionalInterceptors(createOscarInterceptor())
                .build();
    }

    @Bean
    public OscarInterceptor createOscarInterceptor() {
        return new OscarInterceptor();
    }

}
