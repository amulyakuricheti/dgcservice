package com.nike.dgcfulfillmentservice.notifier;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.util.json.Jackson;
import com.nike.dgcfulfillmentservice.notifier.data.InternalCommMessage;
import com.nike.wingtips.TraceHeaders;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;


@Slf4j
public class SQSNotifierImpl implements SQSNotifier {

    private AmazonSQS amazonSQS;

    private String queueURL;

    public SQSNotifierImpl(AmazonSQS amazonSQS, String queueURL) {
        this(queueURL);
        this.amazonSQS = amazonSQS;
    }

    public SQSNotifierImpl(String queueURL) {
        this.queueURL = queueURL;
    }


    //sending PG GET URL as body
    public void publishMessageForGETDetails(String dgcRequestId, String jobURL, Integer eta, String traceId) {
        log.info("this is to publish jobUrl to PG GET queue with eta={}, dgcRequestId={}", eta, dgcRequestId);

        SendMessageRequest request = this.prepareMessageRequest(traceId);
        InternalCommMessage internalSQSMessage = this.prepareSQSMessage(dgcRequestId, jobURL);
        request.setMessageBody(Jackson.toJsonPrettyString(internalSQSMessage));

        /**
         * 900000milliseconds = 900Seconds,
         * Note: AWS stipulated delaySeconds is 900Seconds.
         *
         **/
        Integer minDelayMs = 900000;
        eta = eta > minDelayMs ? minDelayMs : eta;
        request.setDelaySeconds(eta / 1000);
        //setting delay seconds as 300 seconds for the get call for testing purpose.
        //request.setDelaySeconds(300);
        this.publish(request, traceId);
    }

    private SendMessageRequest prepareMessageRequest(String traceId) {
        SendMessageRequest request = new SendMessageRequest();
        Map<String, MessageAttributeValue> messageAttributes = new HashMap<String, MessageAttributeValue>();
        messageAttributes.put(TraceHeaders.TRACE_ID, new MessageAttributeValue().withDataType("String").withStringValue(traceId));
        request.setMessageAttributes(messageAttributes);
        return request;
    }

    /**
     * Creates an SQS message.
     *
     * @param request
     * @throws Exception
     */
    private void publish(SendMessageRequest request, String traceId) {
        log.info("publish(queue={}, traceId={})", queueURL, traceId);
        long startTime = System.currentTimeMillis();
        request.setQueueUrl(this.queueURL);
        this.amazonSQS.sendMessage(request);
        log.info("event = publish to queue={}, success=true, message={}, traceId={}, TimeTakenToPublishToSqs={}ms", this.queueURL, request.toString(), traceId, (System.currentTimeMillis() - startTime));
    }

    public InternalCommMessage prepareSQSMessage(String dgcRequestId, String getJobUrl) {
        InternalCommMessage internalSQSMessage = new InternalCommMessage();
        internalSQSMessage.setPgGetJobUrl(getJobUrl);
        internalSQSMessage.setDgcRequestId(dgcRequestId);
        return internalSQSMessage;
    }


}
