package com.nike.dgcfulfillmentservice.constant;

public final class RuleEngineConstants {
    public static final String DGC_TYPE = "type";
    public static final String ENTERPRISE_CODE = "enterpriseCode";
    public static final String CURRENCY = "currency";

    private RuleEngineConstants() {

    }
}
