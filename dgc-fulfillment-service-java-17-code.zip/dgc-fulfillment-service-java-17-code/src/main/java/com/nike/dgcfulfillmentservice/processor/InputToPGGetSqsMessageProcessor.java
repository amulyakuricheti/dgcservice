package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.notifier.data.InternalCommMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class InputToPGGetSqsMessageProcessor implements Processor {

    @Value("${paymentgateway.giftcertificate.vip.name}")
    private String pgGiftCardEndPointVipName;

    @Value("${paymentgateway.giftcertificate_results.vip.name}")
    private String pgGiftCardResultsEndPointVipName;

    private static final String PG_RESULTS_ENDPOINT_RESOURCE = "gift_certificate_results";


    @Override
    public void process(Exchange exchange) throws Exception {
        InternalCommMessage internalSQSMessage = exchange.getIn().getBody(InternalCommMessage.class);
        String jobURL = internalSQSMessage.getPgGetJobUrl();
        String dgcRequestId = internalSQSMessage.getDgcRequestId();
        log.info("Internal SQS message received with  PG get URL :{} for dgcRequestId={}", jobURL, dgcRequestId);
        exchange.setProperty(DgcPaymentConstants.URL_PATH, jobURL);
        if (jobURL.contains(PG_RESULTS_ENDPOINT_RESOURCE)) {
            exchange.setProperty(DgcPaymentConstants.VIP_NAME, pgGiftCardResultsEndPointVipName);
            exchange.setProperty(DgcPaymentConstants.IS_PG_DGC_RESULTS_ENDPOINT, true); // this flag will be used to differentiate PG responses
        } else {
            exchange.setProperty(DgcPaymentConstants.VIP_NAME, pgGiftCardEndPointVipName);
        }
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, dgcRequestId);
        log.info("PG get call VIP name set in property is:{},dgcRequestId={}", exchange.getProperty(DgcPaymentConstants.VIP_NAME), dgcRequestId);
    }
}
