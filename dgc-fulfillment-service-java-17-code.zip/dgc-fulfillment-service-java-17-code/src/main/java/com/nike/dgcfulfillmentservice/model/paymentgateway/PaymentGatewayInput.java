package com.nike.dgcfulfillmentservice.model.paymentgateway;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentGatewayInput {

    private String priority;

    @Valid
    private Request request;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Builder
    @Data
    public static class Request {
        @NotEmpty(message = "ReferenceCode is  empty", groups = PaymentGatewayDGCInputCheck.class)
        private String referenceCode;

        @NotNull(message = "amount is  empty", groups = PaymentGatewayDGCInputCheck.class)
        private Double amount;

//        @NotEmpty(message = "CertificateProfileId is  empty", groups = PaymentGatewayDGCInputCheck.class)
        private String certificateProfileId;

        @NotEmpty(message = "currency is  empty", groups = PaymentGatewayDGCInputCheck.class)
        private String currency;

        @NotEmpty(message = "account is  empty", groups = PaymentGatewayDGCInputCheck.class)
        private String account;

        @Valid
        private RecipientInfo recipientInfo;

        @Valid
        private SenderInfo senderInfo;


        @Data
        public static class RecipientInfo {
            @Valid
            private ContactInfo contactInfo;

            @Data
            public static class ContactInfo {
                @NotEmpty(message = "RecipientEmail is  empty", groups = PaymentGatewayDGCInputCheck.class)
                private String email;
            }
        }

        @Data
        public static class SenderInfo {
            @Valid
            private ContactInfo contactInfo;

            @Valid
            private Name name;

            @Data
            public static class ContactInfo {
                @NotEmpty(message = "SenderEmail is  empty", groups = PaymentGatewayDGCInputCheck.class)
                private String email;
            }

            @Data
            public static class Name {

                @NotEmpty(message = "FirstName is  empty", groups = PaymentGatewayDGCInputCheck.class)
                private String firstName;

                @NotEmpty(message = "LastName is  empty", groups = PaymentGatewayDGCInputCheck.class)
                private String lastName;
            }
        }
    }
}
