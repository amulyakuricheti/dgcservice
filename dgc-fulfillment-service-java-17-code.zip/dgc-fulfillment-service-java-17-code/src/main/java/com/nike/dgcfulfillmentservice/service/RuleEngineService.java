package com.nike.dgcfulfillmentservice.service;

import com.nike.dgcfulfillmentservice.command.RuleEngineCommand;
import com.nike.dgcfulfillmentservice.constant.RuleEngineConstants;
import com.nike.dgcfulfillmentservice.model.AccountRuleEnginePayload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Responsible for getting, updating and creating RetryDuration values.
 * Has cached data and initializes data once app started if there are no values stored in DB.
 */
@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class RuleEngineService {

    private ConcurrentHashMap<String, AccountRuleEnginePayload> ruleEngineDgcEntries = new ConcurrentHashMap<>();
    private AtomicLong pollCounter = new AtomicLong();

    private final RuleEngineCommand ruleEngineCommand;


    public AccountRuleEnginePayload getGiftCardAccountNo(Map<String, String> ruleEngineAttr, String traceId) throws Exception {
        String cacheKey = String.join("_", ruleEngineAttr.values());
        AccountRuleEnginePayload backOrderRetryRule = ruleEngineDgcEntries.get(cacheKey);
        if (backOrderRetryRule != null) {
            log.info("DGC Account Number has been picked from cache. for internalCacheKey={} and accountNumber={} ", ruleEngineAttr.toString(), backOrderRetryRule.getAccountNo());
            return backOrderRetryRule;
        } else {
            log.info("DGC accountNumber is not present in cache so calling rule engine for {}", ruleEngineAttr.toString());
            backOrderRetryRule = this.getDgcAccountNoFromRuleEngine(ruleEngineAttr, traceId);
            return backOrderRetryRule;
        }

    }


    /**
     * Call this method to update cached values once something has changed(like RetryDuration is updated through API)
     */
    public void clearCache() {
        ruleEngineDgcEntries.clear();
        log.info("Cached accountNumber were cleared");
    }

    /**
     * fixedRate = 3600000ms = 1 hours
     * initialDelay = 20000ms = 20 seconds
     */
    @Scheduled(fixedRate = 3600000, initialDelay = 20000)
    public void clearCacheScheduler() {
        Long pollNumber = pollCounter.incrementAndGet();
        log.info("Polling to clear cache. pollNumber: {}", pollNumber);
        this.clearCache();
    }


    private AccountRuleEnginePayload getDgcAccountNoFromRuleEngine(Map<String, String> ruleEngAttr, String traceId) throws Exception {
        String accountNumber = ruleEngineCommand.getGiftCardAccountNo(ruleEngAttr, traceId);
        if (accountNumber != null) {
            AccountRuleEnginePayload backOrderRetryRule = new AccountRuleEnginePayload();
            backOrderRetryRule.setEnterpriseCode(ruleEngAttr.get(RuleEngineConstants.ENTERPRISE_CODE));
            backOrderRetryRule.setCurrency(ruleEngAttr.get(RuleEngineConstants.CURRENCY));
            backOrderRetryRule.setType(ruleEngAttr.get(RuleEngineConstants.DGC_TYPE));
            backOrderRetryRule.setAccountNo(accountNumber);

            ruleEngineDgcEntries.put(backOrderRetryRule.getEnterpriseCode()
                    + "_" + backOrderRetryRule.getCurrency()
                    + "_" + backOrderRetryRule.getType(), backOrderRetryRule);

            log.info("DGC Account Number successfully stored into cache after fetching from rule engine with the internalCacheKey={} and accountNumber={}", ruleEngAttr.toString(), backOrderRetryRule.getAccountNo());
            return backOrderRetryRule;
        } else {
            log.error("Unable to find the dgc accountNumber in Rule Engine for the parameters {}", ruleEngAttr.toString());
            throw new RuntimeException(String.format("RuleEngineService: Unable to fetch Account number for the parameters %s", ruleEngAttr.toString()));
        }
    }

}
