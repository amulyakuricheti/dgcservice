package com.nike.phylon.exception;

/**
 * Interface that all error code enumerations must implement.
 *
 * @author Greg Whitaker
 */
public interface BaseErrorCode {

    /**
     * @return error code
     */
    String getValue();
}
