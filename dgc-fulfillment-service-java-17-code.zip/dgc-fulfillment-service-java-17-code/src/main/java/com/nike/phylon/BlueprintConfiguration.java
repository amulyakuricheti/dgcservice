package com.nike.phylon;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
//import com.amazonaws.util.EC2MetadataUtils;
import com.netflix.hystrix.contrib.metrics.eventstream.HystrixMetricsStreamServlet;
import com.nike.dgcfulfillmentservice.notifier.SQSNotifier;
import com.nike.dgcfulfillmentservice.notifier.SQSNotifierImpl;
import com.nike.phylon.jwt.auth.JWTInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsAsyncClientHttpRequestFactory;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import javax.validation.Validator;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Spring configuration class that provides custom configuration of common beans.
 */
@Configuration
public class BlueprintConfiguration {

    @Value("${min.thread.count}")
    private int minThreadCount;

    @Value("${max.thread.count}")
    private int maxThreadCount;

    @Value("${idle.time.seconds}")
    private int timeToLive;

//    @Autowired
//    private AmazonSQS amazonSQS;

    @Value("${sqs.dgc.pg-get.queue}")
    private String pgGetCallInputQueue;

    @Value("${sqs.dgc.pac-post-retry.queue}")
    private String asyncBridgeRetryInputQueue;

    @Qualifier("JWTInterceptor")
    @Autowired
    private JWTInterceptor jwtInterceptor;

//    @Bean
//    public EurekaInstanceConfigBean eurekaInstanceConfigBean() {
//        EurekaInstanceConfigBean bean = new EurekaInstanceConfigBean(new InetUtils(new InetUtilsProperties()));
//        AmazonInfo dataCenter = AmazonInfo.Builder.newBuilder().autoBuild("eureka");
//        bean.setDataCenterInfo(dataCenter);
//        return bean;
//    }

    @Bean
    public AmazonSQS amazonSQSClient() {
        return AmazonSQSClientBuilder
                .standard()
                .withRegion(Regions.US_EAST_1)
                .build();
    }

    @LoadBalanced
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    ThreadPoolExecutor executors() {
        return new ThreadPoolExecutor(minThreadCount, maxThreadCount, timeToLive, TimeUnit.SECONDS, new LinkedBlockingQueue<>(maxThreadCount));
    }


    @Bean
    public ServletRegistrationBean hystrixStreamServlet() {
        return new ServletRegistrationBean(new HystrixMetricsStreamServlet(), "/hystrix.stream");
    }

    @Bean
    @LoadBalanced
    @Deprecated
    AsyncRestTemplate asyncRestTemplate(@LoadBalanced RestTemplate restTemplate) {
        AsyncRestTemplate template = new AsyncRestTemplate(
                new HttpComponentsAsyncClientHttpRequestFactory(), restTemplate);
        return template;
    }

    @Bean(name = "pgGetCallNotifier")
    public SQSNotifier getPGGetCallNotifier() {
        return new SQSNotifierImpl(amazonSQSClient(), amazonSQSClient().getQueueUrl(pgGetCallInputQueue).getQueueUrl());
    }

    @Bean(name = "postToPACRetryNotifier")
    public SQSNotifier getPostToPACRetryNotifier() {
        return new SQSNotifierImpl(amazonSQSClient(), amazonSQSClient().getQueueUrl(asyncBridgeRetryInputQueue).getQueueUrl());
    }

    @Bean
    public Validator localValidatorFactoryBean() {
        return new LocalValidatorFactoryBean();
    }

    /**
     * JWT Interceptor for authentication in controller end-point
     *
     * @return
     */
    @Bean
    public WebMvcConfigurerAdapter webMvcConfigurerAdapter() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(jwtInterceptor);
            }
        };
    }
}
