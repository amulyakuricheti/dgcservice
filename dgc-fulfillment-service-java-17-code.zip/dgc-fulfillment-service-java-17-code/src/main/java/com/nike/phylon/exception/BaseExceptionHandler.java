package com.nike.phylon.exception;

import com.nike.phylon.jwt.auth.exception.JWTValidationException;
import com.nike.phylon.rest.exception.mapper.SpindleExceptionHandler;
import com.nike.phylon.rest.validation.ValidationRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Base class that all application specific {@link ExceptionHandler} must extend.
 * Please override the appSpecificHandler
 */
@ControllerAdvice
public class BaseExceptionHandler extends SpindleExceptionHandler {

//    public BaseExceptionHandler() {
//        super(new ValidationRunner()); // Pass a ValidationRunner instance to the parent constructor
//    }

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseExceptionHandler.class);
    //Added this to fix the error
//    public BaseExceptionHandler(ValidationRunner validationRunner) {
//        super(validationRunner);
//    }

    @ExceptionHandler(JWTValidationException.class)
    @ResponseBody
    public ResponseEntity handleJWTException(HttpServletRequest req, JWTValidationException ex) {
        LOGGER.error("JWTValidationException caught by handler", ex);
        return getResponseBuilder(ex.getStatusCode(), new ErrorMessage.ErrorMessageBuilder().withHttpStatus(ex.getStatusCode()).
                withMessage(ex.getMessage()).build());
    }

//    @ExceptionHandler(Exception.class)
//    @ResponseBody
//    public ResponseEntity handleControllerException(HttpServletRequest req, Exception ex) {
//        LOGGER.error("Exception caught by handler", ex);
//        return appSpecificHandler(ex);
//    }

    public ResponseEntity<ErrorMessage> appSpecificHandler(Exception t) {
        return getResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorMessage.ErrorMessageBuilder().withHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.value()).
                withMessage(t.getMessage()).build());
    }

    /**
     * Returns a Spring {@link ResponseEntity} to use when contructing a common error message format.
     *
     * @param httpStatus   the http status
     * @param errorMessage the error message
     * @return {@link ResponseEntity}
     */
    protected ResponseEntity<ErrorMessage> getResponseBuilder(HttpStatus httpStatus, ErrorMessage errorMessage) {
        return getResponseBuilder(httpStatus.value(), errorMessage);
    }

    /**
     * Returns a Spring {@link ResponseEntity} to use when constructing a common error message format.
     *
     * @param httpStatus   the http status code
     * @param errorMessage the error message
     * @return {@link ResponseEntity}
     */
    protected ResponseEntity<ErrorMessage> getResponseBuilder(int httpStatus, ErrorMessage errorMessage) {
        return ResponseEntity.status(httpStatus)
                .cacheControl(getCacheControl())
                .contentType(MediaType.APPLICATION_JSON)
                .body(errorMessage);
    }

    /**
     * Returns a Spring {@link ResponseEntity} to use when constructing a common error message format.
     *
     * @param httpStatus the http status
     * @param errorCode  the error code
     * @param message    the error message
     * @return {@link ResponseEntity}
     */
    protected ResponseEntity<ErrorMessage> getResponseBuilder(HttpStatus httpStatus, BaseErrorCode errorCode, String message) {
        return getResponseBuilder(httpStatus.value(), errorCode, message);
    }

    /**
     * Returns a Spring {@link ResponseEntity} to use when constructing a common error message format.
     *
     * @param httpStatus the http status
     * @param errorCode  the error code
     * @param message    the error message
     * @return {@link ResponseEntity}
     */
    protected ResponseEntity<ErrorMessage> getResponseBuilder(int httpStatus, BaseErrorCode errorCode, String message) {
        return ResponseEntity.status(httpStatus)
                .cacheControl(getCacheControl())
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ErrorMessage.ErrorMessageBuilder().withHttpStatus(httpStatus).withCode(errorCode.getValue()).withMessage(message).build());
    }

    /**
     * Returns a Spring {@link ResponseEntity} to use when constructing a common error message format.
     *
     * @param httpStatus  the http status
     * @param errorCode   the error code
     * @param message     the error message
     * @param errors      any field errors
     * @return {@link ResponseEntity}
     */
    protected ResponseEntity<ErrorMessage> getResponseBuilder(HttpStatus httpStatus, BaseErrorCode errorCode, String message, List<ErrorMessage.Error> errors) {
        return getResponseBuilder(httpStatus.value(), errorCode, message, errors);
    }

    /**
     * Returns a Spring {@link ResponseEntity} to use when constructing a common error message format.
     *
     * @param httpStatus  the http status
     * @param errorCode   the error code
     * @param message     the error message
     * @param errors      any field errors
     * @return {@link ResponseEntity}
     */
    protected ResponseEntity<ErrorMessage> getResponseBuilder(int httpStatus, BaseErrorCode errorCode, String message, List<ErrorMessage.Error> errors) {
        ErrorMessage errorMessage = new ErrorMessage.ErrorMessageBuilder().withHttpStatus(httpStatus).withCode(errorCode.getValue()).withMessage(message).build();

        for (ErrorMessage.Error error : errors) {
            errorMessage.addFieldError(error);
        }

        return ResponseEntity.status(httpStatus)
                .cacheControl(getCacheControl())
                .contentType(MediaType.APPLICATION_JSON)
                .body(errorMessage);
    }

    /**
     * @return currently configured cache control header
     */
    protected CacheControl getCacheControl() {
        return defaultCacheControl();
    }

    /**
     * @return default cache control header
     */
    protected CacheControl defaultCacheControl() {
        return CacheControl.maxAge(1L, TimeUnit.SECONDS);
    }
}
