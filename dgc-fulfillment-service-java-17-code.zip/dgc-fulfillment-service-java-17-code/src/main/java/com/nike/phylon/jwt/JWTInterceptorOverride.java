package com.nike.phylon.jwt;

import com.nike.phylon.jwt.auth.JWTInterceptor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Overrides the standards {@link com.nike.phylon.jwt.auth.JWTInterceptor} to log the appId of whoever is making the call
 */
@Slf4j
@Component
public class JWTInterceptorOverride extends JWTInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logRequestInfo(request);
        return super.preHandle(request, response, handler);
    }

    // Looking for appId or X-Nike-AppId as we configured app to allow use of alternate headers (appId is the alternate header).
    private void logRequestInfo(final HttpServletRequest request) {
        val appId = !StringUtils.isBlank(request.getHeader("appId")) ? request.getHeader("appId") : request.getHeader("X-Nike-AppId");
        log.info("Validating JWT for request from appId={}", appId);
    }

}
