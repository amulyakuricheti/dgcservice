package com.nike.phylon.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Preconditions;
import com.nike.phylon.ApplicationInfo;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Standard error errorMessage response object that can be used by all blueprint applications.
 *
 * @author Greg Whitaker
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorMessage implements Serializable {
    private static final long serialVersionUID = -1141414668620247457L;

    private final int httpStatus;
    private final String code;
    private final Date timestamp;
    private final String service;
    private final String requestId;
    private final String requestUrl;
    private final String message;
    private final List<Error> errors;

    public ErrorMessage(ErrorMessageBuilder errorMessageBuilder) {
        Preconditions.checkArgument(StringUtils.isNotEmpty(errorMessageBuilder.errorMessage));

        this.httpStatus = errorMessageBuilder.status;
        this.code = errorMessageBuilder.errorCode;

        if (errorMessageBuilder.errorTimestamp != null) {
            this.timestamp = (Date) errorMessageBuilder.errorTimestamp.clone();
        } else {
            this.timestamp = new Date();
        }

        this.service = errorMessageBuilder.applicationName;
        this.requestId = errorMessageBuilder.requestid;
        this.requestUrl = errorMessageBuilder.requesturl;
        this.message = errorMessageBuilder.errorMessage;
        this.errors = errorMessageBuilder.errorList;
    }

    /**
     * Adds a field level error errorMessage.
     *
     * @param error Field level error errorMessage
     */
    public void addFieldError(final Error error) {
        if (error != null) {
            errors.add(error);
        }
    }

    /**
     * Adds a field level error errorMessage.
     *
     * @param errorCode Error errorCode
     * @param field Field name
     * @param errorMessage Error errorMessage
     */
    public void addFieldError(final String errorCode, final String field, final String errorMessage) {
        Preconditions.checkArgument(StringUtils.isNotEmpty(errorCode));
        Preconditions.checkArgument(StringUtils.isNotEmpty(field));
        Preconditions.checkArgument(StringUtils.isNotEmpty(errorMessage));

        errors.add(new Error(errorCode, field, errorMessage));
    }

    /**
     * @return HTTP status errorCode
     */
    public int getHttpStatus() {
        return httpStatus;
    }

    /**
     * @return Error errorCode
     */
    public String getCode() {
        return code;
    }

    /**
     * @return Timestamp of when the error occured
     */
    public Date getTimestamp() {
        return (Date) timestamp.clone();
    }

    /**
     * @return Service name where the error originated
     */
    public String getService() {
        return service;
    }

    /**
     * @return Request identifier
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * @return Request URL
     */
    public String getRequestUrl() {
        return requestUrl;
    }

    /**
     * @return Error errorMessage
     */
    public String getMessage() {
        return message;
    }

    /**
     * @return List of any field level errorList
     */
    public List<Error> getErrors() {
        return errors;
    }

    /**
     * Field level error errorMessage.
     */
    public static class Error implements Serializable {
        private static final long serialVersionUID = 7812871254069575005L;

        private final String code;
        private final String field;
        private final String message;

        /**
         * Creates an instance.
         *
         * @param code Error errorCode
         * @param field Field name
         * @param message Error Message
         */
        public Error(final String code, final String field, final String message) {
            this.code = code;
            this.field = field;
            this.message = message;
        }

        /**
         * @return Error errorCode
         */
        public String getCode() {
            return code;
        }

        /**
         * @return Field name
         */
        public String getField() {
            return field;
        }

        /**
         * @return Error errorMessage
         */
        public String getMessage() {
            return message;
        }
    }

    /**
     * Standard error errorMessage response object builder that can be used by all blueprint applications.
     */
    public static class ErrorMessageBuilder {
        private int status;
        private String errorMessage;
        private String errorCode = null;
        private Date errorTimestamp = new Date();
        private String applicationName = ApplicationInfo.getApplicationId();
        private String requestid = null;
        private String requesturl = null;
        private List<Error> errorList = new ArrayList<>();

        /**
         * Creates a builder instance with httpStatus
         *
         * @param httpStatus httpStatus errorCode
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withHttpStatus(int httpStatus) {
            this.status = httpStatus;
            return this;
        }

        /**
         * Creates a builder instance with error errorMessage
         *
         * @param message error errorMessage
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withMessage(String message) {
            this.errorMessage = message;
            return this;
        }

        /**
         * Creates a builder instance with Error errorCode
         *
         * @param code Error errorCode
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withCode(String code) {
            this.errorCode = code;
            return this;
        }

        /**
         * Creates a builder instance with errorTimestamp
         *
         * @param timestamp errorTimestamp
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withTimestamp(Date timestamp) {
            this.errorTimestamp = Date.from(timestamp.toInstant());
            return this;
        }

        /**
         * Creates a builder instance with application name
         *
         * @param service application name
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withService(String service) {
            this.applicationName = service;
            return this;
        }

        /**
         * Creates a builder instance with request identifier
         *
         * @param requestId request identifier
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withRequestId(String requestId) {
            this.requestid = requestId;
            return this;
        }

        /**
         * Creates a builder instance with request Url
         *
         * @param requestUrl request Url
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withRequestUrl(String requestUrl) {
            this.requesturl = requestUrl;
            return this;
        }

        /**
         * Creates a builder instance with List of Errors
         *
         * @param errors List of Errors
         * @return ErrorMessageBuilder
         */
        public ErrorMessageBuilder withErrors(List<Error> errors) {
            this.errorList = errors;
            return this;
        }

        /**
         * Builds ErrorMessageinstance
         *
         * @return ErrorMessage
         */
        public ErrorMessage build() {
            return new ErrorMessage(this);
        }
    }
}
