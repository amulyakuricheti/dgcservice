#!/bin/bash

# Make the script fail if one of commands fails
set -Eeuo pipefail

helpFunction() {
   echo ""
   echo "Usage: $0 -s serviceName -a awsAccountNumber -r awsRegion  -t ecrImageTag"
   echo -e "\t-s Service Name"
   echo -e "\t-a AWS Account Number"
   echo -e "\t-r AWS Account Region"
   echo -e "\t-t ECR Image Tag"
   exit 1 # Exit script after printing help
}

while getopts "s:a:r:t:" opt
do
   case "$opt" in
      s ) serviceName="$OPTARG" ;;
      a ) awsAccountNumber="$OPTARG" ;;
      r ) awsRegion="$OPTARG" ;;
      t ) ecrImageTag="$OPTARG" ;;
      ? ) helpFunction ;; # Print helpFunction in case parameter is non-existent
   esac
done

# Print helpFunction in case parameters are empty
if [ -z "$serviceName" ] || [ -z "$awsAccountNumber" ] || [ -z "$awsRegion" ] || [ -z "$ecrImageTag" ]
then
   echo "Some or all of the parameters are empty";
   helpFunction
fi

# Check if ECR Repo exists, if not create
echo "Checking ECR for [$serviceName] repo";
# policy base64 encoded string
ecrLcPolicy=`echo 'eyJydWxlcyI6W3sicnVsZVByaW9yaXR5IjoxLCJkZXNjcmlwdGlvbiI6ImtlZXAgYXQgbGVhc3Qgb25lIGltYWdlIGxhYmVsZWQgbGF0ZXN0Iiwic2VsZWN0aW9uIjp7InRhZ1N0YXR1cyI6InRhZ2dlZCIsInRhZ1ByZWZpeExpc3QiOlsibGF0ZXN0Il0sImNvdW50VHlwZSI6ImltYWdlQ291bnRNb3JlVGhhbiIsImNvdW50TnVtYmVyIjoxfSwiYWN0aW9uIjp7InR5cGUiOiJleHBpcmUifX0seyJydWxlUHJpb3JpdHkiOjIsImRlc2NyaXB0aW9uIjoiZXhwaXJlIGFueSBvbGRlciB0aGFuIDYwIGRheXMiLCJzZWxlY3Rpb24iOnsidGFnU3RhdHVzIjoiYW55IiwiY291bnRUeXBlIjoic2luY2VJbWFnZVB1c2hlZCIsImNvdW50VW5pdCI6ImRheXMiLCJjb3VudE51bWJlciI6NjB9LCJhY3Rpb24iOnsidHlwZSI6ImV4cGlyZSJ9fV19' |base64 -d`
if ! aws ecr describe-repositories --repository-names $serviceName --region $awsRegion > /dev/null 2>&1; then
   echo "ECR Repo not found, creating [$serviceName] repo...";
   aws ecr create-repository --repository-name $serviceName --region $awsRegion > /dev/null 2>&1;
   echo "Attaching default lifecycle policy..."
   aws ecr put-lifecycle-policy --repository-name $serviceName --lifecycle-policy-text "${ecrLcPolicy}" --region $awsRegion > /dev/null 2>&1;
   echo "ECR repo with default lifecycle policy created."
elif ! aws ecr get-lifecycle-policy --repository-name $serviceName --region $awsRegion > /dev/null 2>&1; then
   echo "Repository with no policy found, attaching default 60 days expiration policy..."
   aws ecr put-lifecycle-policy --repository-name $serviceName --lifecycle-policy-text "${ecrLcPolicy}" --region $awsRegion > /dev/null 2>&1;
else
   echo "Repository and policy exist, no action needed."
fi

awsDomainSuffix=""
if [[ "$awsRegion" == "cn-"* ]]
then
   awsDomainSuffix=".cn"
fi

# Begin script in case all parameters are correct
echo "Deploying docker image [$serviceName] at AWS Account:[$awsAccountNumber] in the [$awsRegion] region with the following tag [$ecrImageTag]..."

mkdir -p {build/reports,build/test-results}
docker build . --pull --build-arg BUILD_NUMBER  --tag $serviceName
docker tag $serviceName $awsAccountNumber.dkr.ecr.$awsRegion.amazonaws.com$awsDomainSuffix/$serviceName:$ecrImageTag
docker tag $serviceName $awsAccountNumber.dkr.ecr.$awsRegion.amazonaws.com$awsDomainSuffix/$serviceName:latest
aws ecr get-login-password --region $awsRegion \
| docker login \
    --username AWS \
    --password-stdin $awsAccountNumber.dkr.ecr.$awsRegion.amazonaws.com$awsDomainSuffix
docker push $awsAccountNumber.dkr.ecr.$awsRegion.amazonaws.com$awsDomainSuffix/$serviceName:$ecrImageTag
docker push $awsAccountNumber.dkr.ecr.$awsRegion.amazonaws.com$awsDomainSuffix/$serviceName:latest
docker run --entrypoint=/bin/sh --rm -i -v "$(pwd)"/build:/tmp-build $serviceName << COMMANDS
cp -R /build/reports /tmp-build/
cp -R /build/test-results /tmp-build/
COMMANDS
