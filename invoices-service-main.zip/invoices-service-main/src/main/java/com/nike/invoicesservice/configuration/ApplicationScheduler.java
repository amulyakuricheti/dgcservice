package com.nike.invoicesservice.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;

@EnableScheduling
@Configuration
public class ApplicationScheduler {

    private static final Logger LOG = LoggerFactory.getLogger(ApplicationScheduler.class);

    @Scheduled(cron = "0 * * * * ?")
    public void printStatus() {
        LOG.info("Worker status: ACTIVE at {}", LocalDateTime.now());
    }
}
