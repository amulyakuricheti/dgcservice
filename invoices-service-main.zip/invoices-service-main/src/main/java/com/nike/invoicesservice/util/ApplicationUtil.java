package com.nike.invoicesservice.util;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Temporary class until other classes and unit tests in place, so that Pitest passes (otherwise there would be zero
 * mutations)
 */
@Slf4j
@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ApplicationUtil {

    public boolean isTest() {
        return true;
    }

}
