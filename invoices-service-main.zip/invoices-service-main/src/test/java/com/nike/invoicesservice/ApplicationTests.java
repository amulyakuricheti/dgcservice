package com.nike.invoicesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = {"local"})
@SpringBootTest(classes = Application.class)
class ApplicationTests {

	@Test
	void testApplication() {

	}

}
