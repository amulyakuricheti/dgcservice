package com.nike.invoicesservice.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ApplicationUtilTest {

    private final ApplicationUtil applicationUtil = new ApplicationUtil();

    @Test
    public void isTest() {
        assertTrue(applicationUtil.isTest());
    }

}
