package com.nike.invoicesservice;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;

@Slf4j
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = Application.class)
@ActiveProfiles("integrationTest")
@TestPropertySource(properties = {"management.server.port=0", "releaseVersion=1"})
// releaseVersion: with SpringBoot 2.0, property parsing is more strict. Need this mock value for /info endpoint.
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BaseApplicationTest extends BaseIntegrationTest {

    //Dummy Test
    @Test
    public void test() throws Exception {
        assertTrue(true);
    }

}
