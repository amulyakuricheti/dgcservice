package com.nike.invoicesservice;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.server.LocalServerPort;

/**
 * Base class which performs common
 * setup tasks for integration tests.
 */
public class BaseIntegrationTest {

    @Value("${instanceUrl:#{null}}")
    protected String instanceUrl;

    @LocalServerPort
    private int serverPort;

    @BeforeEach
    public void setup() throws Exception {
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
        RestAssured.port = serverPort;

        if (instanceUrl != null) {
            RestAssured.baseURI = instanceUrl;
        } else {
            RestAssured.requestSpecification = new RequestSpecBuilder()
                    .setBaseUri(System.getProperty("APP_HOST", "http://localhost:" + serverPort))
                    .build();
        }
    }

}
