#!/bin/bash

# Replace this by ${ECS_CONTAINER_METADATA_URI} to get container info
get_container_id() {
value=$(cat /proc/self/cpuset | sed 's/^[ \t]*//;s/[ \t]*$//')
echo "${value##*/}"
}

docker_id=$(get_container_id)
if [ -z "$docker_id" ]; then
echo "Unable to find docker id"
else
    echo "found container id : $docker_id"
fi

mkdir -p /etc/default
sudo touch /etc/default/nike_signalfx.conf
sudo chmod 777 /etc/default/nike_signalfx.conf
sudo chmod 777 /opt/splunk-otel-javaagent.jar

cat > /etc/default/nike_signalfx.conf << EOL
container_id=${docker_id}
sfx_api_key=${SPLUNK_ACCESS_TOKEN_METRICS}
sfx_api_key_tracing=${SPLUNK_ACCESS_TOKEN_TRACING}
app=${APP}
app_group=${APP_GROUP}
env=${ENV}
server_region=${SERVER_REGION}
aws_account_id=${AWS_ACCOUNT_ID}
EOL

# turn on bash's job control
set -m

# for debug use -Dotel.javaagent.debug=true \
export _JAVA_OPTIONS="-Dotel.resource.attributes=service.name=${APP},deployment.environment=${ENV} \
                      -Dotel.java.disabled.resource-providers=io.opentelemetry.sdk.extension.resources.ProcessResourceProvider \
                      -Dotel.traces.exporter=otlp \
                      -Dotel.exporter.otlp.endpoint=http://localhost:4317 \
                      -Dotel.propagators=tracecontext,b3,b3multi \
                      -Dsplunk.access.token=${SPLUNK_ACCESS_TOKEN_TRACING} \
                      -D@environment=${ENV} \
                      -Dspring.profiles.active=${ENV} \
                      -Dsplunk.metrics.enabled=true \
                      -Dsplunk.metrics.endpoint=http://localhost:9080/v2/datapoint \
                      ${APP_PROFILE_OPTIONS}"

# Start the primary process and put it in the background
java -server -jar /app/spring-boot-application.jar
