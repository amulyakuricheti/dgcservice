package com.nike.phylon;

import com.netflix.config.DynamicPropertyFactory;

/**
 * Utility that allows easy access to service metadata.
 */
public final class ApplicationInfo {

    private ApplicationInfo() {
        // Should only be accessed via static methods.
    }

    /**
     * @return Name of the application
     */
    public static String getApplicationId() {
        return DynamicPropertyFactory.getInstance().getStringProperty("info.app.name", "Undefined").get();
    }

    /**
     * @return Current version of the application
     */
    public static String getApplicationVersion() {
        return DynamicPropertyFactory.getInstance().getStringProperty("info.app.version", "Undefined").get();
    }

    /**
     * @return Name of the current environment
     */
    public static String getEnvironment() {
        return DynamicPropertyFactory.getInstance().getStringProperty("spring.profiles.active", "Undefined").get();
    }
}
