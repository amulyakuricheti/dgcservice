package com.nike.dgcfulfillmentservice.route;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.processor.PaymentGatewayInputProcessor;
import com.nike.dgcfulfillmentservice.processor.PaymentGatewayResponseProcessor;
import com.nike.dgcfulfillmentservice.processor.PaymentGatewayRestCallProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PostToPaymentGatewayRouteConfig extends RouteBuilder {


    public static final String PUT_TO_PG_ROUTE_ID = "put-request-to-pg";
    public static final String PUT_TO_PG_ROUTE_NAME = "direct:" + PUT_TO_PG_ROUTE_ID;

    private final PaymentGatewayInputProcessor paymentGatewayInputProcessor;

    private final PaymentGatewayResponseProcessor paymentGatewayResponseProcessor;

    private final PaymentGatewayRestCallProcessor paymentGatewayRestCallProcessor;

    @Override
    public void configure() throws Exception {

        from(PUT_TO_PG_ROUTE_NAME)
                .routeId(PUT_TO_PG_ROUTE_ID)
                .routeDescription("post dgc request to Payment Gateway")
                .errorHandler(noErrorHandler())
                .process(paymentGatewayInputProcessor)
                .marshal().json(JsonLibrary.Jackson)
                .log(LoggingLevel.INFO, "Before calling Payment Gateway PUT endpoint, data = ${body}")
                .log(LoggingLevel.INFO, "Before calling Payment Gateway PUT endpoint, endpoint = ${property.URL_PATH}")
                .removeHeaders("CamelServiceCall*") //to remove the previous call (pulse) headers
                .process(paymentGatewayRestCallProcessor)
                .convertBodyTo(String.class)
                .log(LoggingLevel.INFO, "Response received from PG PUT call is = ${body}, dgcRequestId=${header." + DgcPaymentConstants.DGC_REQUEST_ID + "}")
                .unmarshal().json(JsonLibrary.Jackson, PaymentGatewayResponse.class)
                .process(paymentGatewayResponseProcessor) // payment gateway response processor
                .end();

    }
}
