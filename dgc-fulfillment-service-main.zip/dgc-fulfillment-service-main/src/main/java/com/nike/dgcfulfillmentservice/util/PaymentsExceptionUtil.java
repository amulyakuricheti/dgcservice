package com.nike.dgcfulfillmentservice.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.commons.lang.exception.ExceptionUtils;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public final class PaymentsExceptionUtil {

    private PaymentsExceptionUtil() {

    }

    public static Map<String, String> getErrorDetails(Exception exception) {
        Map<String, String> errorDetails = new HashMap<>();
        String responseCode = null;
        String message = "";
        Throwable rootCause = ExceptionUtils.getRootCause(exception);
        HttpOperationFailedException httpOperationFailedException = null;
        if (exception instanceof HttpOperationFailedException) {
            httpOperationFailedException = (HttpOperationFailedException) exception;
        } else if (rootCause instanceof HttpOperationFailedException) {
            httpOperationFailedException = (HttpOperationFailedException) rootCause;
        } else {
            log.error("exception caught {}, is not a valid ,may be intermittent error", exception.toString());
        }

        if (httpOperationFailedException != null) {
            log.error("Exception caught is {}, is valid Exception got from the endpoint = {}", httpOperationFailedException.getMessage(), httpOperationFailedException.getUri());
            responseCode = String.valueOf(httpOperationFailedException.getStatusCode());
            message = String.valueOf(httpOperationFailedException.getLocalizedMessage());
        }

        errorDetails.put("ErrorCode", responseCode);
        errorDetails.put("ErrorMessage", message);

        return errorDetails;
    }
}
