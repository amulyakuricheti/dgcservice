package com.nike.dgcfulfillmentservice.model.input;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@XmlRootElement(name = "OrderRelease")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderRelease {

    @NotEmpty(message = "enterpriseCode is Empty", groups = VOMOrderReleaseCheck.class)
    @XmlAttribute(name = "EnterpriseCode")
    private String enterpriseCode;

    @NotEmpty(message = "salesOrderNo is Empty", groups = VOMOrderReleaseCheck.class)
    @XmlAttribute(name = "SalesOrderNo")
    private String salesOrderNo;

    @XmlElement(name = "Order")
    @Valid
    private Order order;

    @XmlElement(name = "OrderLine")
    @Valid
    private OrderLine orderLine;

    @XmlAttribute(name = "ReleaseNo")
    private String releaseNo;

    @XmlAttribute(name = "OrderHeaderKey")
    private String orderHeaderKey;

    @NotEmpty(message = "shipAdviceNo is Empty", groups = VOMOrderReleaseCheck.class)
    @XmlAttribute(name = "ShipAdviceNo")
    private String shipAdviceNo;


    @Data
    @XmlAccessorType(XmlAccessType.FIELD)
    public static final class Order {
        @XmlAttribute(name = "BuyerUserId")
        private String buyerUserId;

        @XmlElement(name = "PriceInfo")
        @Valid
        private PriceInfo priceInfo;

        @XmlElement(name = "PersonInfoBillTo")
        @Valid
        private PersonInfoBillTo personInfoBillTo;


        @Data
        @XmlAccessorType(XmlAccessType.FIELD)
        public static final class PriceInfo {
            @NotEmpty(message = "Currency is Empty", groups = VOMOrderReleaseCheck.class)
            @XmlAttribute(name = "Currency")
            private String currency;
        }

        @Data
        @XmlAccessorType(XmlAccessType.FIELD)
        public static final class PersonInfoBillTo {
            @NotEmpty(message = "BillToEmailId is Empty", groups = VOMOrderReleaseCheck.class)
            @XmlAttribute(name = "EMailID")
            private String emailId;
            @NotEmpty(message = "FirstName is Empty", groups = VOMOrderReleaseCheck.class)
            @XmlAttribute(name = "FirstName")
            private String firstName;
            @NotEmpty(message = "lastName is Empty", groups = VOMOrderReleaseCheck.class)
            @XmlAttribute(name = "LastName")
            private String lastName;

        }

    }

    @Data
    @XmlAccessorType(XmlAccessType.FIELD)
    public static final class OrderLine {

        @XmlAttribute(name = "OrderLineKey")
        private String orderLineKey;

        @XmlAttribute(name = "LineType")
        private String lineType;

        @NotNull(message = "orderedQty is Empty", groups = VOMOrderReleaseCheck.class)
        @XmlAttribute(name = "OrderedQty")
        private Double orderedQty;

        @XmlElement(name = "PersonInfoShipTo")
        @Valid
        private PersonInfoShipTo personInfoShipTo;

        @XmlElement(name = "Extn")
        @Valid
        private Extn extn;

        @Data
        @XmlAccessorType(XmlAccessType.FIELD)
        public static final class PersonInfoShipTo {
            @XmlAttribute(name = "Country")
            private String country;
            @NotEmpty(message = "ShipTOEmailId is Empty", groups = VOMOrderReleaseCheck.class)
            @XmlAttribute(name = "EMailID")
            private String emailId;
        }

        @Data
        @XmlAccessorType(XmlAccessType.FIELD)
        public static final class Extn {

            @NotNull(message = "ExtnDenomination is Empty", groups = VOMOrderReleaseCheck.class)
            @XmlAttribute(name = "ExtnDenomination")
            private Double extnDenomination;
        }
    }

}

