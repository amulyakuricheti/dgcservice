package com.nike.dgcfulfillmentservice.processor;

import com.nike.hades.nspkafkautil.producer.PublishToKafkaProducer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * Use this processor to build invoice update message to be sent to NSP.
 */
@Slf4j
@Component("NSPPostInvoiceEventProcessor")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class NSPPostInvoiceEventProcessor implements Processor {

    private final PublishToKafkaProducer kafkaProducer;

    @Override
    public void process(Exchange exchange) throws Exception {
        log.info("NSPPostInvoiceEventProcessor action=processNSP status=NSP process started - {}", exchange.getIn().getBody());
        publishOrderEventToNsp(exchange);
        log.info("NSPPostInvoiceEventProcessor action=processNSP status=NSP process completed");
    }

    private void publishOrderEventToNsp(Exchange exchange) {
        String message = exchange.getIn().getBody(String.class);
        kafkaProducer.publishDataToKafka(message.toString(), "", "");
        log.info("event=NSPPostPayloadProcessor action=processNSP status-Successfully published data to Kafka end point - {}", message);

    }

}
