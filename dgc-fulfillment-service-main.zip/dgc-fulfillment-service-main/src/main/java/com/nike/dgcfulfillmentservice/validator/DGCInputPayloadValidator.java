package com.nike.dgcfulfillmentservice.validator;


import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.model.input.VOMOrderReleaseCheck;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Set;

@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class DGCInputPayloadValidator {

    private final Validator validator;

    public boolean isIncomingVOMInputValid(OrderRelease request) {
        return validateAsyncDgcRequest(request).isEmpty();
    }

    private Set<ConstraintViolation<OrderRelease>> validateAsyncDgcRequest(OrderRelease orderRelease) {
        return validator.validate(orderRelease, VOMOrderReleaseCheck.class);
    }

}
