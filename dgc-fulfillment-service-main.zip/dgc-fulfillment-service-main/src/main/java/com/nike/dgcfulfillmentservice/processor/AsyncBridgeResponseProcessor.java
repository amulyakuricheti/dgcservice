package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.service.AsyncBridgeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class AsyncBridgeResponseProcessor implements Processor {

    private final AsyncBridgeService asyncBridgeService;

    @Override
    public void process(Exchange exchange) throws Exception {

        Long startTime = System.currentTimeMillis();
        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        asyncBridgeService.updateTransactionWithCompleted(dgcRequestId);
        log.info("successfully updated the transaction with status completed for the dgcRequestId = {}", dgcRequestId);
        log.info("time taken to process AsyncBridge Response, AsyncResponseProcessStartTime={}ms, AsyncResponseProcessEndTime = {}ms, AsyncResponseTimeTaken={}ms", startTime, System.currentTimeMillis(), (System.currentTimeMillis() - startTime));

    }
}
