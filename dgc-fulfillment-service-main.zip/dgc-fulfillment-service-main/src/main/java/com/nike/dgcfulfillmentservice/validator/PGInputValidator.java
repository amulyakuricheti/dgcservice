package com.nike.dgcfulfillmentservice.validator;

import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayDGCInputCheck;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Set;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PGInputValidator {

    private final Validator validator;

    public boolean isPGPutInputValid(PaymentGatewayInput pgInputRequest) {
        return this.validateAsyncRequestToPG(pgInputRequest).isEmpty();
    }

    private Set<ConstraintViolation<PaymentGatewayInput>> validateAsyncRequestToPG(PaymentGatewayInput pgInputRequest) {
        return validator.validate(pgInputRequest, PaymentGatewayDGCInputCheck.class);
    }


}
