package com.nike.dgcfulfillmentservice.route;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.processor.AsyncBridgeResponseProcessor;
import com.nike.dgcfulfillmentservice.processor.NSPPostInvoiceEventProcessor;
import com.nike.dgcfulfillmentservice.processor.PostToAsyncBridgeProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;


@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PostToAsyncBridgeRouteConfig extends RouteBuilder {

    public static final String POST_TO_PAC_ROUTE_ID = "post-to-pac-route-id";

    public static final String POST_TO_PAC_ROUTE_NAME = "direct:" + POST_TO_PAC_ROUTE_ID;

    private final PostToAsyncBridgeProcessor postToAsyncBridgeProcessor;

    private final AsyncBridgeResponseProcessor asyncBridgeResponseProcessor;

    private final NSPPostInvoiceEventProcessor nspPostInvoiceEventProcessor;

    @Override
    public void configure() throws Exception {

        from(POST_TO_PAC_ROUTE_NAME)
                .routeId(POST_TO_PAC_ROUTE_ID)
                .routeDescription("DGC details posting to asyncBridge")
                .errorHandler(noErrorHandler())
                .process(postToAsyncBridgeProcessor)
                .marshal().jacksonxml(true)
                //Posting to Async bridge endpoint for Order status
                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.POST))
                .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_XML_VALUE))
                .log(LoggingLevel.INFO, "Trace Headers -> X-B3-TraceId = ${header.X-B3-TraceId}, X-B3-SpanId = ${header.X-B3-SpanId}, "
                        + "X-B3-ParentSpanId = ${header.X-B3-ParentSpanId}")
                .log(LoggingLevel.INFO, "Posting Dgc Details to NSP for dgcRequestId=${header." + DgcPaymentConstants.DGC_REQUEST_ID + "}")
                .process(nspPostInvoiceEventProcessor)
                .process(asyncBridgeResponseProcessor)
                .end();

    }
}
