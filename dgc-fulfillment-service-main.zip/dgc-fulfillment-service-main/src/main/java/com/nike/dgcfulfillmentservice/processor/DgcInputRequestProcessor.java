package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.service.DgcPaymentsService;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import com.nike.dgcfulfillmentservice.validator.DGCInputPayloadValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.UUID;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class DgcInputRequestProcessor implements Processor {

    private final DgcPaymentsService dgcPaymentsService;

    private final DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;

    private final DGCInputPayloadValidator dgcInputPayloadValidator;

    @Override
    public void process(Exchange exchange) throws Exception {
        OrderRelease orderRelease = exchange.getIn().getBody(OrderRelease.class);
        log.info("DgcInputRequestProcessor: OrderRelease payload with minimal details is:{}", orderRelease);
        String traceId = getTraceId();
        exchange.getIn().setHeader("X-B3-TraceId", traceId);
        log.info("DgcInputRequestProcessor: traceId is:{}", traceId);
        if (this.isOrderReleaseValid(orderRelease)) {
            String dgcRequestId = dgcPaymentsWrkrUtil.getDgcRequestId(orderRelease.getOrderLine().getOrderLineKey(), orderRelease.getShipAdviceNo());

            String accountNo = fetchAccountNo(orderRelease.getEnterpriseCode());
            log.info("DGCAccountNo ::{}, for the enterPriseCode :: {}", accountNo, orderRelease.getEnterpriseCode());
            DgcRequest dgcRequest = dgcPaymentsService.saveGCRequest(orderRelease, accountNo, dgcRequestId);
            log.info("DgcRequestId and transactionId sending to downstream are {}, {}", dgcRequestId, dgcRequest.getTransactionId());

            exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, dgcRequestId);
            exchange.setProperty(DgcPaymentConstants.DGC_REQUEST_SHIP_ADVICE_NO, dgcRequest.getShipAdviceNo());
            exchange.setProperty(DgcPaymentConstants.DGC_REQUEST_ENTERPRISE_CODE, dgcRequest.getEnterpriseCode());
            exchange.setProperty(DgcPaymentConstants.TRANSACTION_ID, dgcRequest.getTransactionId());
            exchange.setProperty(DgcPaymentConstants.TRANSACTION_STATUS, dgcRequest.getRequestStatus());
        } else {
            throw new BadRequestException(String.format("Invalid Dgc request payload received from VOM, orderRelease payload=%s", orderRelease));
        }
    }

    private String fetchAccountNo(String enterpriseCode) {
        if (DgcPaymentConstants.ENTERPRISECODE_US.equalsIgnoreCase(enterpriseCode)) {
           return DgcPaymentConstants.DGC_RULE_ACCOUNTNAME_US;
        } else if (DgcPaymentConstants.ENTERPRISECODE_JP.equalsIgnoreCase(enterpriseCode)) {
            return DgcPaymentConstants.DGC_RULE_ACCOUNTNAME_JP;
        } else {
            log.info("Unable to fetch Account number for this enterpriseCode {}", enterpriseCode);
            throw new RuntimeException("Unable to fetch Account number for the enterpriseCode");
        }
    }

    private boolean isOrderReleaseValid(OrderRelease orderRelease) {
        return dgcInputPayloadValidator.isIncomingVOMInputValid(orderRelease);
    }

    private String getTraceId() {
        return UUID.randomUUID().toString();
    }
}
