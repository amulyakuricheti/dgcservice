package com.nike.dgcfulfillmentservice.service;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayInput;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.repository.DgcRequestsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PaymentGatewayService {

    private final DgcPaymentsService dgcPaymentsService;

    private final DgcRequestsRepository dgcRequestsRepository;

    public PaymentGatewayInput preparePaymentGatewayRequest(OrderRelease orderRelease, String accountNo) {

        PaymentGatewayInput.Request.SenderInfo.Name name = new PaymentGatewayInput.Request.SenderInfo.Name();
        name.setFirstName(orderRelease.getOrder().getPersonInfoBillTo().getFirstName());
        name.setLastName(orderRelease.getOrder().getPersonInfoBillTo().getLastName());

        PaymentGatewayInput.Request pgRequest = PaymentGatewayInput.Request.builder()
                .amount(orderRelease.getOrderLine().getExtn().getExtnDenomination())
                .currency(orderRelease.getOrder().getPriceInfo().getCurrency())
                .certificateProfileId(orderRelease.getOrder().getBuyerUserId())
                .referenceCode(orderRelease.getSalesOrderNo())
                .account(accountNo)
                .build();

        PaymentGatewayInput paymentGatewayInput = this.buildPGRequest(pgRequest);
        this.addContactInfo(orderRelease.getOrder().getPersonInfoBillTo().getEmailId(), orderRelease.getOrderLine().getPersonInfoShipTo().getEmailId(), paymentGatewayInput);

        paymentGatewayInput.getRequest().getSenderInfo().setName(name);

        return paymentGatewayInput;
    }

    public PaymentGatewayInput preparePaymentGatewayRequest(String dgcRequestId) throws Exception {
        Optional<DgcRequest> optionalDgcRequest = dgcPaymentsService.getDgcRequestByDgcRequestId(dgcRequestId);
        PaymentGatewayInput pgInput = null;
        if (optionalDgcRequest.isPresent()) {
            DgcRequest dgcRequest = optionalDgcRequest.get();
            PaymentGatewayInput.Request.SenderInfo.Name name = new PaymentGatewayInput.Request.SenderInfo.Name();
            name.setFirstName(dgcRequest.getSenderFirstName());
            name.setLastName(dgcRequest.getSenderLastName());

            PaymentGatewayInput.Request pgInputRequest = PaymentGatewayInput.Request.builder()
                    .amount(dgcRequest.getRequestAmount())
                    .currency(dgcRequest.getCurrency())
                    .certificateProfileId(dgcRequest.getCertificateProfileId())
                    .referenceCode(dgcRequest.getSalesOrderNumber())
                    .account(dgcRequest.getGiftCardAccountNumber())
                    .build();

            pgInput = this.buildPGRequest(pgInputRequest);
            this.addContactInfo(dgcRequest.getSenderEmail(), dgcRequest.getRecipientEmail(), pgInput);

            pgInput.getRequest().getSenderInfo().setName(name);
        }
        return pgInput;
    }


    public void updateWithPGCompletedResponse(String dgcRequestId, PaymentGatewayResponse paymentGatewayResponse) throws Exception {
        Optional<DgcRequest> optionalDgcRequest = dgcPaymentsService.getDgcRequestByDgcRequestId(dgcRequestId);

        if (optionalDgcRequest.isPresent()) {
            DgcRequest dgcRequest = optionalDgcRequest.get();
            // if the requestSuccess is false
            if (!paymentGatewayResponse.getResponse().getRequestSuccess()) {
                log.warn("paymentGateway Get response received with ErrorCode = {} for dgcRequestId = {}", paymentGatewayResponse.getResponse().getErrorCode(), dgcRequestId);
                dgcRequest.setBusinessErrorCode(paymentGatewayResponse.getResponse().getErrorCode());
                dgcRequest.setBusinessErrorMessage(paymentGatewayResponse.getResponse().getErrorMessage());
            }
            dgcRequest.setRequestStatus(TransactionStatusConstants.STATUS_PROCESSED);
            dgcRequest.setEta(TransactionStatusConstants.PROCESSED_ETA_ZERO);
            dgcRequest.setLastModifiedDateTime(OffsetDateTime.now());
            dgcRequest.setPgGiftCardResultsUrl(paymentGatewayResponse.getResponse().getLinks().getSelf().getRef());
            dgcRequest.setRequestSuccess(paymentGatewayResponse.getResponse().getRequestSuccess());
            if (paymentGatewayResponse.getResponse().getExpirationDate() != null) {
                dgcRequest.setExpirationDate(OffsetDateTime.parse(paymentGatewayResponse.getResponse().getExpirationDate()));
            }

            dgcRequest.setTtl(OffsetDateTime.now().plusDays(DgcPaymentConstants.RETENTION_DAYS).toEpochSecond());
            dgcRequestsRepository.updateTransaction(dgcRequest);
            log.info("DGC PG response Details updated with PROCESSED status in DB for dgcRequestId={} with details: {}", dgcRequestId, dgcRequest.toString());
        } else {
            throw new RuntimeException(String.format("Unable to update PROCESSED status for the dgcRequestId=%s with PG get response.", dgcRequestId));
        }

    }

    public void updateWithPGPendingResponse(String dgcRequestId, PaymentGatewayResponse paymentGatewayResponse) throws Exception {
        log.info("Payment request is in processing status for the dgcRequestId = {}", dgcRequestId);
        Optional<DgcRequest> optionalDgcRequest = dgcPaymentsService.getDgcRequestByDgcRequestId(dgcRequestId);
        if (optionalDgcRequest.isPresent()) {
            DgcRequest dgcRequest = optionalDgcRequest.get();
            dgcRequest.setEta(paymentGatewayResponse.getEta());
            dgcRequest.setPgGetUrl(paymentGatewayResponse.getLinks().getSelf().getRef());
            dgcRequest.setRequestStatus(TransactionStatusConstants.STATUS_PROCESSING);
            dgcRequest.setLastModifiedDateTime(OffsetDateTime.now());
            dgcRequestsRepository.updateTransaction(dgcRequest);
            log.info("transaction successfully updated with PROCESSING status for dgcRequestId={} with details={}", dgcRequestId, dgcRequest.toString());
        } else {
            throw new RuntimeException(String.format("Unable to update PROCESSING status for the dgcRequestId=%s", dgcRequestId));
        }

    }


    public void updatePaymentTransactionWithError(String dgcRequestId, String errorCode, String errorMessage) {
        dgcPaymentsService.updateTransactionToError(dgcRequestId, errorCode, errorMessage);
    }


    private PaymentGatewayInput buildPGRequest(PaymentGatewayInput.Request pgRequest) {
        String priority = DgcPaymentConstants.PRIORITY_NORMAL;
        PaymentGatewayInput pgInputRequest = PaymentGatewayInput.builder()
                .priority(priority)
                .request(pgRequest)
                .build();

        return pgInputRequest;
    }


    public void addContactInfo(String senderContactEmail, String recipientContactEmail, PaymentGatewayInput paymentGatewayInput) {

        PaymentGatewayInput.Request.RecipientInfo recipientInfo = new PaymentGatewayInput.Request.RecipientInfo();
        PaymentGatewayInput.Request.SenderInfo senderInfo = new PaymentGatewayInput.Request.SenderInfo();
        PaymentGatewayInput.Request.RecipientInfo.ContactInfo recipientContactInfo = new PaymentGatewayInput.Request.RecipientInfo.ContactInfo();
        PaymentGatewayInput.Request.SenderInfo.ContactInfo senderContactInfo = new PaymentGatewayInput.Request.SenderInfo.ContactInfo();

        senderContactInfo.setEmail(senderContactEmail);
        recipientContactInfo.setEmail(recipientContactEmail);

        senderInfo.setContactInfo(senderContactInfo);
        recipientInfo.setContactInfo(recipientContactInfo);
        paymentGatewayInput.getRequest().setSenderInfo(senderInfo);
        paymentGatewayInput.getRequest().setRecipientInfo(recipientInfo);


    }
}
