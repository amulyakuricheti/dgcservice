package com.nike.dgcfulfillmentservice.config.nsp;

import com.nike.om.nsp.routes.NspRouteBuilder;
import com.nike.om.nsp.utils.NspKafkaConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.kafka.KafkaConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import static com.nike.dgcfulfillmentservice.route.IngressDgcReleaseEventRouteConfig.INGRESS_DGC_RELEASE_EVENT_ROUTE_ID;
@Configuration
@Slf4j
@RequiredArgsConstructor(onConstructor = @__({@Autowired}))
public class NspConsumerConfiguration {

    private final NspRouteBuilder nspRouteBuilder;
    private final CamelContext context;
    private final NspKafkaConfig nspKafkaConfig;

    @Value("${sterling.dgcpayments.topic}")
    private String nspDgcConsumerTopic;

    @Value("${sterling.dgcpayments.broker}")
    private String nspDgcFulfillmentBroker;

    @Bean("dgcfulfillmentSterlingNspConsumerConfig")
    public KafkaConfiguration paymentStatusNspConsumerConfig() {
        return nspKafkaConfig.getConsumerConfigNsp(nspDgcFulfillmentBroker, nspDgcConsumerTopic);
    }

    @PostConstruct
    public void addNspRoutes() throws Exception {
        final RouteBuilder consumeDGCFulfilmentNspRouteBuilder = nspRouteBuilder.nspConsumerRouteBuilder(nspDgcConsumerTopic, "dgcfulfillmentSterlingNspConsumerConfig", INGRESS_DGC_RELEASE_EVENT_ROUTE_ID);
        context.addRoutes(consumeDGCFulfilmentNspRouteBuilder);

    }
}
