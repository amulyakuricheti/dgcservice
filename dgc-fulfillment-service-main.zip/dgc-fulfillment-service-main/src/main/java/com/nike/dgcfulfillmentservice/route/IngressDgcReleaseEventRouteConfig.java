package com.nike.dgcfulfillmentservice.route;

import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.exception.InternalToDGCPaymentWrkrException;
import com.nike.dgcfulfillmentservice.exception.PaymentGatewayPUTException;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.processor.DgcInputRequestProcessor;
import com.nike.dgcfulfillmentservice.processor.ExceptionLoggingProcessor;
import com.nike.dgcfulfillmentservice.processor.PGPutCallExceptionProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.converter.jaxb.JaxbDataFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;

import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.SQS_SCHEMA;
import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.SQS_CLIENT_SUFFIX;
import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.TRANSACTION_STATUS;
import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.DGC_REQUEST_ENTERPRISE_CODE;
import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.DGC_REQUEST_ID;
import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.DGC_REQUEST_SHIP_ADVICE_NO;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class IngressDgcReleaseEventRouteConfig extends RouteBuilder {

    public static final String INGRESS_DGC_RELEASE_EVENT_ROUTE_ID = "dgc-release-event-in-route";
    public static final String INGRESS_DGC_RELEASE_EVENT_ROUTE_NAME = "direct:" + INGRESS_DGC_RELEASE_EVENT_ROUTE_ID;

    private final DgcInputRequestProcessor dgcInputRequestProcessor;

    @Value("${camel.redeliveryDelayMs}")
    private long redeliverDelay;

    @Value("${camel.maxRedeliveryCount}")
    private int maxRedeliveryCount;

    @Value("${sqs.vom.dgc.order_release.dlq}")
    private String asyncPaymentsInputDLQName;

    @Override
    public void configure() throws Exception {

        onException(PaymentGatewayPUTException.class)
                .handled(true)
                .bean(ExceptionLoggingProcessor.class)
                .bean(PGPutCallExceptionProcessor.class)
                .stop();

        onException(InternalToDGCPaymentWrkrException.class, BadRequestException.class)
                .handled(true)
                .useOriginalMessage()
                .bean(ExceptionLoggingProcessor.class)
                .to(SQS_SCHEMA + asyncPaymentsInputDLQName + SQS_CLIENT_SUFFIX)
                .end();

        onException(Exception.class)
                .useOriginalMessage()
                .bean(ExceptionLoggingProcessor.class)
                .maximumRedeliveries(maxRedeliveryCount)
                .redeliveryDelay(redeliverDelay)
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .retriesExhaustedLogLevel(LoggingLevel.ERROR)
                .asyncDelayedRedelivery();

        // XML Data Format
        JaxbDataFormat jaxbDataFormat = new JaxbDataFormat();
        JAXBContext con = JAXBContext.newInstance(OrderRelease.class);
        jaxbDataFormat.setContext(con);

        from(INGRESS_DGC_RELEASE_EVENT_ROUTE_NAME)
                .routeId(INGRESS_DGC_RELEASE_EVENT_ROUTE_ID)
                .routeDescription("receive the dgc input and send to pg put route")
                .streamCaching()
                .convertBodyTo(String.class, "UTF-8")
                .log(LoggingLevel.INFO, "IngressDgcReleaseEventRoute: OrderRelease Payload has received, orderRelease=${body}")
                .unmarshal(jaxbDataFormat)
                .process(dgcInputRequestProcessor)
                .log(LoggingLevel.INFO, "Dgc request received with status=${property." + TRANSACTION_STATUS + "} and dgcRequestId=${header." + DGC_REQUEST_ID + "}, shipAdviceNo=${property." + DGC_REQUEST_SHIP_ADVICE_NO + "}, enterpriseCode=${property." + DGC_REQUEST_ENTERPRISE_CODE + "}")
                .choice()
                .when(exchangeProperty(TRANSACTION_STATUS).isEqualTo(TransactionStatusConstants.STATUS_PROCESSED))
                .log(LoggingLevel.INFO, "Dgc Request has already been processed, Hence ignoring this request with dgcRequestId=${header." + DGC_REQUEST_ID + "}, shipAdviceNo=${property." + DGC_REQUEST_SHIP_ADVICE_NO + "}, enterpriseCode=${property." + DGC_REQUEST_ENTERPRISE_CODE + "}")
//                .to(NotifyGetPGUpdateRouteConfig.PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_NAME)
                .when(exchangeProperty(TRANSACTION_STATUS).isEqualTo(TransactionStatusConstants.STATUS_COMPLETED))
                .log(LoggingLevel.INFO, "Dgc Request has already been completed, Hence ignoring this request with dgcRequestId=${header." + DGC_REQUEST_ID + "}, shipAdviceNo=${property." + DGC_REQUEST_SHIP_ADVICE_NO + "}, enterpriseCode=${property." + DGC_REQUEST_ENTERPRISE_CODE + "}")
//                .to(NotifyGetPGUpdateRouteConfig.PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_NAME)
                .when(exchangeProperty(TRANSACTION_STATUS).isEqualTo(TransactionStatusConstants.STATUS_PROCESSING))
                .log(LoggingLevel.INFO, "DGC Request is already in processing status,hence ignoring this request with dgcRequestId=${header." + DGC_REQUEST_ID + "}, shipAdviceNo=${property." + DGC_REQUEST_SHIP_ADVICE_NO + "}, enterpriseCode=${property." + DGC_REQUEST_ENTERPRISE_CODE + "}")
                .otherwise()
                .to(PostToPaymentGatewayRouteConfig.PUT_TO_PG_ROUTE_NAME)
                .to(NotifyGetPGUpdateRouteConfig.PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_NAME)
                .end();
    }
}
