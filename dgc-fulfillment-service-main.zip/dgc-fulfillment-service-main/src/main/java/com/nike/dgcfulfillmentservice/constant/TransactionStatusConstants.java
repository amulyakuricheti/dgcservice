package com.nike.dgcfulfillmentservice.constant;

public final class TransactionStatusConstants {

    private TransactionStatusConstants() {
    }

    public static final String STATUS_NEW = "NEW";
    public static final String STATUS_PROCESSING = "PROCESSING";
    public static final String STATUS_PROCESSED = "PROCESSED";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_RETRY = "RETRY";
    public static final String STATUS_ERROR = "ERROR";

    public static final int PROCESSED_ETA_ZERO = 0;

}
