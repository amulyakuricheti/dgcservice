package com.nike.dgcfulfillmentservice.exception;

/**
Exception class to capture the conflict in payment requests posted from PG
 */
public class PaymentConflictException extends RuntimeException {

    public PaymentConflictException(String msg) {
        super(msg);
    }
}
