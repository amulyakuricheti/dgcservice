package com.nike.dgcfulfillmentservice.route;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.processor.PublishMsgToGetPGUpdateProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class NotifyGetPGUpdateRouteConfig extends RouteBuilder {

    public static final String PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_ID = "send-message-to-get-route";
    public static final String PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_NAME = "direct:" + PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_ID;

    private final PublishMsgToGetPGUpdateProcessor publishMsgToGetPGUpdateProcessor;

    @Override
    public void configure() throws Exception {

        from(PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_NAME)
                .routeId(PUBLISH_MESSAGE_TO_GET_PAYMENT_ROUTE_ID)
                .routeDescription("Publish message to SQS for further processing")
                .errorHandler(noErrorHandler())
                .log(LoggingLevel.INFO, "Request received to send notification to Payment Gateway GET endpoint route, dgcRequestId = ${header." + DgcPaymentConstants.DGC_REQUEST_ID + "}")
                .process(publishMsgToGetPGUpdateProcessor)
                .end();
    }
}
