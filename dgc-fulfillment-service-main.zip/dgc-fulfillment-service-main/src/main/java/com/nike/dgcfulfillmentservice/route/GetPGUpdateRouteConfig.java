package com.nike.dgcfulfillmentservice.route;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.processor.InputToPGGetSqsMessageProcessor;
import com.nike.dgcfulfillmentservice.processor.PaymentGatewayResponseProcessor;
import lombok.RequiredArgsConstructor;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.IS_PG_DGC_RESULTS_ENDPOINT;

@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class GetPGUpdateRouteConfig extends RouteBuilder {

    public static final String GET_PG_UPDATE_ROUTE_ID = "get-from-pg-route-id";
    public static final String PG_GET_CALL_ROUTE_NAME = "direct:" + GET_PG_UPDATE_ROUTE_ID;

    private final InputToPGGetSqsMessageProcessor inputToPGGetSqsMessageProcessor;

    private final PaymentGatewayResponseProcessor paymentGatewayResponseProcessor;


    @Override
    public void configure() throws Exception {

        from(PG_GET_CALL_ROUTE_NAME)
                .routeId(GET_PG_UPDATE_ROUTE_ID)
                .routeDescription("this is route will call PG GET endpoint either jobs or result endpoint based on the url received in the sqs message")
                .process(inputToPGGetSqsMessageProcessor)
                .convertBodyTo(String.class)
                .choice()
                .when(exchangeProperty(IS_PG_DGC_RESULTS_ENDPOINT))
                .unmarshal().json(JsonLibrary.Jackson, PaymentGatewayResponse.Response.class)
                .endChoice()
                .otherwise()
                .unmarshal().json(JsonLibrary.Jackson, PaymentGatewayResponse.class)
                .end()
                .process(paymentGatewayResponseProcessor)
                .log(LoggingLevel.INFO, "Received response from PG GET call for dgcRequestId=${header." + DgcPaymentConstants.DGC_REQUEST_ID + "}")
                .end();
    }
}
