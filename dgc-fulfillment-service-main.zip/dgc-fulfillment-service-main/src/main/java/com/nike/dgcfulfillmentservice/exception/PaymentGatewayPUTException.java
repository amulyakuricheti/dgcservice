package com.nike.dgcfulfillmentservice.exception;

public class PaymentGatewayPUTException extends RuntimeException {

//    public PaymentGatewayPUTException(String errorMessage) {
//        super(errorMessage);
//    }

    public PaymentGatewayPUTException(Exception exception) {
        super(exception);
    }
}
