package com.nike.dgcfulfillmentservice.service;

import com.nike.dgcfulfillmentservice.model.asyncbridge.ExtnNikeGiftcardInfo;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.validator.AsyncBridgeInputValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Slf4j
@Service
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class AsyncBridgeService {

    private final DgcPaymentsService dgcPaymentsService;

    private final AsyncBridgeInputValidator asyncBridgeInputValidator;

    public boolean validate(ExtnNikeGiftcardInfo asyncResponse) {
        boolean isValid = asyncBridgeInputValidator.isAsyncResponseValid(asyncResponse);
        return isValid;
    }

    public ExtnNikeGiftcardInfo prepareAsyncPaymentResponse(String dgcRequestId, PaymentGatewayResponse.Response paymentGatewayResponse) throws Exception {
        log.info("PG Completed response received for dgcRequestId={}", dgcRequestId);
        Optional<DgcRequest> optionalDgcRequest = dgcPaymentsService.getDgcRequestByDgcRequestId(dgcRequestId);
        if (optionalDgcRequest.isPresent()) {
            ExtnNikeGiftcardInfo asyncResponse = this.buildAsyncPaymentResponse(optionalDgcRequest.get(), paymentGatewayResponse);
            log.info("Generated Async bridge Response payload for dgcRequestId={}, shipAdviceNo={}, enterpriseCode={}", dgcRequestId, optionalDgcRequest.get().getShipAdviceNo(), optionalDgcRequest.get().getEnterpriseCode());
            return asyncResponse;
        } else {
            throw new RuntimeException(String.format("No DB record found for the dgcRequestId=%s", dgcRequestId));
        }
    }

    public ExtnNikeGiftcardInfo buildAsyncPaymentResponse(DgcRequest dgcRequest, PaymentGatewayResponse.Response paymentGatewayResponse) throws Exception {
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = new ExtnNikeGiftcardInfo();

        extnNikeGiftcardInfo.setExtnAuthCode(paymentGatewayResponse.getRequestToken());
        extnNikeGiftcardInfo.setExtnTokenCode(paymentGatewayResponse.getRequestToken());

        if (paymentGatewayResponse.getDecision() != null) {
            extnNikeGiftcardInfo.setExtnDecision(paymentGatewayResponse.getDecision());
        } else {
            extnNikeGiftcardInfo.setExtnDecision(paymentGatewayResponse.getRequestSuccess() ? "ACCEPT" : "ERROR");
        }
        extnNikeGiftcardInfo.setExtnExpirationDate(paymentGatewayResponse.getExpirationDate());
        extnNikeGiftcardInfo.setExtnGiftcardNumber(paymentGatewayResponse.getAccountNumber());
        extnNikeGiftcardInfo.setExtnSuccessStatus(paymentGatewayResponse.getRequestSuccess());
        extnNikeGiftcardInfo.setExtnPin(paymentGatewayResponse.getPin());
        extnNikeGiftcardInfo.setExtnStatus(paymentGatewayResponse.getRequestSuccess() ? "valid" : "invalid");

        extnNikeGiftcardInfo.setOrderHeaderKey(dgcRequest.getOrderHeaderKey());
        extnNikeGiftcardInfo.setExtnOrderHeaderKey(dgcRequest.getOrderHeaderKey());
        extnNikeGiftcardInfo.setIsDGC(true);
        extnNikeGiftcardInfo.setExtnOrderLineKey(dgcRequest.getOrderLineKey());
        extnNikeGiftcardInfo.setOrderLineKey(dgcRequest.getOrderLineKey());

        extnNikeGiftcardInfo.setReleaseNo(dgcRequest.getReleaseNo());
        extnNikeGiftcardInfo.setQuantity(dgcRequest.getQuantity());

        return extnNikeGiftcardInfo;

    }


    public void updateTransactionWithCompleted(String dgcRequestId) {
        dgcPaymentsService.updateTransactionWithCompleted(dgcRequestId);
    }

    public void updateTransactionWithError(String dgcRequestId, String errorCode, String errorMessage) {
        dgcPaymentsService.updateTransactionToError(dgcRequestId, errorCode, errorMessage);
    }

}
