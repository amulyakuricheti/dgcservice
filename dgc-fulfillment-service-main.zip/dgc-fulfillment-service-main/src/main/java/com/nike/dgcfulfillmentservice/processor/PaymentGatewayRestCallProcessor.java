package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.pace.generator.tokenclient.interfaces.TokenClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestOperations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpMethod;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PaymentGatewayRestCallProcessor implements Processor {

    @Value("${oscar.service-scopes.payment-gift_certificates-v1.PUT}")
    private String giftCertificatePutEndpointScope;

    @Qualifier("restTemplateWithLoadBalancer")
    private final RestOperations restTemplate;

    @Autowired
    private TokenClient tokenClient;

    @Override
    public void process(Exchange exchange) throws Exception {
        String payload = exchange.getIn().getBody(String.class);
        String url = exchange.getIn().getHeader(DgcPaymentConstants.URL_PATH, String.class);

        log.info("Calling PG payload in private link: {} and url: {}", payload, url);
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.set(DgcPaymentConstants.X_NIKE_APP_ID, DgcPaymentConstants.ASYNCPAYMENTS);
        headers.set(HttpHeaders.AUTHORIZATION, "Bearer " + generateToken(giftCertificatePutEndpointScope));

        HttpEntity<String> requestEntity = new HttpEntity<>(payload, headers);
        String responseBody = null;

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);
            responseBody = response.getBody();
            log.error("Response body: {}", responseBody);
        } catch (Exception e) {
            log.error("Failed calling endpoint with private link exception: {}", e.getMessage());
        }

        exchange.getIn().setBody(responseBody);
    }


    public String generateToken(String scope) {
        try {
            return tokenClient.getAccessToken(scope);
        } catch (Exception ex) {
            log.error("Attempting to generate oscar token for headerScope: {} has failed", scope, ex);
            throw new RuntimeException("OSCAR Token Error: Error trying to generate token for headerScope: " + scope, ex);
        }
    }
}
