package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.service.DgcPaymentsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class SchedulerProcessor implements Processor {

    private final DgcPaymentsService dgcPaymentsService;

    public List<DgcRequest> getRecordsToRetry() throws Exception {
        Long startTime = System.currentTimeMillis();
        List<DgcRequest> dgcRequests = dgcPaymentsService.getRetryTransactions();
        log.info("time taken to retry record from DB, retryPutTimeTaken = {}ms", (System.currentTimeMillis() - startTime));
        log.info("Records received to retry count = {}", dgcRequests.size());
        return dgcRequests;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        DgcRequest dgcRequest = exchange.getIn().getBody(DgcRequest.class);
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, dgcRequest.getDgcRequestId());
        exchange.setProperty(DgcPaymentConstants.TRANSACTION_ID, dgcRequest.getTransactionId()); //to form PG URL
        exchange.getIn().setBody(dgcRequest.getDgcRequestId());
    }
}
