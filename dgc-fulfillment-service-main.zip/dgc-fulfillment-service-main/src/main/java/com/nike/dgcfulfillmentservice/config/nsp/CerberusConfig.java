package com.nike.dgcfulfillmentservice.config.nsp;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nike.cerberus.client.CerberusClient;
import com.nike.cerberus.springboot.CerberusClientSpringBootConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.Map;

@Configuration
@Slf4j
@Import(CerberusClientSpringBootConfiguration.class)
public class CerberusConfig {

    private String sdbPath;
    private CerberusClient cerberusClient;

    public CerberusConfig(@Value(("${cerberus.config.path}")) String sdbPath, @Autowired CerberusClient cerberusClient) {
        this.sdbPath = sdbPath;
        this.cerberusClient = cerberusClient;
    }

    @Bean
    @Qualifier("CerberusSecrets")
    public Map<String, String> cerberusProps() {
        Map<String, String> secrets = cerberusClient.read(sdbPath).getData();
        return secrets;
    }

    @Bean("objectMapper")
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        return mapper;
    }
}
