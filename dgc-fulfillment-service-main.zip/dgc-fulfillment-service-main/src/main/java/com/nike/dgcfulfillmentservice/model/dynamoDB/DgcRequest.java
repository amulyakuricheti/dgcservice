package com.nike.dgcfulfillmentservice.model.dynamoDB;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.time.OffsetDateTime;

@Data
@DynamoDBTable(tableName = "ordermgmt.dgc.requests-global")
public class DgcRequest {

    @DynamoDBHashKey
    private String dgcRequestId;

    private String orderNumber;
    private String transactionId;
    private String enterpriseCode;

    @DynamoDBIndexHashKey(attributeName = "requestStatus", globalSecondaryIndexNames = {"retryIndex"})
    private String requestStatus;

    private Integer eta;
    private String businessErrorCode;
    private String businessErrorMessage;
    private String errorCode;
    private String errorMessage;
    private String pgGetUrl;

    private String pgGiftCardResultsUrl;


    private String orderHeaderKey;
    private String orderLineKey;
    private String salesOrderNumber;
    private String releaseNo;
    private Double quantity;
    private String shipAdviceNo;
    private String certificateProfileId;

    private String currency;
    private Double requestAmount;
    private String recipientEmail;
    private String senderEmail;
    private String senderFirstName;
    private String senderLastName;
    private String giftCardAccountNumber;

    @DynamoDBTypeConverted(converter = BooleanConverter.class)
    private Boolean requestSuccess;

    @DynamoDBTypeConverted(converter = OffsetDateTimeMarshaller.class)
    private OffsetDateTime expirationDate;


    @DynamoDBTypeConverted(converter = OffsetDateTimeMarshaller.class)
    private OffsetDateTime retryExpiryDateTime;

    @DynamoDBTypeConverted(converter = OffsetDateTimeMarshaller.class)
    private OffsetDateTime creationDateTime;

    @DynamoDBTypeConverted(converter = OffsetDateTimeMarshaller.class)
    private OffsetDateTime lastModifiedDateTime;

    @JsonIgnore
    private long ttl;
}
