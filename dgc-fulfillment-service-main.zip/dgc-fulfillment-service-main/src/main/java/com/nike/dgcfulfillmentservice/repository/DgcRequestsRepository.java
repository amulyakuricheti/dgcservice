package com.nike.dgcfulfillmentservice.repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedQueryList;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.exception.RecordNotFoundException;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.stream.Collectors.toCollection;

@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
@Repository
public class DgcRequestsRepository {

    private final DynamoDBMapper dynamoDBMapper;

    @Value("${dynamoDB.transactions.globalSecondaryIndex.retryIndexName}")
    private String retryIndexName;

    public void save(DgcRequest transaction) {
        dynamoDBMapper.save(transaction);
    }

    public void updateTransaction(DgcRequest transaction) {
        dynamoDBMapper.save(transaction);
    }

    public Optional<DgcRequest> getTransactionByRequestId(String dgcRequestId) throws RecordNotFoundException {
        Map<String, AttributeValue> eav = new HashMap<>();
        long startTime = System.currentTimeMillis();
        eav.put(":dgcRequestId", new AttributeValue().withS(dgcRequestId));

        Optional<DgcRequest> optionalDBPaymentTransaction;
        DynamoDBQueryExpression<DgcRequest> queryExpression = new DynamoDBQueryExpression<DgcRequest>()
                .withKeyConditionExpression("dgcRequestId = :dgcRequestId")
                .withExpressionAttributeValues(eav)
                .withScanIndexForward(false)
                .withConsistentRead(false)
                .withLimit(1);

        try {
            optionalDBPaymentTransaction = this.getTransactionsFromDB(queryExpression, dgcRequestId);
        } catch (RecordNotFoundException e) {
            log.warn("Record does not exists for the dgcRequestId={}", dgcRequestId);
            optionalDBPaymentTransaction = Optional.empty();
        }

        log.info("event:Fetching records for the dgcRequestId={} ended, - TimeTaken={}ms", dgcRequestId, (System.currentTimeMillis() - startTime));

        return optionalDBPaymentTransaction;

    }

    public List<DgcRequest> getRecordsToRetry() {
        List<DgcRequest> dbDgcRequests = new ArrayList<>();
        Map<String, AttributeValue> expressionAttributeValues = new HashMap<String, AttributeValue>();
        long startTime = System.currentTimeMillis();
        log.info("event:Fetching records to retry PG PUT Call, startTime: {}", OffsetDateTime.now().toString());
        expressionAttributeValues.put(":v_status", new AttributeValue().withS(TransactionStatusConstants.STATUS_RETRY));
        expressionAttributeValues.put(":v_currentTime", new AttributeValue().withS(OffsetDateTime.now().toString()));

        DynamoDBQueryExpression<DgcRequest> queryExpression = new DynamoDBQueryExpression<DgcRequest>()
                .withKeyConditionExpression("requestStatus = :v_status  AND retryExpiryDateTime > :v_currentTime")
                .withExpressionAttributeValues(expressionAttributeValues)
                .withIndexName(retryIndexName)
                .withScanIndexForward(false)
                .withConsistentRead(false);


        PaginatedQueryList<DgcRequest> results = dynamoDBMapper.query(DgcRequest.class, queryExpression);

        if (results.size() != 0) {
            dbDgcRequests = results.parallelStream().collect(toCollection(ArrayList::new));
        }

        log.info("event:Fetching records to retry PG PUT Call ended, - TimeTaken={}ms", (System.currentTimeMillis() - startTime));

        return dbDgcRequests;
    }

    private Optional<DgcRequest> getTransactionsFromDB(DynamoDBQueryExpression<DgcRequest> queryExpression, String id) throws RecordNotFoundException {
        long startTime = System.currentTimeMillis();

        Optional<DgcRequest> possibleResult =
                dynamoDBMapper.query(DgcRequest.class, queryExpression)
                        .stream()
                        .findFirst();

        if (!possibleResult.isPresent()) {
            throw new RecordNotFoundException(String.format("There is no object with dgcRequestId=%s in dgc requests Table",
                    id));
        }

        log.info("DynamoDB result retrieved for dgcRequestId={}, is: {} - TimeTaken={}ms", id, possibleResult, (System.currentTimeMillis() - startTime));

        return possibleResult;
    }

}
