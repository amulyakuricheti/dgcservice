package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.notifier.data.InternalCommMessage;
import com.nike.pace.generator.tokenclient.interfaces.TokenClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestOperations;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class InputToPGGetSqsMessageProcessor implements Processor {

    @Value("${paymentgateway.giftcertificate.vip.name}")
    private String pgGiftCardEndPointVipName;

    @Value("${paymentgateway.giftcertificate_results.vip.name}")
    private String pgGiftCardResultsEndPointVipName;

    @Value("${oscar.service-scopes.payment-gift_certificate_results-v1.GET}")
    private String giftCertificateResultEndpointScope;

    @Value("${oscar.service-scopes.payment-gift_certificates-v1.GET}")
    private String giftCertificateGetEndpointScope;

    @Qualifier("restTemplateWithLoadBalancer")
    private final RestOperations restTemplate;

    @Autowired
    private TokenClient tokenClient;

    private static final String PG_RESULTS_ENDPOINT_RESOURCE = "gift_certificate_results";


    @Override
    public void process(Exchange exchange) throws Exception {
        // Extracting necessary information from the internal SQS message
        InternalCommMessage internalSQSMessage = exchange.getIn().getBody(InternalCommMessage.class);
        String jobURL = internalSQSMessage.getPgGetJobUrl();
        String dgcRequestId = internalSQSMessage.getDgcRequestId();

        // Logging the receipt of internal SQS message with relevant details
        log.info("Received internal SQS message with PG job URL: {} for dgcRequestId={}", jobURL, dgcRequestId);

        // Setting properties based on the job URL
        exchange.setProperty(DgcPaymentConstants.PRIVATE_URL_PATH, jobURL);
        if (jobURL.contains(PG_RESULTS_ENDPOINT_RESOURCE)) {
            exchange.setProperty(DgcPaymentConstants.VIP_NAME, pgGiftCardResultsEndPointVipName);
            exchange.setProperty(DgcPaymentConstants.IS_PG_DGC_RESULTS_ENDPOINT, true); // Flag for differentiating PG responses
        } else {
            exchange.setProperty(DgcPaymentConstants.VIP_NAME, pgGiftCardEndPointVipName);
        }

        // Constructing the final URL
        String vipName = exchange.getProperty(DgcPaymentConstants.VIP_NAME, String.class);
        String urlPath = exchange.getProperty(DgcPaymentConstants.PRIVATE_URL_PATH, String.class);
        String finalUrl = vipName + urlPath;
        log.info("Constructed final URL: {}", finalUrl);
        exchange.setProperty(DgcPaymentConstants.URL_PATH_GETCALL, finalUrl);
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, dgcRequestId);
        // Setting headers for the HTTP request
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_TYPE, "application/json; charset=UTF-8");
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.set(DgcPaymentConstants.X_NIKE_APP_ID, DgcPaymentConstants.ASYNCPAYMENTS);

        // Setting authorization header based on job URL
        String tokenScope = jobURL.contains(PG_RESULTS_ENDPOINT_RESOURCE) ? giftCertificateResultEndpointScope : giftCertificateGetEndpointScope;
        headers.set(HttpHeaders.AUTHORIZATION, "Bearer " + generateToken(tokenScope));

        // Creating the HTTP request entity
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        // Making the HTTP GET request and handling the response
        String responseBody = null;
        try {
            ResponseEntity<String> response = restTemplate.exchange(finalUrl, HttpMethod.GET, requestEntity, String.class);
            responseBody = response.getBody();
            log.info("Response received from endpoint: {}", responseBody);
        } catch (Exception e) {
            log.error("Failed to call endpoint with private link. Exception: {}", e.getMessage());
        }

        // Setting the response body in the exchange
        exchange.getIn().setBody(responseBody);

    }

    public String generateToken(String scope) {
        try {
            return tokenClient.getAccessToken(scope);
        } catch (Exception ex) {
            log.error("Attempting to generate oscar token for headerScope: {} has failed", scope, ex);
            throw new RuntimeException("OSCAR Token Error: Error trying to generate token for headerScope: " + scope, ex);
        }
    }
}
