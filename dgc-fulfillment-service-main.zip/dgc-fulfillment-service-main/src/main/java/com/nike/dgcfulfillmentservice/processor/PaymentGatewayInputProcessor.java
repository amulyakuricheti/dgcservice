package com.nike.dgcfulfillmentservice.processor;

import com.amazonaws.util.json.Jackson;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.exception.InternalToDGCPaymentWrkrException;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayInput;
import com.nike.dgcfulfillmentservice.service.PaymentGatewayService;
import com.nike.dgcfulfillmentservice.validator.PGInputValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;


@Component
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class PaymentGatewayInputProcessor implements Processor {

    private final PaymentGatewayService paymentGatewayService;

    private final PGInputValidator pgInputValidator;

    @Value("${paymentgateway.giftcertificate.vip.name}")
    private String pgGiftCardEndPointVipName;

    @Value("${paymentgateway.giftcertificate.put.path}")
    private String pgGiftCardUrlPath;


    @Override
    public void process(Exchange exchange) throws Exception {
        PaymentGatewayInput pgInputRequest = null;
        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        String transactionId = exchange.getProperty(DgcPaymentConstants.TRANSACTION_ID, String.class);
        String shipAdviceNo = exchange.getProperty(DgcPaymentConstants.DGC_REQUEST_SHIP_ADVICE_NO, String.class);
        String enterpriseCode = exchange.getProperty(DgcPaymentConstants.DGC_REQUEST_ENTERPRISE_CODE, String.class);

        if (dgcRequestId != null) {
            pgInputRequest = paymentGatewayService.preparePaymentGatewayRequest(dgcRequestId);
        } else {
            throw new InternalToDGCPaymentWrkrException(String.format("No dgcRequestId has been received in the camel headers"));
        }

        if (pgInputRequest != null
                && pgInputValidator.isPGPutInputValid(pgInputRequest)) {
            Map<String, String> pgUrlParams = this.getEndpointDetails(transactionId);
            exchange.setProperty(DgcPaymentConstants.VIP_NAME, pgUrlParams.get(DgcPaymentConstants.VIP_NAME));
            exchange.setProperty(DgcPaymentConstants.URL_PATH, pgUrlParams.get(DgcPaymentConstants.URL_PATH));
            exchange.setProperty(DgcPaymentConstants.PRIVATE_URL_PATH, pgUrlParams.get(DgcPaymentConstants.PRIVATE_URL_PATH));
            exchange.getIn().setHeader(DgcPaymentConstants.URL_PATH, pgUrlParams.get(DgcPaymentConstants.URL_PATH));
            exchange.getIn().setBody(pgInputRequest);
            log.info("Payment gateway request payload successfully formed for the dgcRequestId = {}, shipAdviceNo={}, enterpriseCode={} and urlPath={}", dgcRequestId, shipAdviceNo, enterpriseCode, pgUrlParams.get(DgcPaymentConstants.URL_PATH));
        } else {
            log.error("payment Request formed for dgcRequestId = {} before PG PUT call is invalid. payload is = {}", dgcRequestId, Jackson.toJsonString(pgInputRequest));
            paymentGatewayService.updatePaymentTransactionWithError(dgcRequestId, "400", "Bad_Request_PG");
            throw new BadRequestException(String.format("Payment Request to PG PUT call is invalid for dgcRequestId = %s, pgInputPayload=%s", dgcRequestId, Jackson.toJsonString(pgInputRequest)));
        }

    }

    /**
     * Provide  VIP Name and URL to interact with Payment Gateway
     *
     * @param transactionId
     * @return
     */
    private Map<String, String> getEndpointDetails(String transactionId) {
        Map<String, String> pgUrlParams = new HashMap<>();
        pgUrlParams.put(DgcPaymentConstants.VIP_NAME, pgGiftCardEndPointVipName);
        pgUrlParams.put(DgcPaymentConstants.PRIVATE_URL_PATH, pgGiftCardUrlPath + transactionId);
        pgUrlParams.put(DgcPaymentConstants.URL_PATH, pgGiftCardEndPointVipName + pgGiftCardUrlPath + transactionId);
        return pgUrlParams;

    }

}
