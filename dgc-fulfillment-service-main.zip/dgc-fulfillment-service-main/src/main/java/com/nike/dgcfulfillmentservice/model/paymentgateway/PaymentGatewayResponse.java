package com.nike.dgcfulfillmentservice.model.paymentgateway;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentGatewayResponse {

    private String id;
    private String status;
    private Integer eta;
    private String resourceType;
    private Link links;
    private Response response;


    @Data
    public static final class Link {
        private Self self;

        @Data
        public static final class Self {
            private String ref;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private String accountNumber;
        private String referenceCode;
        private String currency;
        private Double creationAmount;
        private String pin;
        private Boolean requestSuccess;
        private String requestId;
        private String requestToken;
        private String resourceType;
        private String expirationDate;
        private String decision;


        private Link links;
        private String errorCode;
        private String errorMessage;
    }

}
