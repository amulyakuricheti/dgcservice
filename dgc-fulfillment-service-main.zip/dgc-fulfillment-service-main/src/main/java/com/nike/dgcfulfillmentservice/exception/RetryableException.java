package com.nike.dgcfulfillmentservice.exception;

public class RetryableException extends RuntimeException {

    public RetryableException(String message) {
        super(message);
    }

}
