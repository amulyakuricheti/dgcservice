package com.nike.dgcfulfillmentservice.model.asyncbridge;

public interface VOMDgcResponseCheck {
}
