package com.nike.dgcfulfillmentservice.model.input;

public interface VOMOrderReleaseCheck {
}
