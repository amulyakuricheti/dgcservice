package com.nike.dgcfulfillmentservice.model.dynamoDB;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;

public class BooleanConverter implements DynamoDBTypeConverter<String, Boolean> {

    @Override
    public final String convert(Boolean booleanValue) {
        return booleanValue.toString();
    }

    @Override
    public final Boolean unconvert(String obj) {
        return Boolean.parseBoolean(obj);
    }
}

