package com.nike.dgcfulfillmentservice.model.dynamoDB;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;

import java.time.OffsetDateTime;

public class OffsetDateTimeMarshaller implements DynamoDBTypeConverter<String, OffsetDateTime> {

        @Override
        public final String convert(OffsetDateTime offsetDateTime) {
            return offsetDateTime.toString();
        }

        @Override
        public final OffsetDateTime unconvert(String obj) {
            return OffsetDateTime.parse(obj);
        }
    }

