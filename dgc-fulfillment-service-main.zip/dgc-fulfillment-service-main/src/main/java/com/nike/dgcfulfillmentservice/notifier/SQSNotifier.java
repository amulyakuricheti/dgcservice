package com.nike.dgcfulfillmentservice.notifier;

public interface SQSNotifier {
    void publishMessageForGETDetails(String dgcRequestId, String jobURL, Integer eta, String traceId);
}
