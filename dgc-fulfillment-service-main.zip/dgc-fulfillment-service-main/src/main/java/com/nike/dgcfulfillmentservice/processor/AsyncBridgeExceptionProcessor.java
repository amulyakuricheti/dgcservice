package com.nike.dgcfulfillmentservice.processor;


import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.notifier.SQSNotifier;
import com.nike.dgcfulfillmentservice.service.AsyncBridgeService;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import com.nike.dgcfulfillmentservice.util.PaymentsExceptionUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class AsyncBridgeExceptionProcessor implements Processor {

    @Autowired
    @Qualifier("postToPACRetryNotifier")
    private SQSNotifier asyncBridgeRetryNotifier;

    private final DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;

    private final AsyncBridgeService asyncBridgeService;

    @Override
    public void process(Exchange exchange) throws Exception {
        String dgcRequestId = exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class);
        String pgResultUrl = exchange.getProperty(DgcPaymentConstants.PG_RESULT_URL, String.class);
        log.warn("AsyncBridge post call failed in the first attempt fo the dgcRequestId = {}", dgcRequestId);
        Exception camelExceptionCaught = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
        String traceId = "";

        Map<String, String> errorDetails = PaymentsExceptionUtil.getErrorDetails(camelExceptionCaught);

        String errorMessage = errorDetails.get("ErrorMessage").isEmpty() ? DgcPaymentConstants.ASYNC_BRIDGE_POST_EXCEPTION : errorDetails.get("ErrorMessage");

        asyncBridgeService.updateTransactionWithError(dgcRequestId, errorDetails.get("ErrorCode"), errorMessage);

        boolean isEligibleToRetry = dgcPaymentsWrkrUtil.isEligibleToRetry(camelExceptionCaught);
        log.info("Sending dgc details to queue for retry with DgcRequestId={}, pgResultUrl={}", dgcRequestId, pgResultUrl);
        if (isEligibleToRetry) {
            asyncBridgeRetryNotifier.publishMessageForGETDetails(dgcRequestId, pgResultUrl, 0, traceId);
        } else {
            log.warn("Request is not eligible to process for dgcRequestId={} with error {}", dgcRequestId, camelExceptionCaught);
            throw new RuntimeException(camelExceptionCaught);
        }
    }


}
