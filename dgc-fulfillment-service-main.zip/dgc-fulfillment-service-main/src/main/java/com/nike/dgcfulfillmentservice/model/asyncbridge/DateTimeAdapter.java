package com.nike.dgcfulfillmentservice.model.asyncbridge;

import org.joda.time.DateTime;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import static org.joda.time.DateTimeZone.UTC;

public class DateTimeAdapter extends XmlAdapter<String, DateTime> {

    public DateTime unmarshal(String v) throws Exception {
        return new DateTime(v, UTC);
    }

    public String marshal(DateTime v) throws Exception {
        return v.toString();
    }
}
