package com.nike.dgcfulfillmentservice;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nike.dgcfulfillmentservice.model.asyncbridge.ExtnNikeGiftcardInfo;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayInput;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import org.springframework.util.StreamUtils;
import org.xml.sax.InputSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;
import java.io.InputStream;
import java.time.OffsetDateTime;

import static java.nio.charset.StandardCharsets.UTF_8;

public class TestDataProvider {

    public OrderRelease createOrderReleaseInput() throws Exception {
        //Disable XXE
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        spf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        spf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        OrderRelease request;
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("dgcReleaseInput.xml")) {
            //Do unmarshall operation
            Source xmlSource = new SAXSource(spf.newSAXParser().getXMLReader(),
                    new InputSource(in));

            JAXBContext jaxbContext = JAXBContext.newInstance(OrderRelease.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

            request = (OrderRelease) unmarshaller.unmarshal(xmlSource);
        }
        return request;
    }

    public OrderRelease createOrderReleaseInvalidInput() throws Exception {
        //Disable XXE
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        spf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        spf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        OrderRelease request;
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("dgcReleaseInput_BadRequest.xml")) {
            //PersonInfoBillTo LastName is missing the xml

            //Do unmarshall operation
            Source xmlSource = new SAXSource(spf.newSAXParser().getXMLReader(),
                    new InputSource(in));

            JAXBContext jaxbContext = JAXBContext.newInstance(OrderRelease.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

            request = (OrderRelease) unmarshaller.unmarshal(xmlSource);
        }
        return request;
    }


    public DgcRequest getDBDgcRequest() {
        DgcRequest dgcRequest = new DgcRequest();
        dgcRequest.setDgcRequestId("TST_DGC_REQUEST_ID-123");
        dgcRequest.setTransactionId("TXN_ID123");
        dgcRequest.setShipAdviceNo("SHPADVNO123");
        dgcRequest.setEnterpriseCode("NIKEUS");
        dgcRequest.setSalesOrderNumber("TSTORDNO1234");
        dgcRequest.setRequestStatus("NEW");
        dgcRequest.setCertificateProfileId("14752962350");
        dgcRequest.setOrderLineKey("TEST_ORDLINE_KEY_123");
        dgcRequest.setOrderHeaderKey("TEST_ORDHDR_KEY_123");
        dgcRequest.setRecipientEmail("test12@mail.com");
        dgcRequest.setSenderFirstName("firstName");
        dgcRequest.setSenderLastName("lastName");
        dgcRequest.setRequestAmount(100.0);
        dgcRequest.setGiftCardAccountNumber("TST_GFTCRD_NO_1234");
        dgcRequest.setCurrency("USD");
        dgcRequest.setQuantity(1.0);
        dgcRequest.setReleaseNo("TST_RELEASENO_1234");
        dgcRequest.setSenderEmail("test@mail.com");
        return dgcRequest;
    }


//    public DgcDetails getDBPaymentDetails() {
//        DgcDetails dgcDetails = new DgcDetails();
//        dgcDetails.setDgcRequestDetailId("DGCREQDTLID123");
//        dgcDetails.setCertificateProfileId("14752962350");
//        dgcDetails.setOrderLineKey("TEST_ORDLINE_KEY_123");
//        dgcDetails.setOrderHeaderKey("TEST_ORDHDR_KEY_123");
//        dgcDetails.setRecipientEmail("test12@mail.com");
//        dgcDetails.setRequestAmount(100.0);
//        dgcDetails.setGiftCardAccountNumber("TST_GFTCRD_NO_1234");
////        dbPaymentDetails.setGiftCardSecretKey("TST_SECRET_KEY-123");
////        dbPaymentDetails.setDecision("ACCEPTED");
//        dgcDetails.setRequestSuccess(true);
//        dgcDetails.setExpirationDate(OffsetDateTime.now().plusDays(1));
////        dbPaymentDetails.setGiftCardSecret(AESEncryptDecryptUtil.encrypt("1256","TST_SECRET_KEY-123"));
//        dgcDetails.setCurrency("USD");
//        dgcDetails.setSenderEmail("test@mail.com");
//        return dgcDetails;
//    }

    public PaymentGatewayInput createPaymentGatewayInput() {

        PaymentGatewayInput.Request.SenderInfo.Name name = new PaymentGatewayInput.Request.SenderInfo.Name();
        name.setFirstName("TST_FIRST_NAME");
        name.setLastName("TST_LAST_NAME");

        PaymentGatewayInput.Request.RecipientInfo recipientInfo = new PaymentGatewayInput.Request.RecipientInfo();
        PaymentGatewayInput.Request.SenderInfo senderInfo = new PaymentGatewayInput.Request.SenderInfo();
        PaymentGatewayInput.Request.RecipientInfo.ContactInfo recipientContactInfo = new PaymentGatewayInput.Request.RecipientInfo.ContactInfo();
        PaymentGatewayInput.Request.SenderInfo.ContactInfo senderContactInfo = new PaymentGatewayInput.Request.SenderInfo.ContactInfo();

        senderContactInfo.setEmail("test@test.com");
        recipientContactInfo.setEmail("test@test.com");

        senderInfo.setContactInfo(senderContactInfo);
        recipientInfo.setContactInfo(recipientContactInfo);

        PaymentGatewayInput.Request request = PaymentGatewayInput.Request
                .builder()
                .certificateProfileId("TEST123")
                .referenceCode("TEST_REF_CODE123")
                .account("12345")
                .currency("USD")
                .amount(100.0)
                .senderInfo(senderInfo)
                .recipientInfo(recipientInfo)
                .build();

        return PaymentGatewayInput
                .builder()
                .priority("NORMAL")
                .request(request)
                .build();

    }

    public PaymentGatewayResponse createPaymentGatewayResponse() {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(JsonParser.Feature.AUTO_CLOSE_SOURCE, true);
        PaymentGatewayResponse paymentGatewayResponse = null;

        try (InputStream in = this.getClass().getClassLoader().getResourceAsStream("paymentgatewayresponses/pgPutResponse.json")) {
            String test = StreamUtils.copyToString(in, UTF_8);
            paymentGatewayResponse = objectMapper.readValue(test, PaymentGatewayResponse.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return paymentGatewayResponse;

    }

    public PaymentGatewayResponse createPaymentGatewayResponseCompleted() {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(JsonParser.Feature.AUTO_CLOSE_SOURCE, true);
        PaymentGatewayResponse paymentGatewayResponse = null;

        try (InputStream in = this.getClass().getClassLoader().getResourceAsStream("paymentgatewayresponses/pgGetResponseCompleted.json")) {
            String test = StreamUtils.copyToString(in, UTF_8);
            paymentGatewayResponse = objectMapper.readValue(test, PaymentGatewayResponse.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return paymentGatewayResponse;

    }

    public PaymentGatewayResponse.Response createPaymentGatewayResponseCompletedResults() {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(JsonParser.Feature.AUTO_CLOSE_SOURCE, true);
        PaymentGatewayResponse.Response paymentGatewayResponse = null;

        try (InputStream in = this.getClass().getClassLoader().getResourceAsStream("paymentgatewayresponses/pgResultResponse.json")) {
            String test = StreamUtils.copyToString(in, UTF_8);
            paymentGatewayResponse = objectMapper.readValue(test, PaymentGatewayResponse.Response.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return paymentGatewayResponse;

    }


    public ExtnNikeGiftcardInfo createAsyncPaymentResponse() throws Exception {
        //Disable XXE
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        spf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        spf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        ExtnNikeGiftcardInfo recordCollection;
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("AsyncBridgePayload.xml")) {

            //Do unmarshall operation
            Source xmlSource = new SAXSource(spf.newSAXParser().getXMLReader(), new InputSource(in));
            JAXBContext jaxbContext = JAXBContext.newInstance(ExtnNikeGiftcardInfo.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

            recordCollection = (ExtnNikeGiftcardInfo) unmarshaller.unmarshal(xmlSource);
        }
        return recordCollection;
    }

    public DgcRequest getDBPaymentTxnWithExpirationDate() {
        DgcRequest dgcRequest = new DgcRequest();
        dgcRequest.setTransactionId("testTransactionId");
        dgcRequest.setRequestStatus("RETRY");
        dgcRequest.setRetryExpiryDateTime(OffsetDateTime.now().minusMinutes(5));
        return dgcRequest;
    }

    public DgcRequest getDBPaymentTxnWithExpirationDateNotExpired() {
        DgcRequest dgcRequest = new DgcRequest();
        dgcRequest.setTransactionId("testTransactionId");
        dgcRequest.setRequestStatus("RETRY");
        dgcRequest.setRetryExpiryDateTime(OffsetDateTime.now().plusMinutes(6));
        return dgcRequest;
    }


}
