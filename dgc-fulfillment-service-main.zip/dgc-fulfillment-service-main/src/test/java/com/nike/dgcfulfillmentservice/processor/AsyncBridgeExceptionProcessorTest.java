package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.exception.AsyncBridgePOSTException;
import com.nike.dgcfulfillmentservice.notifier.SQSNotifier;
import com.nike.dgcfulfillmentservice.service.AsyncBridgeService;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Qualifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AsyncBridgeExceptionProcessorTest extends ProcessorTest {

    @Mock
    @Qualifier("postToPACRetryNotifier")
    private SQSNotifier dgcPaymentsWrkrNotifier;

    @Mock
    private DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;

    @Mock
    private AsyncBridgeService asyncBridgeService;

    @InjectMocks
    private AsyncBridgeExceptionProcessor asyncBridgeExceptionProcessor;

    @Test
    public void testProcess() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new AsyncBridgePOSTException("exceptionBody"));
        when(dgcPaymentsWrkrUtil.isEligibleToRetry(any())).thenReturn(true);
        asyncBridgeExceptionProcessor.process(exchange);
        verify(asyncBridgeService, times(1)).updateTransactionWithError(any(), any(), any());
        verify(dgcPaymentsWrkrNotifier, times(1)).publishMessageForGETDetails(any(), any(), any(), any());

    }

    @Test(expected = RuntimeException.class)
    public void testProcessNotEligibleToRetry() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new AsyncBridgePOSTException("exceptionBody"));
        when(dgcPaymentsWrkrUtil.isEligibleToRetry(any())).thenReturn(false);
        asyncBridgeExceptionProcessor.process(exchange);

    }

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(asyncBridgeExceptionProcessor).to("mock:result");
            }
        };
    }
}
