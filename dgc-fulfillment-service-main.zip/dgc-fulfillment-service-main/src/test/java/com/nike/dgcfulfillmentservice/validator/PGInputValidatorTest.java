package com.nike.dgcfulfillmentservice.validator;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayInput;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class PGInputValidatorTest {

    private PGInputValidator pgInputValidator;

    private TestDataProvider testDataProvider = new TestDataProvider();

    @Before
    public void setup() {
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        Validator validator = validatorFactory.getValidator();
        pgInputValidator = new PGInputValidator(validator);
    }

    @Test
    public void testIsPGPutInputValid() throws Exception {
        PaymentGatewayInput pgInputRequest = testDataProvider.createPaymentGatewayInput();
        boolean isValid = pgInputValidator.isPGPutInputValid(pgInputRequest);
        assertTrue(isValid);
    }

    @Test
    public void testIsPGPutInputInValid() throws Exception {
        PaymentGatewayInput pgInputRequest = testDataProvider.createPaymentGatewayInput();
        PaymentGatewayInput.Request request = pgInputRequest.getRequest();
        request.setAccount("");
        boolean isValid = pgInputValidator.isPGPutInputValid(pgInputRequest);
        assertFalse(isValid);
    }
}
