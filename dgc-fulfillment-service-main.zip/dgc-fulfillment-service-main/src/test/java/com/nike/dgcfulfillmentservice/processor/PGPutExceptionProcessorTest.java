package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.service.DgcPaymentsService;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.notNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PGPutExceptionProcessorTest extends ProcessorTest {

    @Mock
    private DgcPaymentsService DGCPaymentsService;

    @Mock
    private DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;

    @InjectMocks
    private PGPutCallExceptionProcessor pgPutCallExceptionProcessor;

    private TestDataProvider testDataProvider = new TestDataProvider();


    @Test
    public void testProcess() {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("CamelHttpResponseCode", "500");
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new HttpOperationFailedException("testURL", 500, null, null, responseHeaders, "testException"));
        when(dgcPaymentsWrkrUtil.isEligibleToRetry(any())).thenReturn(true);
        pgPutCallExceptionProcessor.process(exchange);
        verify(DGCPaymentsService, times(1)).updateTransactionToRetry(any(), any(), any(), notNull());
    }

    @Test(expected = RuntimeException.class)
    public void testProcessNoEligibleToRetry() {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("CamelHttpResponseCode", "400");
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new HttpOperationFailedException("testURL", 400, null, null, responseHeaders, "testException"));
        when(dgcPaymentsWrkrUtil.isEligibleToRetry(any())).thenReturn(false);
        pgPutCallExceptionProcessor.process(exchange);

    }

    @Test(expected = RuntimeException.class)
    public void testProcessNoEligibleToRetry_1() {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("CamelHttpResponseCode", "400");
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new RuntimeException("runtimeexception", new HttpOperationFailedException("testURL", 400, null, null, responseHeaders, "testException")));
        when(dgcPaymentsWrkrUtil.isEligibleToRetry(any())).thenReturn(false);
        pgPutCallExceptionProcessor.process(exchange);

    }

    @Test
    public void testHandleExceptionOnRetry() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("CamelHttpResponseCode", "500");
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new HttpOperationFailedException("testURL", 500, null, null, responseHeaders, "testException"));
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(testDataProvider.getDBPaymentTxnWithExpirationDate()));
        pgPutCallExceptionProcessor.handleExceptionOnRetry(exchange);
        verify(DGCPaymentsService, times(1)).updateTransactionToError(any(), any(), any());
    }

    @Test
    public void testHandleExceptionOnRetryToRetry() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("CamelHttpResponseCode", "500");
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new HttpOperationFailedException("testURL", 500, null, null, responseHeaders, "testException"));

        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(testDataProvider.getDBPaymentTxnWithExpirationDateNotExpired()));
        pgPutCallExceptionProcessor.handleExceptionOnRetry(exchange);

        verify(DGCPaymentsService, times(1)).updateTransactionToRetry(any(), any(), any(), any());
    }

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(pgPutCallExceptionProcessor).to("mock:result");
            }
        };
    }
}
