package com.nike.dgcfulfillmentservice.service;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.model.asyncbridge.ExtnNikeGiftcardInfo;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.validator.AsyncBridgeInputValidator;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.OffsetDateTime;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AsyncBridgeServiceTest {

    @Mock
    private DgcPaymentsService DGCPaymentsService;

    @Mock
    private AsyncBridgeInputValidator asyncBridgeInputValidator;

    @InjectMocks
    private AsyncBridgeService asyncBridgeService;

    private TestDataProvider testDataProvider = new TestDataProvider();


    @Test
    public void testPrepareAsyncPaymentResponseFromPGResponse() throws Exception {

        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        PaymentGatewayResponse paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompleted();
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(dbDgcRequest));
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = asyncBridgeService.prepareAsyncPaymentResponse("TID123", paymentGatewayResponse.getResponse());
        assertNotNull(extnNikeGiftcardInfo);
        assertEquals("851515", extnNikeGiftcardInfo.getExtnPin());
        assertEquals("123794", extnNikeGiftcardInfo.getExtnAuthCode());
        assertEquals("valid", extnNikeGiftcardInfo.getExtnStatus());
        assertEquals("6060104681022656118", extnNikeGiftcardInfo.getExtnGiftcardNumber());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getExtnOrderHeaderKey());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getOrderHeaderKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getExtnOrderLineKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getOrderLineKey());
        assertEquals(true, extnNikeGiftcardInfo.getIsDGC());
        assertThat(extnNikeGiftcardInfo.getQuantity(), Matchers.is(1.0));
        assertEquals("TST_RELEASENO_1234", extnNikeGiftcardInfo.getReleaseNo());

    }

    @Test
    public void testPrepareAsyncPaymentResponseFromPGResultsResponse() throws Exception {

        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        PaymentGatewayResponse.Response paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompletedResults();
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(dbDgcRequest));
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = asyncBridgeService.prepareAsyncPaymentResponse("TID123", paymentGatewayResponse);
        assertNotNull(extnNikeGiftcardInfo);
        assertEquals("694289", extnNikeGiftcardInfo.getExtnPin());
        assertEquals("2088712227142314", extnNikeGiftcardInfo.getExtnAuthCode());
        assertEquals("valid", extnNikeGiftcardInfo.getExtnStatus());
        assertEquals("ACCEPT", extnNikeGiftcardInfo.getExtnDecision());
        assertEquals("6063857841000058303", extnNikeGiftcardInfo.getExtnGiftcardNumber());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getExtnOrderHeaderKey());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getOrderHeaderKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getExtnOrderLineKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getOrderLineKey());
        assertEquals(true, extnNikeGiftcardInfo.getIsDGC());
        assertThat(extnNikeGiftcardInfo.getQuantity(), Matchers.is(1.0));
        assertEquals("TST_RELEASENO_1234", extnNikeGiftcardInfo.getReleaseNo());

    }

    @Test
    public void testPrepareAsyncPaymentResponseFromPGResultsError() throws Exception {

        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        PaymentGatewayResponse.Response paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompletedResults();
        paymentGatewayResponse.setRequestSuccess(false);
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(dbDgcRequest));
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = asyncBridgeService.prepareAsyncPaymentResponse("TID123", paymentGatewayResponse);
        assertNotNull(extnNikeGiftcardInfo);
//        assertEquals("694289", extnNikeGiftcardInfo.getExtnPin());
//        assertEquals("2088712227142314", extnNikeGiftcardInfo.getExtnAuthCode());
        assertEquals("invalid", extnNikeGiftcardInfo.getExtnStatus());
        assertEquals("ERROR", extnNikeGiftcardInfo.getExtnDecision());
//        assertEquals("6063857841000058303", extnNikeGiftcardInfo.getExtnGiftcardNumber());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getExtnOrderHeaderKey());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getOrderHeaderKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getExtnOrderLineKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getOrderLineKey());
        assertEquals(true, extnNikeGiftcardInfo.getIsDGC());
        assertThat(extnNikeGiftcardInfo.getQuantity(), Matchers.is(1.0));
        assertEquals("TST_RELEASENO_1234", extnNikeGiftcardInfo.getReleaseNo());

    }

    @Test(expected = RuntimeException.class)
    public void testPrepareAsyncPaymentResponseFromPGResponseDBRecordNotFound() throws Exception {
        PaymentGatewayResponse paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompleted();
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.empty());
        asyncBridgeService.prepareAsyncPaymentResponse("TID123", paymentGatewayResponse.getResponse());
    }


    @Test
    public void testBuildAsyncResponseWithResponseForErrorButSuccess() throws Exception {
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        dbDgcRequest.setRequestStatus("PROCESSING");
        PaymentGatewayResponse paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompleted();
        paymentGatewayResponse.getResponse().setErrorCode("BUSINESS_ERROR");
        paymentGatewayResponse.getResponse().setCreationAmount(30.0);
        paymentGatewayResponse.getResponse().setRequestSuccess(true);
        Object payload = asyncBridgeService.buildAsyncPaymentResponse(dbDgcRequest, paymentGatewayResponse.getResponse());
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = (ExtnNikeGiftcardInfo) payload;

        //to verify if the errorFlag is not set to Y and processedAmount not null
        assertEquals("ACCEPT", extnNikeGiftcardInfo.getExtnDecision());
        assertEquals("valid", extnNikeGiftcardInfo.getExtnStatus());
        assertEquals("123794", extnNikeGiftcardInfo.getExtnAuthCode());
        assertEquals("851515", extnNikeGiftcardInfo.getExtnPin());
        assertEquals("6060104681022656118", extnNikeGiftcardInfo.getExtnGiftcardNumber());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getExtnOrderHeaderKey());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getOrderHeaderKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getExtnOrderLineKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getOrderLineKey());
        assertEquals(true, extnNikeGiftcardInfo.getIsDGC());
        assertThat(extnNikeGiftcardInfo.getQuantity(), Matchers.is(1.0));
        assertEquals("TST_RELEASENO_1234", extnNikeGiftcardInfo.getReleaseNo());

    }

    @Test
    public void testBuildAsyncResponseWithResponseForErrorAndFailure() throws Exception {
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        dbDgcRequest.setRequestStatus("PROCESSING");
        PaymentGatewayResponse paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompleted();
        paymentGatewayResponse.getResponse().setDecision("ERROR");
        paymentGatewayResponse.getResponse().setErrorCode("BUSINESS_ERROR");
        paymentGatewayResponse.getResponse().setCreationAmount(0.0);
        paymentGatewayResponse.getResponse().setRequestSuccess(false);
        Object payload = asyncBridgeService.buildAsyncPaymentResponse(dbDgcRequest, paymentGatewayResponse.getResponse());
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = (ExtnNikeGiftcardInfo) payload;
        assertEquals(false, extnNikeGiftcardInfo.getExtnSuccessStatus());
        assertEquals("invalid", extnNikeGiftcardInfo.getExtnStatus());
        assertEquals("ERROR", extnNikeGiftcardInfo.getExtnDecision());
        assertEquals("6060104681022656118", extnNikeGiftcardInfo.getExtnGiftcardNumber());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getExtnOrderHeaderKey());
        assertEquals("TEST_ORDHDR_KEY_123", extnNikeGiftcardInfo.getOrderHeaderKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getExtnOrderLineKey());
        assertEquals("TEST_ORDLINE_KEY_123", extnNikeGiftcardInfo.getOrderLineKey());
        assertEquals(true, extnNikeGiftcardInfo.getIsDGC());
        assertThat(extnNikeGiftcardInfo.getQuantity(), Matchers.is(1.0));
        assertEquals("TST_RELEASENO_1234", extnNikeGiftcardInfo.getReleaseNo());


    }


    @Test
    public void testUpdateTransactionWithCompleted() {
        asyncBridgeService.updateTransactionWithCompleted("TEST123");
        verify(DGCPaymentsService, times(1)).updateTransactionWithCompleted(eq("TEST123"));
    }

    @Test
    public void validateExtnNikeGiftCardInfo() {
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = new ExtnNikeGiftcardInfo();
        extnNikeGiftcardInfo.setExtnExpirationDate(OffsetDateTime.now().toString());
        extnNikeGiftcardInfo.setExtnTokenCode("TEST123");
        boolean isValid = asyncBridgeService.validate(extnNikeGiftcardInfo);
        assertFalse(isValid);
    }


    @Test
    public void testUpdatePaymentTransactionWithError() {

        asyncBridgeService.updateTransactionWithError("TID123", "10", "INVALID_VALUE");
        verify(DGCPaymentsService, times(1)).updateTransactionToError(any(), any(), any());

    }


}
