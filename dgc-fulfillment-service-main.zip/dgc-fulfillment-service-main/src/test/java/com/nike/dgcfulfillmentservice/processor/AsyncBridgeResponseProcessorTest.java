package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.service.AsyncBridgeService;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class AsyncBridgeResponseProcessorTest extends ProcessorTest {

    @Mock
    private AsyncBridgeService asyncBridgeService;

    @InjectMocks
    private AsyncBridgeResponseProcessor asyncBridgeResponseProcessor;


    @Test
    public void testProcess() {

        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, "202");
        template.send(exchange);
        verify(asyncBridgeService,times(1)).updateTransactionWithCompleted(any());
    }


    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(asyncBridgeResponseProcessor).to("mock:result");
            }
        };
    }
}
