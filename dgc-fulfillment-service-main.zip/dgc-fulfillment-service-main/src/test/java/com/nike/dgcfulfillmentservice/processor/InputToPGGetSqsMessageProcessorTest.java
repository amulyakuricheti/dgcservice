package com.nike.dgcfulfillmentservice.processor;


import com.amazonaws.util.json.Jackson;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.notifier.data.InternalCommMessage;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.IS_PG_DGC_RESULTS_ENDPOINT;
import static com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants.PRIVATE_URL_PATH;

@RunWith(MockitoJUnitRunner.class)
public class InputToPGGetSqsMessageProcessorTest extends ProcessorTest {

    @InjectMocks
    private InputToPGGetSqsMessageProcessor inputToPgGetSqsMessageProcessor;


    @Before
    public void init() {
        ReflectionTestUtils.setField(inputToPgGetSqsMessageProcessor, "pgGiftCardEndPointVipName", "payment-gift_certificates-v1");
        ReflectionTestUtils.setField(inputToPgGetSqsMessageProcessor, "pgGiftCardResultsEndPointVipName", "payment-gift_certificate_results-v1");
    }

    @Test
    public void testProcess() {

        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);

        InternalCommMessage internalSQSMessage = new InternalCommMessage();
        internalSQSMessage.setGiftCardType("DGC");
        internalSQSMessage.setPgGetJobUrl("/payment/gift_certificates/v1/jobs/T12345");
        internalSQSMessage.setDgcRequestId("TEST_123");

        exchange.getIn().setBody(Jackson.toJsonPrettyString(internalSQSMessage));

        template.send(exchange);
        assertEquals("/payment/gift_certificates/v1/jobs/T12345", exchange.getProperty(PRIVATE_URL_PATH));
        assertEquals("payment-gift_certificates-v1", exchange.getProperty("VIP_NAME"));
        assertNull(exchange.getProperty(IS_PG_DGC_RESULTS_ENDPOINT));
        assertEquals("TEST_123", exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID));
    }


    @Test
    public void testProcessResultsUrl() {

        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);

        InternalCommMessage internalSQSMessage = new InternalCommMessage();
        internalSQSMessage.setGiftCardType("DGC");
        internalSQSMessage.setPgGetJobUrl("/payment/gift_certificate_results/v1/T12345");
        internalSQSMessage.setDgcRequestId("TEST_123");

        exchange.getIn().setBody(Jackson.toJsonPrettyString(internalSQSMessage));

        template.send(exchange);
        assertEquals("/payment/gift_certificate_results/v1/T12345", exchange.getProperty(PRIVATE_URL_PATH));
        assertEquals("payment-gift_certificate_results-v1", exchange.getProperty("VIP_NAME"));
        assertEquals("TEST_123", exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID));
        assertTrue(exchange.getProperty(IS_PG_DGC_RESULTS_ENDPOINT, Boolean.class));

    }


    @Test(expected = RuntimeException.class)
    public void testNullURLValue() throws Exception {

        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);

        inputToPgGetSqsMessageProcessor.process(exchange);
    }


    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .unmarshal().json(JsonLibrary.Jackson, InternalCommMessage.class)
                        .process(inputToPgGetSqsMessageProcessor).to("mock:result");
            }
        };
    }
}
