package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.service.DgcPaymentsService;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class SchedulerProcessorTest extends ProcessorTest {

    @Mock
    private DgcPaymentsService DGCPaymentsService;

    @InjectMocks
    private SchedulerProcessor schedulerProcessor;


    private TestDataProvider testDataProvider = new TestDataProvider();


    @Test
    public void testGetRetryRecords() throws Exception {
        List<DgcRequest> dbDgcRequestList = schedulerProcessor.getRecordsToRetry();
        verify(DGCPaymentsService, times(1)).getRetryTransactions();
        assertNotNull(dbDgcRequestList);
    }

    @Test
    public void testProcess() {
        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TST_DGC_REQUEST_ID-123");
        exchange.setProperty(DgcPaymentConstants.TRANSACTION_ID, "TXN_ID123");
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        exchange.getIn().setBody(dbDgcRequest, DgcRequest.class);

        template.send(exchange);

        assertEquals(exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID, String.class), "TST_DGC_REQUEST_ID-123");
        assertEquals(exchange.getProperty(DgcPaymentConstants.TRANSACTION_ID, String.class), "TXN_ID123");
        assertEquals(exchange.getIn().getBody(String.class), "TST_DGC_REQUEST_ID-123");

    }

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(schedulerProcessor).to("mock:result");
            }
        };
    }
}
