package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.notifier.SQSNotifier;
import com.nike.dgcfulfillmentservice.repository.DgcRequestsRepository;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Optional;

import static com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants.STATUS_PROCESSED;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PublishMsgToGetPGUpdateProcessorTest extends ProcessorTest {

    @Mock
    @Qualifier("pgGetCallNotifier")
    private SQSNotifier paymentsNotifier;

    @Mock
    private DgcRequestsRepository dgcRequestsRepository;

    @InjectMocks
    private PublishMsgToGetPGUpdateProcessor messageTOGetPaymentDetailsProcessor;

    private TestDataProvider testDataProvider = new TestDataProvider();


    @Test
    public void testProcess() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        PaymentGatewayResponse paymentGatewayResponse = testDataProvider.createPaymentGatewayResponse();
        exchange.getIn().setBody(paymentGatewayResponse);
        template.send(exchange);

        verify(paymentsNotifier, times(1)).publishMessageForGETDetails(any(), any(), any(), any());
    }

    @Test
    public void testProcessForDuplicateReq() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        DgcRequest dgcRequest = testDataProvider.getDBDgcRequest();
        dgcRequest.setRequestStatus(STATUS_PROCESSED);
        dgcRequest.setPgGetUrl("/payment/gift_certificates/v1/jobs/TXN_ID123");
        dgcRequest.setPgGiftCardResultsUrl("/payment/gift_certificate_results/v1/TXN_ID123");

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
//        exchange.getIn().setHeader(TraceHeaders.TRACE_ID, "traceID123");
        OrderRelease orderRelease = testDataProvider.createOrderReleaseInput();
        exchange.getIn().setBody(orderRelease);
        when(dgcRequestsRepository.getTransactionByRequestId("TEST123")).thenReturn(Optional.of(dgcRequest));
        template.send(exchange);
        verify(paymentsNotifier, times(1)).publishMessageForGETDetails("TEST123", "/payment/gift_certificate_results/v1/TXN_ID123", 0, "");
    }

    @Test
    public void testProcessForDuplicateReqNoResultsUrl() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        DgcRequest dgcRequest = testDataProvider.getDBDgcRequest();
        dgcRequest.setRequestStatus(STATUS_PROCESSED);
        dgcRequest.setPgGetUrl("/payment/gift_certificates/v1/jobs/TXN_ID123");

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
//        exchange.getIn().setHeader(TraceHeaders.TRACE_ID, "traceID123");
        OrderRelease orderRelease = testDataProvider.createOrderReleaseInput();
        exchange.getIn().setBody(orderRelease);
        when(dgcRequestsRepository.getTransactionByRequestId("TEST123")).thenReturn(Optional.of(dgcRequest));
        template.send(exchange);
        verify(paymentsNotifier, times(1)).publishMessageForGETDetails("TEST123", "/payment/gift_certificates/v1/jobs/TXN_ID123", 0, "");
    }

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(messageTOGetPaymentDetailsProcessor).to("mock:result");
            }
        };
    }
}
