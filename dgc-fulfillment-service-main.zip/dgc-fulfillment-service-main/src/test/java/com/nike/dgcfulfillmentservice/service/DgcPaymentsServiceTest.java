package com.nike.dgcfulfillmentservice.service;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.repository.DgcRequestsRepository;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.OffsetDateTime;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DgcPaymentsServiceTest {

    @Mock
    private DgcRequestsRepository dgcRequestsRepository;

    @Mock
    private DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;


    @InjectMocks
    private DgcPaymentsService DGCPaymentsService;

    private TestDataProvider testDataProvider = new TestDataProvider();

    @Test
    public void testSaveDgcRequest() throws Exception {
        OrderRelease request = testDataProvider.createOrderReleaseInput();
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        String dgcRequestId = dbDgcRequest.getDgcRequestId();
        String accountNo = "TEST_ACCOUNT_NO_123";
        when(dgcPaymentsWrkrUtil.createDgcRequestRecordFromOrderRelease(any(), any(), any())).thenReturn(dbDgcRequest);
        doReturn(Optional.empty()).when(dgcRequestsRepository).getTransactionByRequestId(any());
        DgcRequest request1 = DGCPaymentsService.saveGCRequest(request, accountNo, dgcRequestId);
        assertEquals(request1, dbDgcRequest);
        verify(dgcRequestsRepository, times(1)).save(any());

    }

    @Test
    public void testDuplicateDgcRequest() throws Exception {
        OrderRelease request = testDataProvider.createOrderReleaseInput();
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        String dgcRequestId = dbDgcRequest.getDgcRequestId();
        String accountNo = "TEST_ACCOUNT_NO_123";
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.of(dbDgcRequest));

        DgcRequest txnId = DGCPaymentsService.saveGCRequest(request, accountNo, dgcRequestId);
        assertEquals("TXN_ID123", txnId.getTransactionId());

    }


    @Test
    public void testGetDBPaymentTransaction() throws Exception {
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.of(testDataProvider.getDBDgcRequest()));
        DgcRequest dbDgcRequest = DGCPaymentsService.getDBDgcRequest(testDataProvider.createOrderReleaseInput());
        assertNotNull(dbDgcRequest);
    }


    @Test
    public void testUpdateTransactionWithCompleted() {
        DgcRequest dgcRequest = testDataProvider.getDBDgcRequest();
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.of(dgcRequest));

        DGCPaymentsService.updateTransactionWithCompleted("TEST123");

        verify(dgcRequestsRepository, times(1)).updateTransaction(any(DgcRequest.class));
        assertEquals(dgcRequest.getRequestStatus(), "COMPLETED");
        assertNotEquals(dgcRequest.getTtl(), 0);

    }

    @Test(expected = RuntimeException.class)
    public void testUpdateTransactionWithCompletedNoRecord() {
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.empty());
        DGCPaymentsService.updateTransactionWithCompleted("TEST123");
    }

    @Test
    public void testUpdateTxnWithRetry() {
        DgcRequest dgcRequest = testDataProvider.getDBDgcRequest();
        OffsetDateTime currentTime = OffsetDateTime.now();
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.of(dgcRequest));
        DGCPaymentsService.updateTransactionToRetry("TEST123", "", "", currentTime.plusHours(DgcPaymentConstants.FORTY_EIGHT_TRANSACTION_EXPIRY_HOURS));
        assertThat(dgcRequest.getRequestStatus(), is("RETRY"));
        assertThat(dgcRequest.getRetryExpiryDateTime(), Matchers.equalTo(currentTime.plusHours(DgcPaymentConstants.FORTY_EIGHT_TRANSACTION_EXPIRY_HOURS)));
        assertNotNull(dgcRequest.getLastModifiedDateTime());
        assertNotNull(dgcRequest.getErrorCode());
        assertNotNull(dgcRequest.getErrorMessage());
        verify(dgcRequestsRepository, times(1)).updateTransaction(any());
    }

    @Test(expected = RuntimeException.class)
    public void testUpdateTxnWithRetryNoRecord() {
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.empty());
        DGCPaymentsService.updateTransactionToRetry("TEST123", "", "", OffsetDateTime.now().plusHours(DgcPaymentConstants.FORTY_EIGHT_TRANSACTION_EXPIRY_HOURS));
    }

    @Test
    public void testUpdateTxnWithError() {
        DgcRequest dgcRequest = testDataProvider.getDBDgcRequest();
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.of(dgcRequest));
        DGCPaymentsService.updateTransactionToError("TEST123", "", "");
        assertThat(dgcRequest.getRequestStatus(), is("ERROR"));
        assertNotNull(dgcRequest.getLastModifiedDateTime());
        assertNotNull(dgcRequest.getErrorMessage());
        assertNotNull(dgcRequest.getErrorCode());
        verify(dgcRequestsRepository, times(1)).updateTransaction(any());
    }

    @Test(expected = RuntimeException.class)
    public void testUpdateTxnWithErrorNoRecords() {
        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.empty());
        DGCPaymentsService.updateTransactionToError("TEST123", "", "");
    }

    @Test
    public void testGetRetryTransactions() {
        DGCPaymentsService.getRetryTransactions();
        verify(dgcRequestsRepository, times(1)).getRecordsToRetry();
    }


}
