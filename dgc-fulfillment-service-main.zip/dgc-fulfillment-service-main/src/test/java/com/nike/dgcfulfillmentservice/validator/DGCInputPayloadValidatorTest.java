package com.nike.dgcfulfillmentservice.validator;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class DGCInputPayloadValidatorTest {

    private DGCInputPayloadValidator DGCInputPayloadValidator;

    private TestDataProvider testDataProvider = new TestDataProvider();

    @Before
    public void setup() {
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        Validator validator = validatorFactory.getValidator();
        DGCInputPayloadValidator = new DGCInputPayloadValidator(validator);
    }

    @Test
    public void testIsVOMPutInputValid() throws Exception {
        OrderRelease pgInputRequest = testDataProvider.createOrderReleaseInput();
        boolean isValid = DGCInputPayloadValidator.isIncomingVOMInputValid(pgInputRequest);
        assertTrue(isValid);
    }

    @Test
    public void testIsVOMPutInputInValid() throws Exception {
        //PersonInfoBillTo LastName is missing
        OrderRelease pgInputRequest = testDataProvider.createOrderReleaseInvalidInput();
        boolean isValid = DGCInputPayloadValidator.isIncomingVOMInputValid(pgInputRequest);
        assertFalse(isValid);
    }
}
