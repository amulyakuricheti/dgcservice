package com.nike.dgcfulfillmentservice.validator;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.model.asyncbridge.ExtnNikeGiftcardInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import static junit.framework.TestCase.assertFalse;

@RunWith(MockitoJUnitRunner.class)
public class AsyncBridgeInputValidatorTest {

    private AsyncBridgeInputValidator asyncBridgeInputValidator;

    private TestDataProvider testDataProvider = new TestDataProvider();

    @Before
    public void setup() {
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        Validator validator = validatorFactory.getValidator();
        asyncBridgeInputValidator = new AsyncBridgeInputValidator(validator);
    }

    @Test
    public void testExtnGiftCardInfoIsValid() throws Exception {
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = testDataProvider.createAsyncPaymentResponse();
        boolean isValid = asyncBridgeInputValidator.isAsyncResponseValid(extnNikeGiftcardInfo);
        assertFalse(isValid);
    }

}
