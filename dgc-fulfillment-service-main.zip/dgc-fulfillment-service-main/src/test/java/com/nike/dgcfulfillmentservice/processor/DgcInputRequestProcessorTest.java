package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.service.DgcPaymentsService;
import com.nike.dgcfulfillmentservice.util.DgcPaymentsWrkrUtil;
import com.nike.dgcfulfillmentservice.validator.DGCInputPayloadValidator;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DgcInputRequestProcessorTest extends ProcessorTest {

    @Mock
    private DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil;
    @Mock
    private DgcPaymentsService DGCPaymentsService;

    @Mock
    private DGCInputPayloadValidator DGCInputPayloadValidator;

    @InjectMocks
    private DgcInputRequestProcessor dgcInputRequestProcessor;

    private final TestDataProvider testDataProvider = new TestDataProvider();

    @Test
    public void testProcess() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);
        OrderRelease orderRelease = testDataProvider.createOrderReleaseInput();
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        exchange.getIn().setBody(orderRelease);

        when(dgcPaymentsWrkrUtil.getDgcRequestId(any(), any())).thenReturn("202003311050035673557019_140163485");
        when(DGCPaymentsService.saveGCRequest(any(), any(), any())).thenReturn(dbDgcRequest);
        when(DGCInputPayloadValidator.isIncomingVOMInputValid(any())).thenReturn(true);

        template.send(exchange);

        assertEquals(exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID), "202003311050035673557019_140163485");
        assertEquals(exchange.getProperty(DgcPaymentConstants.DGC_REQUEST_SHIP_ADVICE_NO), dbDgcRequest.getShipAdviceNo());
        assertEquals(exchange.getProperty(DgcPaymentConstants.DGC_REQUEST_ENTERPRISE_CODE), dbDgcRequest.getEnterpriseCode());
        assertNotNull(exchange.getProperty(DgcPaymentConstants.TRANSACTION_ID));
        assertNotNull(exchange.getProperty(DgcPaymentConstants.TRANSACTION_STATUS));

    }


    @Test(expected = BadRequestException.class)
    public void testProcessBadReqException() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);

        OrderRelease DgcRequest = testDataProvider.createOrderReleaseInput();

        exchange.getIn().setBody(DgcRequest);
        when(DGCInputPayloadValidator.isIncomingVOMInputValid(any())).thenReturn(false);
        dgcInputRequestProcessor.process(exchange);
    }

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(dgcInputRequestProcessor).to("mock:result");
            }
        };
    }
}
