package com.nike.dgcfulfillmentservice.util;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.hamcrest.Matchers;
import org.junit.Test;

import static org.junit.Assert.*;

public class DgcPaymentsWrkrUtilTest {

    DgcPaymentsWrkrUtil dgcPaymentsWrkrUtil = new DgcPaymentsWrkrUtil();
    TestDataProvider testDataProvider = new TestDataProvider();
    String traceId = "traceId";

    @Test
    public void testCreateDgcRequestFromOrderReleaseInput() throws Exception {
        OrderRelease orderReleaseInput = testDataProvider.createOrderReleaseInput();
        String dgcRequestId = dgcPaymentsWrkrUtil.getDgcRequestId(orderReleaseInput.getSalesOrderNo(), orderReleaseInput.getShipAdviceNo());
        DgcRequest transaction = dgcPaymentsWrkrUtil.createDgcRequestRecordFromOrderRelease(orderReleaseInput, "TSTGCACCNO134", dgcRequestId);
        assertEquals(transaction.getDgcRequestId().split("_")[1], "140163485");
        assertNotNull(transaction.getTransactionId());
        assertEquals(transaction.getRequestStatus(), "NEW");
        assertNotNull(transaction.getLastModifiedDateTime());
        assertNotNull(transaction.getCreationDateTime());
        assertEquals("202003311050035673557018", transaction.getOrderHeaderKey());
        assertEquals("C08233443468", transaction.getSalesOrderNumber());
        assertEquals("C08233443468", transaction.getOrderNumber());
        assertEquals("NIKEUS", transaction.getEnterpriseCode());
        assertEquals("202003311050035673557019", transaction.getOrderLineKey());
        assertEquals("TSTGCACCNO134", transaction.getGiftCardAccountNumber());
        assertEquals("USD", transaction.getCurrency());
        assertEquals("25.0", transaction.getRequestAmount().toString());
        assertEquals("14752962350", transaction.getCertificateProfileId());
        assertEquals("ntester26@gmail.com", transaction.getRecipientEmail());
        assertEquals("test@nike.com", transaction.getSenderEmail());
        assertEquals("firstName", transaction.getSenderFirstName());
        assertEquals("lastName", transaction.getSenderLastName());
        assertEquals("1.0", String.valueOf(transaction.getQuantity()));
        assertEquals("1", transaction.getReleaseNo());
    }

    @Test
    public void testIsEligibleToRetry5XX() { //5xx errors
        HttpOperationFailedException httpOperationFailedException = new HttpOperationFailedException("testURL", 500, "internal Server Error", null, null, null);
        boolean isEligible = dgcPaymentsWrkrUtil.isEligibleToRetry(httpOperationFailedException);
        assertTrue(isEligible);
    }

    @Test
    public void testIsEligibleToRetry400() { //400
        HttpOperationFailedException httpOperationFailedException = new HttpOperationFailedException("testURL", 400, "Bad Request", null, null, null);
        boolean isEligible = dgcPaymentsWrkrUtil.isEligibleToRetry(httpOperationFailedException);
        assertFalse(isEligible);
    }

    @Test
    public void testIsEligibleToRetry409() { //409
        HttpOperationFailedException httpOperationFailedException = new HttpOperationFailedException("testURL", 409, "Bad Request", null, null, null);
        boolean isEligible = dgcPaymentsWrkrUtil.isEligibleToRetry(httpOperationFailedException);
        assertFalse(isEligible);
    }

    @Test
    public void testIsEligibleForNullPointer() {
        NullPointerException nullPointerException = new NullPointerException();
        boolean isEligible = dgcPaymentsWrkrUtil.isEligibleToRetry(nullPointerException);
        assertTrue(isEligible);
    }

    @Test
    public void testIsEligibleForGetRootCause() {
        boolean isEligible = dgcPaymentsWrkrUtil.isEligibleToRetry(new Exception("Conflict", new HttpOperationFailedException("testURL", 509, "Conflict", null, null, null)));
        assertTrue(isEligible);
    }

    @Test
    public void testGetDgcRequestId() {
        String dgcRequestId = dgcPaymentsWrkrUtil.getDgcRequestId("ORDLNKEY123", null);
        assertThat(dgcRequestId, Matchers.is("ORDLNKEY123"));
    }


}
