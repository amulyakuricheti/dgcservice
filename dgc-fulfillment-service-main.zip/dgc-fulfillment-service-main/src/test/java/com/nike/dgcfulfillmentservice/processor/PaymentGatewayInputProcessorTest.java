package com.nike.dgcfulfillmentservice.processor;


import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.exception.InternalToDGCPaymentWrkrException;
import com.nike.dgcfulfillmentservice.model.input.OrderRelease;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayInput;
import com.nike.dgcfulfillmentservice.service.PaymentGatewayService;
import com.nike.dgcfulfillmentservice.validator.PGInputValidator;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@RunWith(SpringJUnit4ClassRunner.class)
public class PaymentGatewayInputProcessorTest extends ProcessorTest {


    @Mock
    private PaymentGatewayService paymentGatewayService;

    @Mock
    private PGInputValidator pgInputValidator;

    @InjectMocks
    private PaymentGatewayInputProcessor paymentGatewayInputProcessor;
    private TestDataProvider testDataProvider = new TestDataProvider();

    @Before
    public void init() {
        ReflectionTestUtils.setField(paymentGatewayInputProcessor, "pgGiftCardEndPointVipName", "payment-gift_certificates-v1");
        ReflectionTestUtils.setField(paymentGatewayInputProcessor, "pgGiftCardUrlPath", "/payment/gift_certificates/v1/");
    }

    @Test
    public void testProcessInGeneralFlow() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        OrderRelease orderRelease = testDataProvider.createOrderReleaseInput();

        PaymentGatewayInput pgInputRequest = testDataProvider.createPaymentGatewayInput();

        when(paymentGatewayService.preparePaymentGatewayRequest("TEST123")).thenReturn(pgInputRequest);
        when(pgInputValidator.isPGPutInputValid(any())).thenReturn(true);

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        exchange.setProperty(DgcPaymentConstants.TRANSACTION_ID, "TXN_ID123");
        exchange.getIn().setBody(orderRelease);

        template.send(exchange);
        assertEquals("payment-gift_certificates-v1", exchange.getProperty(DgcPaymentConstants.VIP_NAME, String.class));
        assertEquals("payment-gift_certificates-v1/payment/gift_certificates/v1/TXN_ID123", exchange.getProperty(DgcPaymentConstants.URL_PATH, String.class));
        assertNotNull(exchange.getIn().getBody(PaymentGatewayInput.class));
    }

    @Test(expected = InternalToDGCPaymentWrkrException.class)
    public void testProcessInRetryFlowError() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);
        PaymentGatewayInput pgInputRequest = testDataProvider.createPaymentGatewayInput();
        exchange.getIn().setBody("TEST123");
        paymentGatewayInputProcessor.process(exchange);
    }

    @Test
    public void testProcessByDGCRequestIdSchedulerFlow() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        String transactionId = "TST_DGC_REQUEST_ID-123";


        PaymentGatewayInput pgInputRequest = testDataProvider.createPaymentGatewayInput();

        when(paymentGatewayService.preparePaymentGatewayRequest(transactionId)).thenReturn(pgInputRequest);
        when(pgInputValidator.isPGPutInputValid(any())).thenReturn(true);

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, transactionId);
        exchange.setProperty(DgcPaymentConstants.TRANSACTION_ID, "TXN_ID123");
        exchange.setProperty(DgcPaymentConstants.GIFT_CARD_TYPE_ACC_NO, "ACCNO123");

        exchange.getIn().setBody(transactionId);

        template.send(exchange);
        assertEquals("payment-gift_certificates-v1", exchange.getProperty(DgcPaymentConstants.VIP_NAME));
        assertEquals("payment-gift_certificates-v1/payment/gift_certificates/v1/TXN_ID123", exchange.getProperty(DgcPaymentConstants.URL_PATH));
        assertNotNull(exchange.getIn().getBody(String.class));
    }


    @Test
    public void testProcessBadReqException() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        OrderRelease orderRelease = testDataProvider.createOrderReleaseInput();

        PaymentGatewayInput pgInputRequest = testDataProvider.createPaymentGatewayInput();

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        exchange.setProperty(DgcPaymentConstants.TRANSACTION_ID, "TXNID123");
        exchange.setProperty(DgcPaymentConstants.GIFT_CARD_TYPE_ACC_NO, "ACCNO123");

        exchange.getIn().setBody(orderRelease);

        when(paymentGatewayService.preparePaymentGatewayRequest("TEST123")).thenReturn(pgInputRequest);
        when(pgInputValidator.isPGPutInputValid(any())).thenReturn(false);
        try {
            paymentGatewayInputProcessor.process(exchange);
            verify(paymentGatewayService, times(1)).updatePaymentTransactionWithError(any(), any(), any());

        } catch (Exception e) {
            assertIsInstanceOf(BadRequestException.class, e);
        }
    }

    @Override
    protected RouteBuilder createRouteBuilder() {

        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(paymentGatewayInputProcessor).to("mock:result");
            }
        };
    }

}
