package com.nike.dgcfulfillmentservice.processor;

import com.amazonaws.util.json.Jackson;
import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.exception.BadRequestException;
import com.nike.dgcfulfillmentservice.model.asyncbridge.ExtnNikeGiftcardInfo;
import com.nike.dgcfulfillmentservice.repository.DgcRequestsRepository;
import com.nike.dgcfulfillmentservice.service.AsyncBridgeService;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PostToAsyncBridgeProcessorTest extends ProcessorTest {

    @Mock
    private DgcRequestsRepository dgcRequestsRepository;

    @Mock
    private AsyncBridgeService asyncBridgeService;

    @InjectMocks
    private PostToAsyncBridgeProcessor postToAsyncBridgeProcessor;

    private TestDataProvider testDataProvider = new TestDataProvider();

    @Test(expected = RuntimeException.class)
    public void testProcessNullBody() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TST-DGC_REQUEST_ID1234");
        postToAsyncBridgeProcessor.process(exchange);
    }

    @Test
    public void testProcessWithPGResponseFromGetJobsEndpoint() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);

        exchange.getIn().setBody(testDataProvider.createPaymentGatewayResponseCompleted());
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TST-DGC_REQUEST_ID1234");

        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = testDataProvider.createAsyncPaymentResponse();
        when(asyncBridgeService.prepareAsyncPaymentResponse(any(), any())).thenReturn(extnNikeGiftcardInfo);
        when(asyncBridgeService.validate(any())).thenReturn(true);
        template.send(exchange);

        assertNotNull(exchange.getIn().getBody());
        ExtnNikeGiftcardInfo extnNikeGiftcardInfo1 = exchange.getIn().getBody(ExtnNikeGiftcardInfo.class);
        assertNotNull(extnNikeGiftcardInfo1);
        assertEquals(exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID), "TST-DGC_REQUEST_ID1234");
    }

    @Test
    public void testProcessWithPGResponseFromResultsEndpoint() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);

        String paymentGatewayResponseStr = Jackson.toJsonString(testDataProvider.createPaymentGatewayResponseCompleted().getResponse());
        exchange.getIn().setBody(paymentGatewayResponseStr);
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TST-DGC_REQUEST_ID1234");

        ExtnNikeGiftcardInfo extnNikeGiftcardInfo = testDataProvider.createAsyncPaymentResponse();
        when(asyncBridgeService.prepareAsyncPaymentResponse(any(), any())).thenReturn(extnNikeGiftcardInfo);
        when(asyncBridgeService.validate(any())).thenReturn(true);
        template.send(exchange);

        assertNotNull(exchange.getIn().getBody());
        assertEquals(exchange.getIn().getHeader(DgcPaymentConstants.DGC_REQUEST_ID), "TST-DGC_REQUEST_ID1234");
    }

    @Test
    public void testProcessBadReqException() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        DefaultExchange exchange = new DefaultExchange(context);

        exchange.getIn().setBody(testDataProvider.createPaymentGatewayResponseCompleted());
        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "testTransactionId");
        ExtnNikeGiftcardInfo recordCollection = testDataProvider.createAsyncPaymentResponse();
        when(asyncBridgeService.prepareAsyncPaymentResponse(any(), any())).thenReturn(recordCollection);
        try {
            postToAsyncBridgeProcessor.process(exchange);
            verify(asyncBridgeService, times(1)).updateTransactionWithError(any(), any(), any());
        } catch (Exception e) {
            assertIsInstanceOf(BadRequestException.class, e);
        }

    }

//    @Test(expected = RuntimeException.class)
//    public void testCheckRequestStatusNoRecordFound() {
//        String dgcRequestId = "TST_DGC_REQUEST_ID-123";
//        DefaultCamelContext context = new DefaultCamelContext();
//        DefaultExchange exchange = new DefaultExchange(context);
//        exchange.getIn().setBody(dgcRequestId, String.class);
//        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.empty());
//        postToAsyncBridgeProcessor.checkTransactionStatus(exchange);
//        assertNotNull(exchange.getProperty(DgcPaymentConstants.TRANSACTION_STATUS, String.class));
//    }

//    @Test
//    public void testCheckRequestStatus() {
//        String dgcRequestId = "TST_DGC_REQUEST_ID-123";
//        DefaultCamelContext context = new DefaultCamelContext();
//        DefaultExchange exchange = new DefaultExchange(context);
//        exchange.getIn().setBody(dgcRequestId, String.class);
//
//        DgcRequest dgcRequest = testDataProvider.getDBDgcRequest();
//        dgcRequest.setRequestStatus(TransactionStatusConstants.STATUS_PROCESSED);
//        when(dgcRequestsRepository.getTransactionByRequestId(any())).thenReturn(Optional.of(dgcRequest));
//        postToAsyncBridgeProcessor.checkTransactionStatus(exchange);
//        assertEquals("PROCESSED", exchange.getProperty(DgcPaymentConstants.TRANSACTION_STATUS, String.class));
//    }

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(postToAsyncBridgeProcessor).to("mock:result");
            }
        };
    }
}
