package com.nike.dgcfulfillmentservice.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for the {@link DgcPaymentsController}.
 */
public class DgcPaymentsControllerTest {

    private DgcPaymentsController dgcPaymentsController;

    @BeforeEach
    public void setup() {
        dgcPaymentsController = new DgcPaymentsController();
    }

    @Test
    public void testExampleGetOtherService_timeout() throws Exception {
        assertThat(dgcPaymentsController.success()).containsEntry("success", "true");
    }
}
