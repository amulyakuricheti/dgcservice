package com.nike.dgcfulfillmentservice.service;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.model.dynamoDB.DgcRequest;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayInput;
import com.nike.dgcfulfillmentservice.model.paymentgateway.PaymentGatewayResponse;
import com.nike.dgcfulfillmentservice.repository.DgcRequestsRepository;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.OffsetDateTime;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PaymentGatewayServiceTest {

    @Mock
    private DgcRequestsRepository dgcRequestsRepository;

    @Mock
    private DgcPaymentsService DGCPaymentsService;

    @InjectMocks
    private PaymentGatewayService paymentGatewayService;

    private TestDataProvider testDataProvider = new TestDataProvider();


    @Test
    public void testCreatePGInputWithRequest() throws Exception {
        PaymentGatewayInput pgInputRequest = paymentGatewayService.preparePaymentGatewayRequest(
                testDataProvider.createOrderReleaseInput(), "ACCNO123");
        assertEquals(pgInputRequest.getRequest().getCertificateProfileId(), "14752962350");
        assertEquals(pgInputRequest.getRequest().getReferenceCode(), "C08233443468");
        assertEquals(pgInputRequest.getRequest().getAccount(), "ACCNO123");
        assertEquals(pgInputRequest.getRequest().getCurrency(), "USD");
        assertThat(pgInputRequest.getRequest().getAmount(), Matchers.is(25.0));
        assertEquals(pgInputRequest.getRequest().getSenderInfo().getName().getFirstName(), "firstName");
        assertEquals(pgInputRequest.getRequest().getSenderInfo().getName().getLastName(), "lastName");
        assertEquals(pgInputRequest.getRequest().getSenderInfo().getContactInfo().getEmail(), "test@nike.com");
        assertEquals(pgInputRequest.getRequest().getRecipientInfo().getContactInfo().getEmail(), "ntester26@gmail.com");
    }

    @Test
    public void testCreatePGInputWithTxnId() throws Exception {
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(testDataProvider.getDBDgcRequest()));
        PaymentGatewayInput pgInputRequest = paymentGatewayService.preparePaymentGatewayRequest("TEST123");
        assertEquals(pgInputRequest.getRequest().getCertificateProfileId(), "14752962350");
        assertEquals(pgInputRequest.getRequest().getReferenceCode(), "TSTORDNO1234");
        assertEquals(pgInputRequest.getRequest().getAccount(), "TST_GFTCRD_NO_1234");
        assertEquals(pgInputRequest.getRequest().getCurrency(), "USD");
        assertThat(pgInputRequest.getRequest().getAmount(), Matchers.is(100.0));
        assertEquals(pgInputRequest.getRequest().getSenderInfo().getName().getFirstName(), "firstName");
        assertEquals(pgInputRequest.getRequest().getSenderInfo().getName().getLastName(), "lastName");
        assertEquals(pgInputRequest.getRequest().getSenderInfo().getContactInfo().getEmail(), "test@mail.com");
        assertEquals(pgInputRequest.getRequest().getRecipientInfo().getContactInfo().getEmail(), "test12@mail.com");
    }

    @Test
    public void testCreatePGInputWithdgcRequestIdNoDBRecord() throws Exception {
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.empty());
        PaymentGatewayInput pgInputRequest = paymentGatewayService.preparePaymentGatewayRequest("TEST123");
        assertNull(pgInputRequest);
    }

    @Test
    public void testUpdateWithPGPendingResponse() throws Exception {

        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(dbDgcRequest));
        paymentGatewayService.updateWithPGPendingResponse("TEST123", testDataProvider.createPaymentGatewayResponse());
        assertThat(dbDgcRequest.getEta(), is(5000));
        assertThat(dbDgcRequest.getRequestStatus(), is("PROCESSING"));
        assertThat(dbDgcRequest.getPgGetUrl(), is("/payment/gift_certificates/v1/jobs/ae6575a7-8c0e-44ef-b91b-440bdaf2070b"));
        assertNotNull(dbDgcRequest.getLastModifiedDateTime());
        verify(dgcRequestsRepository, times(1)).updateTransaction(any());

    }

    @Test(expected = RuntimeException.class)
    public void testUpdateWithPGPendingResponseNoDBRecord() throws Exception {
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.empty());
        paymentGatewayService.updateWithPGPendingResponse("TEST123", testDataProvider.createPaymentGatewayResponse());
    }

    @Test
    public void testUpdateWithPGCompletedResponse() throws Exception {
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(dbDgcRequest));
        paymentGatewayService.updateWithPGCompletedResponse("TEST123", testDataProvider.createPaymentGatewayResponseCompleted());
        assertThat(dbDgcRequest.getEta(), is(0));
        assertNotNull(dbDgcRequest.getLastModifiedDateTime());
        assertNull(dbDgcRequest.getErrorMessage());
        assertNull(dbDgcRequest.getErrorCode());
        assertEquals(dbDgcRequest.getRequestStatus(), "PROCESSED");
        assertEquals(dbDgcRequest.getRequestSuccess(), true);
        assertEquals(dbDgcRequest.getPgGiftCardResultsUrl(), "/payment/gift_certificate_results/v1/2722be3a-0341-11e6-b512-3e1d05defe78432");
        assertEquals(dbDgcRequest.getExpirationDate(), OffsetDateTime.parse("2099-12-31T08:00:42.428Z"));
        assertThat(dbDgcRequest.getTtl(), Matchers.greaterThan(OffsetDateTime.now().toEpochSecond()));
        verify(dgcRequestsRepository, times(1)).updateTransaction(any());

    }

    @Test(expected = RuntimeException.class)
    public void testUpdateWithPGCompletedResponseNoDBRecord() throws Exception {
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.empty());
        paymentGatewayService.updateWithPGCompletedResponse("TEST123", testDataProvider.createPaymentGatewayResponseCompleted());
    }


    @Test
    public void testUpdateWithPGCompletedResponseWithError() throws Exception {
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(dbDgcRequest));
        PaymentGatewayResponse paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompleted();
        paymentGatewayResponse.getResponse().setRequestSuccess(false);
        paymentGatewayResponse.getResponse().setErrorCode("10");
        paymentGatewayResponse.getResponse().setErrorMessage("INVALID_VALUE");
        paymentGatewayService.updateWithPGCompletedResponse("TEST123", paymentGatewayResponse);
        assertThat(dbDgcRequest.getEta(), is(0));
        assertEquals(dbDgcRequest.getBusinessErrorMessage(), "INVALID_VALUE");
        assertEquals(dbDgcRequest.getBusinessErrorCode(), "10");
        assertEquals(dbDgcRequest.getRequestStatus(), "PROCESSED");
        verify(dgcRequestsRepository, times(1)).updateTransaction(any());

    }

    @Test
    public void testUpdateWithPGCompletedResponseWithErrorSuccess() throws Exception {
        DgcRequest dbDgcRequest = testDataProvider.getDBDgcRequest();
        when(DGCPaymentsService.getDgcRequestByDgcRequestId(any())).thenReturn(Optional.of(dbDgcRequest));
        PaymentGatewayResponse paymentGatewayResponse = testDataProvider.createPaymentGatewayResponseCompleted();
        paymentGatewayResponse.getResponse().setRequestSuccess(true);
        paymentGatewayResponse.getResponse().setErrorCode("10");
        paymentGatewayResponse.getResponse().setErrorMessage("INVALID_VALUE");
        paymentGatewayService.updateWithPGCompletedResponse("TEST123", paymentGatewayResponse);
        assertThat(dbDgcRequest.getEta(), is(0));

        //to verify not to update  business error values in case of requestSuccess is true
        assertNotEquals(dbDgcRequest.getBusinessErrorMessage(), "INVALID_VALUE");
        assertNotEquals(dbDgcRequest.getBusinessErrorCode(), "10");

        assertEquals(dbDgcRequest.getRequestStatus(), "PROCESSED");
        verify(dgcRequestsRepository, times(1)).updateTransaction(any());

    }

    @Test
    public void testUpdatePaymentTransactionWithError() {

        paymentGatewayService.updatePaymentTransactionWithError("TID123", "10", "INVALID_VALUE");
        verify(DGCPaymentsService, times(1)).updateTransactionToError(any(), any(), any());

    }

}


