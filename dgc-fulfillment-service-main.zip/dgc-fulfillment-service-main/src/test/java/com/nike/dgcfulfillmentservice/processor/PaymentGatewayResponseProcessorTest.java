package com.nike.dgcfulfillmentservice.processor;

import com.nike.dgcfulfillmentservice.TestDataProvider;
import com.nike.dgcfulfillmentservice.constant.DgcPaymentConstants;
import com.nike.dgcfulfillmentservice.constant.TransactionStatusConstants;
import com.nike.dgcfulfillmentservice.service.PaymentGatewayService;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class PaymentGatewayResponseProcessorTest extends ProcessorTest {

    @Mock
    private PaymentGatewayService paymentGatewayService;

    @InjectMocks
    private PaymentGatewayResponseProcessor paymentGatewayResponseProcessor;

    private TestDataProvider testDataProvider = new TestDataProvider();


    @Test
    public void testProcessPending() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        exchange.getIn().setBody(testDataProvider.createPaymentGatewayResponse());

        template.send(exchange);

        verify(paymentGatewayService, times(1)).updateWithPGPendingResponse(any(), any());
        assertEquals(exchange.getProperty(DgcPaymentConstants.TRANSACTION_STATUS, String.class), TransactionStatusConstants.STATUS_PROCESSING);
    }

    @Test
    public void testProcessCompleted() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        exchange.getIn().setBody(testDataProvider.createPaymentGatewayResponseCompleted());

        template.send(exchange);

        verify(paymentGatewayService, times(1)).updateWithPGCompletedResponse(any(), any());
        assertEquals(exchange.getProperty(DgcPaymentConstants.TRANSACTION_STATUS, String.class), TransactionStatusConstants.STATUS_PROCESSED);
        assertNotNull(exchange.getProperty(DgcPaymentConstants.PG_RESULT_URL, String.class));
    }

    @Test
    public void testProcessInRetry() throws Exception {
        DefaultCamelContext context = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(context);

        exchange.getIn().setHeader(DgcPaymentConstants.DGC_REQUEST_ID, "TEST123");
        exchange.getIn().setBody(testDataProvider.createPaymentGatewayResponseCompleted().getResponse());
        template.send(exchange);
//        verify(paymentGatewayService, times(1)).updateWithPGCompletedResponse(any(), any());
        assertEquals(exchange.getProperty(DgcPaymentConstants.TRANSACTION_STATUS, String.class), TransactionStatusConstants.STATUS_PROCESSED);
    }

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from("direct:start")
                        .process(paymentGatewayResponseProcessor).to("mock:result");
            }
        };
    }

}
